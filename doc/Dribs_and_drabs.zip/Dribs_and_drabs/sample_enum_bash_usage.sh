#!/bin/bash

function _enum
{
   local list=("$@")
   local len=${#list[@]}

   for (( i=0; i<$len; i++ )); do
      eval "${list[i]}=$i"
   done
}

ENUM=(
    NULL
    OA5
    Muni
    CMO
    GovCorp
    MD2
    EP
    DFC
    CDF_IT
    Morts
    Warrants
    FXIR
    ESG
    EOD_TS
    MIFID
    Filings
    RCDC
    CIQM
    Research
    TESTING
) && _enum "${ENUM[@]}"

#arr_CSN=("NULL" "OA5" "Muni" "CMO" "GovCorp" "MD2" "EP" "DFC" "CDF_IT" "Morts" "Warrants" "FXIR" "ESG" "EOD-TS" "MIFID" "Filings" "RCDC" "CIQM" "Research" "TESTING")
arr_SDT=("" "-05112020" "-05142020" "-05152020" "-05152020" "-0515wid" "-05122020" "-0515v71-id" "-05152020-id" "-05292020" "-06022020" "-06042020-3" "-06042020-2" "-06042020" "-06102020" "-06162020-1" "-06162020-2" "-06162020-3" "-06162020-4" "-06092020")

DSNM=$1

if [ "${DSNM}" = "ALL" ]; then
    LEN=${#ENUM[@]}
    for ((i=1;i<${LEN};i++)); do
        printf "  %-12s %-15s\n" ${ENUM[$i]} ${arr_SDT[$i]}
    done
else
    SD_TAG=${arr_SDT[${ENUM[${DSNM}]}]}
    if [ -n "${SD_TAG}" ]; then
        printf "  %-12s %-15s\n" ${DSNM} ${arr_SDT[${DSNM}]}
    else
        echo "'${DSNM}' not found!"
        exit 1
    fi
fi
