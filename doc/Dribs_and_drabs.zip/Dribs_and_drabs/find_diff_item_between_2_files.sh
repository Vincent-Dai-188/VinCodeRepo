#!/bin/bash

FILE1=$1
FILE2=$2

echo -e "\n1. Items in '$FILE1' but not in '$FILE2':"
while read LINE_1;
do
    #LINE_1=`echo $LINE_1 | awk '{print $1}'`
    grep $LINE_1 $FILE2 &>/dev/null
    if [ $? -ne 0 ]; then
        echo "  < $LINE_1"
    fi
done < $FILE1

echo -e "\n2. Items in '$FILE2' but not in '$FILE1':"

while read LINE_2;
do
    LINE_2=`echo $LINE_2 | awk '{print $1}'`
    grep $LINE_2 $FILE1 &>/dev/null
    if [ $? -ne 0 ]; then
        echo "  > $LINE_2"
    fi
done < $FILE2

echo
