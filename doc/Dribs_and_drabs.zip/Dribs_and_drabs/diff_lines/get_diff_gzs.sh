#!/bin/bash

function RUNIT
{
    echo ">> $@"
    $@
}

fullfile="./gzs_list_full.txt"
blacklistfile="./gzs_list_to_be_removed.txt"

declare -a FULL_SET=()
while read -r line
do
    FULL_SET+=($line)
done < "${fullfile}"

declare -a BL_SET=()
while read -r line
do
    BL_SET+=($line)
done < "${blacklistfile}"

for findex in ${!FULL_SET[@]}; do
    fl_item=${FULL_SET[$findex]}
    if (( findex % 100 == 0 )); then
        echo "- [$findex] ${fl_item}"
    fi
    if [ ${#BL_SET[*]} -ne 0 ]; then
        for bindex in ${!BL_SET[@]}; do
            bl_item=${BL_SET[$bindex]}
            if [ "${fl_item}" == "${bl_item}" ]; then
                #echo " >> unset : BL_SET[$bindex], FULL_SET[$findex]"
                unset BL_SET[$bindex]
                unset FULL_SET[$findex]
                break
            fi
        done
    else
        break
    fi
done

echo -e "\n  Final result: FULL_SET[${#FULL_SET[*]}], BL_SET[${#BL_SET[*]}]"

fout="./gzs_result.txt"
if [ -f $fout ]; then
    rm -f $fout
fi
echo -e "\n>> Output result..."
for fline in ${FULL_SET[@]}; do
    echo $fline >> $fout
done

echo -e "\n    Done."
