#!/bin/bash

RSAKEY="./rsa_key_2048.txt"

if [ ! -f ${RSAKEY} ]; then
    # Generate a 2048-bit RSA key file
    openssl genrsa -out ${RSAKEY} 2048
fi

# Encrypt "hello world" using the RSA key file
echo "hello world" | openssl rsautl -inkey ${RSAKEY} -encrypt > output.bin

# Decrypt the message and output to stdout
openssl rsautl -inkey ${RSAKEY} -decrypt < output.bin

# -----------------------------------------------

echo -n "Master^@12345" | base64 > out_key.bin

mypass=`cat out_key.bin | base64 --decode`
tag="01010"
echo $mypass | sed -n "s/\^/${tag}/p"
#Master01010@12345


/* Without '-n', '\n' will be added at the end. */
c870xdtddes02:~ # echo "Master^@12345" | base64
TWFzdGVyXkAxMjM0NQo=
c870xdtddes02:~ # echo "TWFzdGVyXkAxMjM0NQo=" | base64 --decode
Master^@12345
c870xdtddes02:~ #

/* With '-n', no '\n' will be encoded. */
c870xdtddes02:~ # echo -n "Master^@12345" | base64
TWFzdGVyXkAxMjM0NQ==
c870xdtddes02:~ # echo "QXJjdGljNzE4OEBTRg==" | base64 --decode
Arctic7188@SFc870xdtddes02:~ #
