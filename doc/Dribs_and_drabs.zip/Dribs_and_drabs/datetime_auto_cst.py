import sys
import datetime

if len(sys.argv) == 2:
    MYMPW = str(sys.argv[1])
else:
    # Set timezone to CST (UTC+8)
    cst = datetime.timezone(datetime.timedelta(hours=8))
    # Convert current datetime (UTC+8) to string
    MYMPW = datetime.datetime.now(cst).strftime('%m%d')

print("The KEY is: ~%s~" % MYMPW)