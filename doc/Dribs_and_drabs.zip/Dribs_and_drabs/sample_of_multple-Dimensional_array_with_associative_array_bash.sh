#!/bin/bash

# Put 0/1 into an associative array with index (0,1,...)
declare -A LEDArray=()

for ((idx=0;idx<=9;idx++)); do
    LEDArray+=([$idx]=${idx})
done

printf "%-2s" ${LEDArray[@]}
echo

for ((idx=0;idx<=9;idx++)); do
    echo ${LEDArray[$idx]}
done

# simulate a multi-dimensional array with associative array
declare -A mulDenArray=()
mulDenArray[0,0]="0-0"
mulDenArray[0,1]="0-1"
mulDenArray[1,0]="1-0"
mulDenArray[1,1]="1-1"

echo "Output multi-dimensional array:"
echo "${mulDenArray[0,0]} ${mulDenArray[0,1]}" # will print 0 1
