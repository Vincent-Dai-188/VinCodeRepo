#!/bin/bash

croncmd="/home/me/myfunction myargs > /home/me/myfunction.log 2>&1"
cronjob="0 */15 * * * $croncmd"

echo "To add it to the crontab, with no duplication:"
( crontab -l | grep -v -F "$croncmd" ; echo "$cronjob" ) | crontab -
crontab -l

sleep 2

echo "To remove it from the crontab whatever its current schedule:"
( crontab -l | grep -v -F "$croncmd" ) | crontab -
crontab -l