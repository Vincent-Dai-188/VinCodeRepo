#include "stdio.h"

// Assumes little endian
void printBits(size_t const size, void const * const ptr)
{
    unsigned char *b = (unsigned char*) ptr;
    unsigned char byte;
    int i, j;

    for (i = size-1; i >= 0; i--) {
        for (j = 7; j >= 0; j--) {
            byte = (b[i] >> j) & 1;
            printf("%u", byte);
        }
    }
    puts("");
}

main()
{
    unsigned short iRow = 65535;;
    printf("%x\n", iRow);
    iRow = 65530;
    printBits(sizeof(iRow), &iRow);
    return 0;
}
