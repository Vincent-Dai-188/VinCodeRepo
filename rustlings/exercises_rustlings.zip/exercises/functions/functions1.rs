// functions1.rs
// Execute `rustlings hint functions1` or use the `hint` watch subcommand for a hint.


fn main() {
    call_me();
}

fn call_me() {
    println!("I am here!");
}
