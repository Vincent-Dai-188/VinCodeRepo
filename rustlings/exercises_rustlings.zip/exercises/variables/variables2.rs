// variables2.rs
// Execute `rustlings hint variables2` or use the `hint` watch subcommand for a hint.


fn main() {
    let x : i32 = 0;
    if x == 10 {
        println!("x is ten!");
    } else {
        println!("x is not ten!");
    }
}
