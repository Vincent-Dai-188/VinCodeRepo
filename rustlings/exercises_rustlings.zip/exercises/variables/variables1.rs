// variables1.rs
// Make me compile!
// Execute `rustlings hint variables1` or use the `hint` watch subcommand for a hint.


fn main() {
    let x = 5;
    println!("x has the value {}", x);
}
