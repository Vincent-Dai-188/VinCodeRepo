// variables3.rs
// Execute `rustlings hint variables3` or use the `hint` watch subcommand for a hint.


fn main() {
    let x: i32 = 99;
    println!("Number {}", x);
}
