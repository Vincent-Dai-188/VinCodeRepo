import time
import sys
from selenium import webdriver

if len(sys.argv) == 1:
    print("A KEY string must be provided!")
    sys.exit(1)

SAFE_ID='######'
SAFE_PSW='************'
UID_TEN='U######'
UID_TEN_PSW='************'

EXTKEY = str(sys.argv[1])
print("The KEY is: ~%s~" % EXTKEY)
# Define your password pattern here
MYMPW = 'ABCDEF' + EXTKEY + '123456'

# Launch a new Chrome browser instance with specified proxy-server
chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument('--proxy-server=webproxy.int.westgroup.com:80')

driver = webdriver.Chrome(chrome_options=chrome_options)
driver.get("https://passwordmanager.thomsonreuters.com/hipm_tr/psf.exe?&LANG=en-US#2")

time.sleep(2)

driver.find_element_by_name('USER').send_keys(SAFE_ID)
pw_box = driver.find_element_by_name('PASSWORD')
pw_box.send_keys(SAFE_PSW)
pw_box.submit()

uid_box = driver.find_element_by_name('USER_IDENT')
uid_box.send_keys(UID_TEN)
uid_box.submit()

driver.find_element_by_name('SUBMIT-chn:$INTERNAL_password.pss').click()

mypw_box = driver.find_element_by_name('_MYPW')
mypw_box.send_keys(UID_TEN_PSW)
mypw_box.submit()

driver.find_element_by_link_text("Change passwords").click()

driver.find_element_by_name('SUBMIT-SELECT-TR_HIPM_MGMT').click()

driver.find_element_by_name('_NEWP1').send_keys(MYMPW)
np2_box = driver.find_element_by_name('_NEWP2')
np2_box.send_keys(MYMPW)
np2_box.submit()

# Wanna close this Chrome browser window automatically, uncomment this segment of code below
#time.sleep(2)
#driver.close()
#driver.quit()

print("    Done.")
