#!/bin/bash

if (( $# >= 1 )); then
    /data/venv3/bin/python /data/venv3/bin/pm_rotate.py $@
else
    /data/venv3/bin/python /data/venv3/bin/pm_rotate.py
fi
