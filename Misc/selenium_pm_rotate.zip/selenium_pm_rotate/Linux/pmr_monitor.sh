#!/bin/bash

signfile="/tmp/sign_pmr"
logfile="/tmp/pmrchk.log"

/data/vincent/AWS/login_aws &> /dev/null
iret=$?
if [ $iret -ne 0 ]; then
	echo "`date`    PW_Expiration detected!" >> $logfile
	if [ ! -f ${signfile} ]; then
		/data/vincent/sendmail_message "PMR detected! (`date`)"
		touch ${signfile}
	fi
else
	echo "`date`    PW_OK" >> $logfile
fi

exit $iret