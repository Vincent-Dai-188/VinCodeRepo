import time
import sys
import subprocess
import os.path
import getopt
import base64
import datetime
from selenium import webdriver

SHOWUI = 0
MYMPW = ""
SIGNFILE="/tmp/.pw_sign.dat"
PSN = ""
options, otherargs = getopt.getopt(sys.argv[1:], 'UK:')

for opt, arg in options:
    if opt == '-K':
        MYMPW = arg

if not MYMPW:
    cst = datetime.timezone(datetime.timedelta(hours=8))
    MMDD = datetime.datetime.now(cst).strftime('%m%d')
    month_l = str(9 - int(MMDD[2]))
    MYMPW = MMDD[0] + MMDD[1] + month_l + MMDD[3]
    if os.path.isfile(SIGNFILE):
        with open(SIGNFILE, 'r') as f:
            cnt = f.read()
        if MMDD == cnt[0:4]:
            sn = cnt[4:5]
            if '1' == sn:
                # Option 2 PW
                PSN = "2"
                MYMPW = month_l + MMDD[3] + MMDD[0] + MMDD[1]
            elif '2' == sn:
                print("\n### No available KEY, please specify the KEY with '-K' option! ###")
                sys.exit(2)
        else:
            PSN = "1"
    else:
        PSN = "1"

print("The KEY is: ~%s~" % MYMPW)

print("- Headless Mode -")

PWPRE = subprocess.check_output(["/usr/local/bin/pm_dec", "587Wrg3j"]).decode('cp437')
PWSUF = subprocess.check_output(["/usr/local/bin/pm_dec", "2DOgN5Ib"]).decode('cp437')
MYMPW = PWPRE + MYMPW + PWSUF

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument('--proxy-server=webproxy.int.westgroup.com:80')
chrome_options.add_argument('--no-sandbox');

''' These options below for Headless Chrome only '''
# Hide Chrome browser instance UI
chrome_options.add_argument("--headless")
# Recommended to disable "gpu" as well with "--headless" if running on Windows
chrome_options.add_argument("--disable-gpu")
# Suppress console warning/info messages: INFO = 0, WARNING = 1, LOG_ERROR = 2, LOG_FATAL = 3
# If you want a totally silent mode, it's better to use --log-level=OFF
chrome_options.add_argument('log-level=2')

#driver = webdriver.Chrome('/data/venv3/bin/chromedriver', chrome_options=chrome_options, \
#service_args=['--verbose', '--log-path=/data/vincent/chromedriver.log'])
driver = webdriver.Chrome('/data/venv3/bin/chromedriver', chrome_options=chrome_options)
driver.get("https://passwordmanager.thomsonreuters.com/hipm_tr/psf.exe?&LANG=en-US#2")

time.sleep(2)

PWSAF = subprocess.check_output(["/usr/local/bin/pm_dec", "2gnYs97PsPmhM5wi2FNG"]).decode('cp437')
driver.find_element_by_name('USER').send_keys('6067763')
pw_box = driver.find_element_by_name('PASSWORD')
pw_box.send_keys(PWSAF)
pw_box.submit()

uid_box = driver.find_element_by_name('USER_IDENT')
uid_box.send_keys('U6067763')
uid_box.submit()

driver.find_element_by_name('SUBMIT-chn:$INTERNAL_password.pss').click()

PWTEN = subprocess.check_output(["/usr/local/bin/pm_dec", "3G7aq8Ne2DObMw=="]).decode('cp437')
mypw_box = driver.find_element_by_name('_MYPW')
mypw_box.send_keys(PWTEN)
# Note: In case the decoded PWTEN string is ended with '\n' (RETURN), you must *not* to invoke this .submit() below.
mypw_box.submit()

driver.find_element_by_link_text("Change passwords").click()

driver.find_element_by_name('SUBMIT-SELECT-TR_HIPM_MGMT').click()

driver.find_element_by_name('_NEWP1').send_keys(MYMPW)
np2_box = driver.find_element_by_name('_NEWP2')
np2_box.send_keys(MYMPW)
np2_box.submit()

time.sleep(5)

elements = driver.find_elements_by_xpath('//*[@id="content"]/table/tbody/tr[2]/td[4]/span')
if elements:
    print("\n    Done.\n")

    # Update process sign file
    if PSN:
        with open(SIGNFILE, 'w') as f:
            f.seek(0)
            f.write(MMDD + PSN)
        print("*** Write sign file, done. ***")
else:
    print("\n    Oops! Something went wrong!\n")

# Calling close and then quit will kill the driver running process.
driver.close()

driver.quit()
