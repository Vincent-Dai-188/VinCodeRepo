import time
import sys
import subprocess
import os.path
import getopt
import base64
import datetime
from selenium import webdriver

SHOWUI = 0
MYMPW = ""
SIGNFILE="/tmp/.pw_sign.dat"
PSN = ""
options, otherargs = getopt.getopt(sys.argv[1:], 'UK:')

for opt, arg in options:
    if opt == '-K':
        MYMPW = arg

if not MYMPW:
    cst = datetime.timezone(datetime.timedelta(hours=8))
    MMDD = datetime.datetime.now(cst).strftime('%m%d')
    month_l = str(9 - int(MMDD[2]))
    MYMPW = MMDD[0] + MMDD[1] + month_l + MMDD[3]
    if os.path.isfile(SIGNFILE):
        with open(SIGNFILE, 'r') as f:
            cnt = f.read()
        if MMDD == cnt[0:4]:
            sn = cnt[4:5]
            if '1' == sn:
                # Option 2 PW
                PSN = "2"
                MYMPW = month_l + MMDD[3] + MMDD[0] + MMDD[1]
            elif '2' == sn:
                print("\n### No available KEY, please specify the KEY with '-K' option! ###")
                sys.exit(2)
        else:
            PSN = "1"
    else:
        PSN = "1"

print("The KEY is: ~%s~" % MYMPW)

print("- Headless Mode -")

PWSET = subprocess.check_output(["/usr/local/bin/pm_dec"]).decode('cp437')
PWLIST = PWSET.split()
PWPRE = PWLIST[0]
PWSUF = PWLIST[1]
PWSAF = PWLIST[2]
PWTEN = PWLIST[3]

MYMPW = PWPRE + MYMPW + PWSUF

chrome_options = webdriver.ChromeOptions()
chrome_options.add_argument('--proxy-server=webproxy.int.westgroup.com:80')
chrome_options.add_argument('--no-sandbox');

''' These options below for Headless Chrome only '''
# Hide Chrome browser instance UI
chrome_options.add_argument("--headless")
# Recommended to disable "gpu" as well with "--headless" if running on Windows
chrome_options.add_argument("--disable-gpu")
# Suppress console warning/info messages: INFO = 0, WARNING = 1, LOG_ERROR = 2, LOG_FATAL = 3
# If you want a totally silent mode, it's better to use --log-level=OFF
chrome_options.add_argument('log-level=2')

#driver = webdriver.Chrome('/data/venv3/bin/chromedriver', chrome_options=chrome_options, \
#service_args=['--verbose', '--log-path=/data/vincent/chromedriver.log'])
driver = webdriver.Chrome('/data/venv3/bin/chromedriver', chrome_options=chrome_options)
driver.get("https://passwordmanager.thomsonreuters.com/hipm_tr/psf.exe?&LANG=en-US#2")

time.sleep(5)

print(">> Check SAFE-LOGIN ...\n")

# Expect to see SAFE-LOGIN window first
n = 0
while n < 3:
    n += 1
    try:
        usr_box = driver.find_element_by_name('USER')
        usr_box.send_keys('6067763')
        pw_box = driver.find_element_by_name('PASSWORD')
        pw_box.send_keys(PWSAF)
        pw_box.submit()
        print("*** SFAELOGIN complete ***\n")
        break
    except:
        print("Exception: %s\n", sys.exc_info()[0])
        if n >= 3:
            print("Bypass SFAELOGIN ...\n")
        else:
            print("Will retry after 2 seconds ...\n")
            time.sleep(2)
            continue

time.sleep(2)

print(">> Check TEN-LOGIN ...\n")
uid_box = driver.find_element_by_name('USER_IDENT')
print("*** TEN-LOGIN complete ***\n")

# Calling close and then quit will kill the driver running process.
driver.close()

driver.quit()
