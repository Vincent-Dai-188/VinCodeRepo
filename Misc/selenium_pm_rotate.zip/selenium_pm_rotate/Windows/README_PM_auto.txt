Setup:
------
1. Unzip venv2.zip to C:\
2. Replace all these %YOUR_xxx_xxxx% strings in C:\venv2\Scripts\PM_auto.py
3. Download webdriver for Chrome:  https://sites.google.com/a/chromium.org/chromedriver/downloads
	Unzip and place the "chromedriver.exe" under a directory that is included in %PATH% (e.g., C:\Python\Python36\Scripts\)
4. Create a Shortcut on Desktop to refer to "C:\venv2\Scripts\python.exe PM_auto.py [-U] [-K <key>]"
	-U: UI mode (default: headless mode)
	-K <key>: Specify a key (e.g., 1610) explicitly in case the default password is expired in a working day.


Troubleshooting:
----------------
[9488:8984:0125/072437.582:ERROR:install_util.cc(687)] Failed to read HKLM\SOFTWARE\Policies\Google\Chrome\MachineLevelUserCloudPolicyEnrollmentToken: The system cannot find the file specified. (0x2)

Solution/Workaround:
Regedit => HKLM\SOFTWARE\Policies\Google\Chrome\ => Add New String:
        MachineLevelUserCloudPolicyEnrollmentToken      Value: empty
