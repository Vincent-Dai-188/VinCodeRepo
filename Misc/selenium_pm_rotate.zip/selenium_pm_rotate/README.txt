- python 2.7/3.6
  Modules required (can be installed in PyCharm):
    * selenium
    * splinter
    * six

- WebDriver for Chrome (place the exe file at a location that is already included in %PATH%):
    webdriver.exe       /* https://sites.google.com/a/chromium.org/chromedriver/downloads */

- WebDriver for Firefox (place the exe file at a location that is already included in %PATH%):
    geckodriver.exe     /* https://github.com/mozilla/geckodriver/releases */

-------------------------------------------------------------------------------
[9488:8984:0125/072437.582:ERROR:install_util.cc(687)] Failed to read HKLM\SOFTWARE\Policies\Google\Chrome\MachineLevelUserCloudPolicyEnrollmentToken: The system cannot find the file specified. (0x2)

Solution/Workaround:
Regedit => HKLM\SOFTWARE\Policies\Google\Chrome\ => Add New String:
        MachineLevelUserCloudPolicyEnrollmentToken      Value: empty

-------------------------------------------------------------------------------
How to install webdriver on a windows system
/* Avoid "'webdriver'/'geckodriver' executable needs to be in PATH." error on Windows. */

Answer: You can put it anywhere. 

1. Download following driver 

Chrome:	    https://sites.google.com/a/chromium.org/chromedriver/downloads
Edge:	    https://developer.microsoft.com/en-us/microsoft-edge/tools/webdriver/
Firefox:	https://github.com/mozilla/geckodriver/releases
Safari:	    https://webkit.org/blog/6900/webdriver-support-in-safari-10/

2. Unzip driver and put it into a folder. 

3. Load your driver in your code.
   I want to open Chrome browser so I set the path up in my code. 
      
   from selenium import webdriver
   url="C:\\Programs\\Python36\\BrowersDriver\\chromedriver.exe"
   driver=webdriver.Chrome(url)
   driver.get("http://www.yahoo.com")
   driver.close()
   driver.quit()

/* OR, you can jsut place the exe file at a location that is already included in %PATH%, then you don't need to specifiy the path in the code at all. */

Display %PATH% in PowerShell on Windows: 
PS C:\WINDOWS\System32> $Env:Path
C:\Python27\;C:\Python27\Scripts;C:\Program Files (x86)\Common Files\Oracle\Java\javapath;C:\WINDOWS\system32;C:\WINDOWS;C:\WINDOWS\System32\Wbem;C:\WINDOWS\System32\WindowsPowerShell\v1.0\;C:\WINDOWS\System32\OpenSSH\;C:\Users\U6067763\AppData\Local\Microsoft\WindowsApps;