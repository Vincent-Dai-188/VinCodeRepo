#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include <errno.h>

enum ENVINDEX {Sandbox = 0, PPE = 1, MR = 2};

int env_index = 0;

const char *envtag[3] = {"Sandbox", "PPE", "MR"};
const char *profile[3] = {"tr-fr-sandbox", "tr-fr-preprod", "a-corporate-preprod"};
const char *account[3] = {"015887481462", "608014515287", "320776766695"};
const char *usrrole[3] = {"204618-PowerUser", "a205469-Developer", "a204121-Developer"};

int b64invs[] = { 62, -1, -1, -1, 63, 14, 15, 16, 17, 18, 19, 20,
	21, 22, 23, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5,
	6, 7, 8, 9, 10, 11, 12, 13, 36, 37, 38, 39, 40, 41, 42,
	43, 44, 45, 46, 47, -1, -1, -1, -1, -1, -1, 48, 49, 50,
	51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 24, 25, 26,
	27, 28, 29, 30, 31, 32, 33, 34, 35 };

int b64_isvalidchar(char c)
{
	if (c >= '0' && c <= '9')
		return 1;
	if (c >= 'A' && c <= 'Z')
		return 1;
	if (c >= 'a' && c <= 'z')
		return 1;
	if (c == '+' || c == '/' || c == '=')
		return 1;
	return 0;
}

size_t b64_decoded_size(const char *in)
{
	size_t len;
	size_t ret;
	size_t i;

	if (in == NULL)
		return 0;

	len = strlen(in);
	ret = len / 4 * 3;

	for (i=len; i-->0; ) {
		if (in[i] == '=') {
			ret--;
		} else {
			break;
		}
	}
	return ret;
}

int b64_decode(const char *in, unsigned char *out, size_t outlen)
{
	size_t len;
	size_t i;
	size_t j;
	int	v;

	if (in == NULL || out == NULL)
		return 0;

	len = strlen(in);
	if (outlen < b64_decoded_size(in) || len % 4 != 0)
		return 0;

	for (i=0; i<len; i++) {
		if (!b64_isvalidchar(in[i])) {
			return 0;
		}
	}

	for (i=0, j=0; i<len; i+=4, j+=3) {
		v = b64invs[in[i]-43];
		v = (v << 6) | b64invs[in[i+1]-43];
		v = in[i+2]=='=' ? v << 6 : (v << 6) | b64invs[in[i+2]-43];
		v = in[i+3]=='=' ? v << 6 : (v << 6) | b64invs[in[i+3]-43];

		out[j] = (v >> 16) & 0xFF;
		if (in[i+2] != '=')
			out[j+1] = (v >> 8) & 0xFF;
		if (in[i+3] != '=')
			out[j+2] = v & 0xFF;
	}

	return 1;
}

int cloud_tool_login( char *passwd )
{
    FILE *fp;
    char outinfo[1025];
	char cmd[168];
	int iRetCode = 1;

	memset(cmd, '\0', 168);
    /* '-v' must be given, otherwise no output will be piped. */
	sprintf(cmd, "cloud-tool-fr --profile %s -v login -u 'mgmt\\m6067763' -p '%s' -a %s -r 'human-role/%s'", \
		profile[env_index], passwd, account[env_index], usrrole[env_index]);

    fp = popen(cmd, "r");
    if (fp == NULL) {
        printf("Failed to run popen command. [errno = %d]\n", errno);
        exit(1);
    }

    /* Read the output a line at a time - output it. */
    while (! feof(fp)) {
        if (fgets(outinfo, sizeof(outinfo), fp) != NULL) {
            printf("%s", outinfo);
            if (iRetCode && (strstr(outinfo, "ERROR") != NULL)) {
                iRetCode = 0;
            }
        }
    }

    pclose(fp);

    return iRetCode;
}

int retrieve_basepw( char *out )
{
	size_t out_len;

	FILE    *fp;
    char    *line = NULL;
    size_t  len = 0;
    ssize_t rlens;
	int     iRet = 1;

    fp = fopen("/data/vincent/AWS/pem/.key_ec2.dat", "r");
    if (fp == NULL)
        return 2;

	rlens = getline(&line, &len, fp);
	fclose(fp);
    if (rlens != -1) {
		if (line[rlens-1] == '\n') {
			line[rlens-1] = '\0';
			--rlens;
		}
		out_len = b64_decoded_size(line)+1;
		if (! b64_decode(line, (unsigned char *)out, out_len)) {
			iRet = 3;
		} else {
			out[out_len] = '\0';
			iRet = 1;
		}
    }
	if (line) free(line);
	return iRet;
}

void twist_keypw( char *keypw )
{
	char char_sw[4];
	char_sw[0] = keypw[2];
	char_sw[1] = keypw[3];
	
	char_sw[2] = keypw[0];
	char_sw[3] = keypw[1];
	
	memcpy(keypw, char_sw, 4);
}

void get_keypw( char *keypw )
{
    struct tm *mt;
    time_t mtt;

    setenv("TZ", "UTC-8",1);
    tzset();
    mtt = time(NULL);
    mt = localtime(&mtt);
	strftime(keypw,sizeof(keypw),"%m%d",mt);
	keypw[2] = 105 - keypw[2];
}

void assemble_passwd( char *basepw, char *keypw, char *pwstr )
{
	char buff_sw[32];
	char *index = NULL;
	int len;

	memset(buff_sw, '\0', 32);
	memcpy(pwstr, basepw, strlen(basepw));

	index = strstr(pwstr, "^");
	if (index) {
		len = strlen(index);
		memcpy(buff_sw, index+1, len-1);
		memset(index, '\0', len);
		memcpy(index, keypw, strlen(keypw));
		memcpy(index+strlen(keypw), buff_sw, strlen(buff_sw));
		/*printf("%s\n", pwstr);*/
	}
	else
	{
		printf("'^' not found!\n");
		exit(2);
	}
}

int check_pw_sign()
{
	FILE    *fp;
    char    *line = NULL;
    size_t  len = 0;
    ssize_t rlens;
	int     iRet = 0;

    fp = fopen("/tmp/.pw_sign.dat", "r");
    if (fp == NULL)
        return 0;

	rlens = getline(&line, &len, fp);
	fclose(fp);
    if (rlens != -1) {
		iRet = line[4] - 0x30;
    }

	if (line) free(line);
	return iRet;
}

int main(int argc, char **argv)
{
	char	basepw[32];
	char	pwstr[32];
	char	keypw[8];
	size_t  out_len;
	int 	iRet;
    int 	opt;
    int		iSpecKey = 0;
    int     iPWSign = 0;

    while((opt = getopt(argc, argv, ":SPMhK:")) != -1)
    {
        switch(opt)
        {
            case 'S':
				env_index = Sandbox;
                break;
            case 'P':
				env_index = PPE;
                break;
            case 'M':
				env_index = MR;
                break;
            case 'K':
				sprintf(keypw, "%s", optarg);
				iSpecKey = 1;
                break;
            case 'h':
				printf("Usage: login_aws [-S|-P|-M]\n");
				return 0;
            case '?':
				break;
        }
    }
	
	memset(pwstr, '\0', 32);

	iRet = retrieve_basepw((char *)basepw);
	if (iRet != 1) {
		printf("Failed to decode BASE_PW. [errno = %d]\n", iRet);
		return iRet;
	}

    iPWSign = check_pw_sign();
    if (iPWSign == 0) 
        iPWSign = 1;
    else if (iPWSign >= 3)
            iPWSign = 2;

	if (! iSpecKey) {
		get_keypw((char *)keypw);
        if (iPWSign == 2) {
            twist_keypw((char *)keypw);
			memset(pwstr, '\0', 32);
        }
        assemble_passwd((char *)basepw, (char *)keypw, (char *)pwstr);
		printf(">> [%d] Login '%s' ...\n", iPWSign, envtag[env_index]);
		iRet = cloud_tool_login((char *)pwstr);
		if (! iRet) {
			printf("Failed to login AWS account (%s)!\n", envtag[env_index]);
			return 1;
		}
	}
	else {
		assemble_passwd((char *)basepw, (char *)keypw, (char *)pwstr);
		printf(">> Login '%s' ...\n", envtag[env_index]);
		iRet = cloud_tool_login((char *)pwstr);
		if (! iRet) {
			printf("Failed to login AWS account(%s)!\n", envtag[env_index]);
			return 1;
		}
	}
	printf("    Done.\n");
	return 0;
}