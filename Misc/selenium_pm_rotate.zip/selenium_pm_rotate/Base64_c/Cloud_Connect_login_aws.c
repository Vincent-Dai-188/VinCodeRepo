#include <stdio.h>
#include <string.h>
#include <errno.h>

int Cloud_Connect_login()
{
    FILE *fp;
    char outinfo[1025];
	char cmd[256];
	int iRetCode = 0;

	memset(cmd, '\0', 256);
	sprintf(cmd, "/usr/bin/pwsh -Command Connect-AWS -u m6067763@qarft.refinitiv.com -p '1#49KxE6X!HUNPY' \
		-pr a-corporate-preprod -an 320776766695 -rn 'human-role/a204121-Developer' -r us-east-1");

    fp = popen(cmd, "r");
    if (fp == NULL) {
        printf("Failed to run popen command. [errno = %d]\n", errno);
        return -1;
    }

    /* Read the output a line at a time - output it. */
    while (! feof(fp)) {
        if (fgets(outinfo, sizeof(outinfo), fp) != NULL) {
            printf("%s", outinfo);
            if ( (! iRetCode) && (strstr(outinfo, "True") != NULL)) {
                iRetCode = 1;
            }
        }
    }

    pclose(fp);

    return iRetCode;
}

int main(int argc, char **argv)
{
	int iRet;

	iRet = Cloud_Connect_login();
	if (iRet != 1) {
		printf("\n*** Failed to login AWS account! ***\n");
		return 1;
	}

	return 0;
}