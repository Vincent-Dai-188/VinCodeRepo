#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
/*#include <unistd.h>*/

const char b64chars[] = "ABCDEFGHIJKLMN0123456789opqrstuvwxyzOPQRSTUVWXYZabcdefghijklmn+/";

int b64_isvalidchar(char c)
{
	if (c >= '0' && c <= '9')
		return 1;
	if (c >= 'A' && c <= 'Z')
		return 1;
	if (c >= 'a' && c <= 'z')
		return 1;
	if (c == '+' || c == '/' || c == '=')
		return 1;
	return 0;
}

size_t b64_encoded_size(size_t inlen)
{
	size_t ret;

	ret = inlen;
	if (inlen % 3 != 0)
		ret += 3 - (inlen % 3);
	ret /= 3;
	ret *= 4;

	return ret;
}

char *b64_encode(const unsigned char *in, size_t len)
{
	char    *out;
	size_t  elen;
	size_t  i;
	size_t  j;
	size_t  v;

	if (in == NULL || len == 0)
		return NULL;

	elen = b64_encoded_size(len);
	out  = malloc(elen+1);
	out[elen] = '\0';

	for (i=0, j=0; i<len; i+=3, j+=4) {
		v = in[i];
		v = i+1 < len ? v << 8 | in[i+1] : v << 8;
		v = i+2 < len ? v << 8 | in[i+2] : v << 8;

		out[j]   = b64chars[(v >> 18) & 0x3F];
		out[j+1] = b64chars[(v >> 12) & 0x3F];
		if (i+1 < len) {
			out[j+2] = b64chars[(v >> 6) & 0x3F];
		} else {
			out[j+2] = '=';
		}
		if (i+2 < len) {
			out[j+3] = b64chars[v & 0x3F];
		} else {
			out[j+3] = '=';
		}
	}

	return out;
}

const char* get_process_name_by_pid(const int pid)
{
	char* name = (char*)calloc(1024,sizeof(char));
	if(name){
		sprintf(name, "/proc/%d/cmdline",pid);
		FILE* f = fopen(name,"r");
		if (f) {
			size_t size;
			size = fread(name, sizeof(char), 1024, f);
			if ( size > 0 ) {
				if ( '\n' == name[size-1] )
					name[size-1] = '\0';
			}
			fclose(f);
		}
	}
	return name;
}

int main(int argc, char **argv)
{
	if( argc != 2 ) {
		printf("Error: Source key must be supplied!\n");
		return 1;
	}

	const char *data = argv[1];
	char	   *enc;

	/*
	#include <unistd.h>
	pid_t ppid;
	const char *name_ppid;
	ppid = getppid();
	name_ppid = get_process_name_by_pid(ppid);
	printf("ppid:	%d (%s)\n", ppid, name_ppid);
	if (strcmp(name_ppid, "python3") < 0) {
		printf("Invalid invoker!\n");
		return 1;
	}
	*/

	/*printf("data:	'%s'\n", data);*/

	enc = b64_encode((const unsigned char *)data, strlen(data));
	/*printf("encoded: '%s'\n", enc);*/
	printf("%s", enc);

	free(enc);

	return 0;
}