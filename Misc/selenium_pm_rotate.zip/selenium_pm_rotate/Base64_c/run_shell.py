import subprocess
import time

time.sleep(1)
subprocess.call(["/data/vincent/b64/b64", "12345678"])
time.sleep(2)