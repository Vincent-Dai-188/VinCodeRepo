#include <stdio.h>
#include <stdlib.h>

int assemble_passwd( char *basepw, char *keypw, char *pwstr )
{
	return 0;
}

int main( int argc, char *argv[] )
{
	char	   basepw[32];
	char	   pwstr[32];
	char	   keypw[8];

	memset(basepw, '\0', 32);
	
	sprintf(basepw, "%s", "Master^123456");

	printf("PW_BASE: %s [len=%d]\n", basepw, strlen(basepw));

    return 0;
}
