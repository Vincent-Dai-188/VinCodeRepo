#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

int Cloud_Connect_login()
{
    FILE    *fp;
    char    outinfo[1025];
    char    cmd[256];
    int     iRetCode = 0;
		    
    FILE    *fpp;
    char    *buffer = NULL;
    size_t  bufsize = 0;
    ssize_t line_size;

    fpp = fopen("/data/vincent/AWS/pem/.BTS.sec", "r");
    if (fpp == NULL)
        return -1;

	// ssize_t getline(char **restrict lineptr, size_t *restrict n, FILE *restrict stream);
    // If *lineptr is set to NULL and *n is set 0 before the call, then getline() will allocate a buffer 
	// for storing the line. This buffer should be freed by the user program even if getline() failed.
    line_size = getline(&buffer, &bufsize, fpp);
    fclose(fpp);
    if (line_size != -1) {
		// Remove the possible newline
		if ( buffer[line_size - 1] == '\n') {
             buffer[line_size - 1] = '\0';
        }
	}

    memset(cmd, '\0', 256);
    sprintf(cmd, "/usr/bin/pwsh -Command Connect-AWS -u au6067763@qarft.refinitiv.com -p '%s' \
    -pr a-corporate-preprod -an 320776766695 -rn 'human-role/a204121-Developer' -r us-east-1", buffer);

	free(buffer);

    fp = popen(cmd, "r");
    if (fp == NULL) {
        printf("Failed to run popen command. [errno = %d]\n", errno);
        return -1;
    }

    /* Read the output a buffer at a time - output it. */
    while (! feof(fp)) {
        if (fgets(outinfo, sizeof(outinfo), fp) != NULL) {
            printf("%s", outinfo);
            if ( (! iRetCode) && (strstr(outinfo, "True") != NULL)) {
                iRetCode = 1;
            }
        }
    }

    pclose(fp);

    return iRetCode;
}

int main(int argc, char **argv)
{
    int iRet;

    iRet = Cloud_Connect_login();
    if (iRet != 1) {
        printf("\n*** Failed to login AWS account! ***\n");
        return 1;
    }

    return 0;
}