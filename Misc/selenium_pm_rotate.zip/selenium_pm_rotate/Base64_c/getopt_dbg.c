#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    int opt;
    
    printf("argc = %d\n", argc);
    // put ':' in the starting of the string so that program can
    // distinguish between '?' and ':'
    while((opt = getopt(argc, argv, ":SPMK:")) != -1)
    {
        printf("optind = %d\n", optind);
        switch(opt)
        {
            case 'S':
                printf("option: Sandbox\n");
                break;
            case 'P':
                printf("option: PPE\n");
                break;
            case 'M':
                printf("option: MR_PPE\n");
                break;
            case 'K':
                printf("key: %s\n", optarg);
                break;
            case '?':
                printf("unknown option: %c\n", optopt);
                exit(1);
        }
    }
				
    // optind is for the extra arguments which are not parsed
    for(; optind < argc; optind++) {   
        printf("extra arguments: %s, optind=%d, argc=%d\n", argv[optind], optind, argc);
    }
   
    return 0;
}

/*
c870xdtddes02:/tmp # ./opt_dbg MR 000 -P xx -S -K889
argc = 7
optind = 4
option: PPE
optind = 6
option: Sandbox
optind = 7
key: 889
extra arguments: MR, optind=4, argc=7
extra arguments: 000, optind=5, argc=7
extra arguments: xx, optind=6, argc=7
*/
