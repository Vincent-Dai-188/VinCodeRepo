#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    FILE * fp;
    char * line = NULL;
    size_t len = 0;
    ssize_t rlens;

    fp = fopen("./rcd.dat", "r");
    if (fp == NULL)
        exit(1);

    while ((rlens = getline(&line, &len, fp)) != -1) {
        printf("Retrieved line of length %zu:\n", rlens);
		/* Drop the newline character at the end of line (if any) */
		if (line[rlens - 1] == '\n') 
		{
			line[rlens - 1] = '\0';
			--rlens;
		}
        printf("%s [%zu]\n", line, rlens);
    }

    fclose(fp);
    if (line)
        free(line);
    exit(0);
}