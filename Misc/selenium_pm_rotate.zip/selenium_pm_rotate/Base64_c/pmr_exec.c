#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

int main( int argc, char *argv[] )
{
    FILE *fp;
	const char rootdir[] = "data";
	const char suffpms2[] = "_rotate";
	const char bindir[] = "bin";
	const char verChar = 51;
    char path[1025];
	const char homedir[] = "venv";
	const char pyrunner[] = "python";
	const char pmscript[] = ".pm";
	char pmcmd[64];
	char *keyarg = NULL;

    int opt;

    // put ':' in the starting of the string so that program can
    // distinguish between '?' and ':'
    while((opt = getopt(argc, argv, ":K:")) != -1)
    {
        switch(opt)
        {
            case 'K':
                keyarg = optarg;
                break;
            case '?':
                printf("unknown option: %c\n", optopt);
                exit(1);
        }
    }

	memset(pmcmd, '\0', 64);
	if (keyarg) {
		sprintf(pmcmd, "/%s/%s%c/%s/%s%c /%s/%s%c/%s/%s%s -K%s", rootdir, homedir, verChar, \
			bindir, pyrunner, verChar, rootdir, homedir, verChar, bindir, pmscript, suffpms2, keyarg);
	}
	else {
		sprintf(pmcmd, "/%s/%s%c/%s/%s%c /%s/%s%c/%s/%s%s", rootdir, homedir, verChar, \
			bindir, pyrunner, verChar, rootdir, homedir, verChar, bindir, pmscript, suffpms2);
	}

    /* Open the command for reading. */
    fp = popen(pmcmd, "r");
    if (fp == NULL) {
        printf("Failed to run command. [errno = %d]\n", errno);
        exit(1);
    }

    /* Read the output a line at a time - output it. */
    while (fgets(path, sizeof(path), fp) != NULL) {
        printf("%s", path);
    }

    /* close */
    pclose(fp);

    return 0;
}
