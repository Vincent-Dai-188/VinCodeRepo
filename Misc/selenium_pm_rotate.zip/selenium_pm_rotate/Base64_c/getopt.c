#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

enum ENVINDEX {Sandbox = 0, PPE = 1, MR = 2};

int env_index = 0;

const char *profile[3] = {"tr-fr-sandbox", "tr-fr-preprod", "a-corporate-preprod"};
const char *account[3] = {"015887481462", "608014515287", "320776766695"};
const char *usrrole[3] = {"204618-PowerUser", "a205469-Developer", "a204121-Developer"};

int main(int argc, char *argv[])
{
    int opt;
   
    // put ':' in the starting of the string so that program can
    // distinguish between '?' and ':'
    while((opt = getopt(argc, argv, ":SPMK:")) != -1)
    {
        switch(opt)
        {
            case 'S':
                printf("option: Sandbox\n");
				env_index = Sandbox;
                break;
            case 'P':
                printf("option: PPE\n");
				env_index = PPE;
                break;
            case 'M':
                printf("option: MR_PPE\n");
				env_index = MR;
                break;
            case 'K':
                printf("key: %s\n", optarg);
                break;
            case '?':
                printf("unknown option: %c\n", optopt);
                exit(1);
        }
    }
   
	printf(" - profile: %s\n", profile[env_index]);
	printf(" - account: %s\n", account[env_index]);
	printf(" - usrrole: %s\n", usrrole[env_index]);
				
    // optind is for the extra arguments which are not parsed
    for(; optind < argc; optind++) {   
        printf("extra arguments: %s\n", argv[optind]);
    }
   
    return 0;
}