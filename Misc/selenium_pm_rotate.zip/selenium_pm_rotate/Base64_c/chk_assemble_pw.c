#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

void assemble_passwd( char *basepw, char *keypw, char *pwstr)
{
	char buff_sw[32];
	char *index = NULL;
	int len;

	memset(buff_sw, '\0', 32);
	memcpy(pwstr, basepw, strlen(basepw));

	index = strstr(pwstr, "^");
	if (index) {
		len = strlen(index);
		memcpy(buff_sw, index+1, len-1);
		memset(index, '\0', len);
		memcpy(index, keypw, strlen(keypw));
		memcpy(index+strlen(keypw), buff_sw, strlen(buff_sw));
		printf("%s\n", pwstr);
	}
	else
	{
		printf("'^' not found!\n");
	}
}

int main(int argc, char **argv)
{
	char	basepw[] = "Master^123456";
	char	keypw[] = "XXYZZ";
	char	pwstr[32];
	memset(pwstr, '\0', 32);

	assemble_passwd(basepw, keypw, pwstr);
	/*printf("%s\n", pwstr);*/

	return 0;
}