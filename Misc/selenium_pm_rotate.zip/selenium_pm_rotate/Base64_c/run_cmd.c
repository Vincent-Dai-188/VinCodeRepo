#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

int main( int argc, char *argv[] )
{

    FILE *fp;
    char path[1035];

    /* Open the command for reading. */
    /*fp = popen("/bin/ls /etc/", "r"); */
    fp = popen("cloud-tool-fr --profile tr-fr-sandbox login -u 'mgmt\\m6067763' -p 'FakePass' -a 015887481462 -r 'human-role/204618-PowerUser'", "r");
    if (fp == NULL) {
        printf("Failed to run command. [errno = %d]\n", errno);
        exit(1);
    }

    /* Read the output a line at a time - output it. */
    while (fgets(path, sizeof(path), fp) != NULL) {
        printf("%s", path);
    }

    /* close */
    pclose(fp);

    return 0;
}
