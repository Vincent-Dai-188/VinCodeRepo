#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 \"<CIId1 CIId2 ...>\""
    exit 2
fi

CIs="$@"

echo "$CIs" | grep "ecp:[0-9]-[0-9a-z-]*" &>/dev/null
if [ $? -ne 0 ]; then
    echo "Usage: $0 \"<CIId1 CIId2 ...>\""
    exit 2
fi

for CIId in ${CIs}; do
    retCI=$(getThing $CIId)
	CILabel=$(echo $retCI | jq -r '."@graph"[0]."http://www.w3.org/2000/01/rdf-schema#label"')
    echo -e "\n>> CI: $CIId  \"$CILabel\""
    DEs=$(echo $retCI | jq -r '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasDataElement" | if type=="array" then .[]."@id" else ."@id" end')
    for DEId in $DEs; do
        #echo "  --> $DEId"
        ./traverse_DEs_indent.sh $DEId
    done
done
