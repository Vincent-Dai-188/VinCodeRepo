#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 <Keywrod> [REL_1L_File]"
    exit 2
fi

#Target1LFile="Mod_1L_out_RELs_30_PRS.txt"
Target1LFile="Mod_1L_out_RELs_39_PRS_0721.txt"

Keywd2Chk=$1

if (( $# == 2 )); then
    Target1LFile=$2
fi

ret=$(grep "$Keywd2Chk" "$Target1LFile" | grep -o '^ecp:[^,]*,ecp:[^,]*,[^,]*,relationship' | sort -u)

if [ -n "$ret" ]; then
    echo "$ret" | sed 's/$/,/g'
fi

