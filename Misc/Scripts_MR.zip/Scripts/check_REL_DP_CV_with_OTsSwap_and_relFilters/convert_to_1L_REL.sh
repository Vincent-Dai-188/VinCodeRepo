#!/bin/bash

sourceRELFile=$1
output_File="1L_$sourceRELFile"

egrep '^\[|Check in migration list' ${sourceRELFile} > $output_File
sed -i -e 's/^\[[0-9]\{2,3\}\] //g;s/Check in migration list//g' $output_File
sed -i -z 's/\n\s*>> /^/g' $output_File

echo ">> $output_File:"
cat "$output_File"

