#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 <RELs_check_result_file>"
    exit 2
fi

RAWFILE=$1

OUTPUTFILE="Mod_1L_$RAWFILE"

echo ">> Generate modified file '$OUTPUTFILE' in \"1-line\" format ..."

egrep "^\[|Check in migration list" $RAWFILE > $OUTPUTFILE

sed -i -z -e 's/\[[0-9]\{1,4\}\] //g;s/\n\s*>> /\;/g;s/Check in migration list//g' $OUTPUTFILE

echo "Done."

