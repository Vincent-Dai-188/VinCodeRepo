#!/bin/bash

if (( $# < 1 )); then
	echo "Partition ID must be supplied!"
	exit 1
fi

PT=$1
echo -n "Partition: ${PT} "
./getThing $PT | jq -jr '."@graph"[0] | " From: ", ."https://graph.link/ecp/schema/CDF/hasRelationObjectType"."@id", " To: ", ."https://graph.link/ecp/schema/CDF/hasRelatedObjectType"."@id", "\n"'