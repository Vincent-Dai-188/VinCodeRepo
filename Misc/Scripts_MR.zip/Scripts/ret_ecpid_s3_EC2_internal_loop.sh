#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME [-E <DEV|QA>] [-f] [-i] [-h]"
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))
showEnv=""
chkExist=""

if [ -n "${ENV_GLOBAL}" ]; then
    . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
else
    # DEV Env (default)
    . $WORKDIR/ENV_config/DEV.cfg
fi

while getopts :hifSE: paras
do
    case "$paras" in
        E)
            ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            else  # DEV
                . $WORKDIR/ENV_config/DEV.cfg
            fi
            ;;
        i)  showEnv="true"
            ;;
        f)  chkExist="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***" 1>&2
fi

sn=0
while read ecpid; do
	(( sn += 1 ))
    ecpid_rev=$(echo $ecpid | rev)
    projectId=$(aws s3 ls s3://${S3BUCKET}/${ecpid_rev}/NQuads/2.0.0/)

    if [ -n "${projectId}" ]; then
        if [ -n "${chkExist}" ]; then
            echo "'$ecpid' exists in S3."
        else
            filenm=$(echo $projectId | grep -o "ecp:[0-9]-[0-9a-z]\{8\}-[0-9a-z]\{4\}-[0-9a-z]\{4\}-[0-9a-z]\{4\}-[0-9a-z]\{12\}")
            #echo ">> Copy MR data file '${filenm}' in S3 to /tmp/things_s3/ ..." 1>&2
            aws s3 cp s3://${S3BUCKET}/${ecpid_rev}/NQuads/2.0.0/${filenm} /tmp/things_s3/${ENV}/${ecpid} &>/dev/null
            if [ $? -eq 0 ]; then
                printf "[%04d] $ecpid <S>\n" $sn
            else
                printf "[%04d] $ecpid  X \n" $sn
            fi
            #cat /tmp/things_s3/${ENV}/${ecpid}
        fi
    else
        echo "Not found!"
    fi
done < ECPIDs_QA.lst
