#!/bin/bash

function display_help
{
    echo "Usage: $0 <DP_Id,CV_Id>"
}

if (( $# < 1 )); then
    display_help
    exit 1
fi

DPCV=$1
DP=$(echo "$DPCV" | awk -F',' '{print $1}')
CV=$(echo "$DPCV" | awk -F',' '{print $2}')

if [ -z "$DP" ] || [ -z "$CV" ]; then
    display_help
    exit 1
fi

#printf "{ DP,CV: %s }\n" "${DP}" "${CV}"
echo "- DP: $DP"
thing_DP=$(./getThing $DP)
if [ $? -eq 0 ] ; then
    echo "$thing_DP" | jq -rj '."@graph"[0] | "  - enrichmentEnabled: ", ."https://graph.link/ecp/schema/CDF/enrichmentEnabled", "\n"'
else
    echo "- DP: None"
    exit 2
fi

StoreMap=$(./sparql_get_StoreMaps_by_DP-CV.sh ${DP} ${CV} | jq -r ".results.bindings[].map.value")
if [ -z "${StoreMap}" ]; then
    echo "*** No StoreMap found! ***"
    exit 2
fi

for SMitem in $StoreMap; do
    echo "- StoreMap: $SMitem"
    ret=$(./getThing $SMitem)
    if [ $? -eq 0 ] ; then
        echo -n "  - Store: "
        ST=$(echo "$ret" | jq -r '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasStore"."@id"')
        echo "$ST"
        thing_ST=$(./getThing $ST)
        if [ $? -eq 0 ] ; then
            echo "$thing_ST" | jq -rj '."@graph"[0] | "    - isAlternateUpdateStreamEnabled: ", ."https://graph.link/ecp/schema/CDF/isAlternateUpdateStreamEnabled", "\n    - isUpdateStreamEnabled: ", ."https://graph.link/ecp/schema/CDF/isUpdateStreamEnabled", "\n"'
        fi
    else
       echo "  - Store: None"
    fi
done
