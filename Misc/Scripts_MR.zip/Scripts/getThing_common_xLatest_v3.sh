#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <ecp-id> [-i] [-S] [-L] [-D] [-h] [-E <DEV|QA|Prod|Sandbox>] [-T <json|nquads|trig>] [-C]"
}

function refetch_token
{
    # Outputs to stderr to avoid potential parse error when using jq
    echo "Re-Fetch Token ..." 1>&2
    # -H 'Content-Length: 0' (To avoid: Content-Length missing for POST or PUT requests)
    token=$(curl -s -X POST \
        -H "Key: ${uKey}" \
        -H "SecretKey: ${SecretKey}" \
        -H "x-api-key: ${APIKey}" \
        -H "Content-Length: 0" \
        ${HOST}/auth)

    if [ -z "$token" ]; then
        echo "*** Failed to obtain token! ***"
        exit 1
    fi
    #echo -e "\nNew token:\n${token}\n"
    date +%s > $TOKENFILE
    echo $token >> $TOKENFILE
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

# Accept: JSON-LD (default)
CONTTYPE="vnd.ecp.registry+json"

CacheCtrl=""
showEnv=""
SKIPTOKEN=""
CF_EARLIER=""
SUFFIX=""

if (( $# >= 1 )); then
    ECPID=$1
    shift
else
    display_help
    exit 1
fi

while getopts :hiCLDSE:T: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            elif [ "${ENV}" = "DEV" ]; then
                . $WORKDIR/ENV_config/DEV.cfg
            elif [ "${ENV}" = "Prod" ]; then
                . $WORKDIR/ENV_config/Prod.cfg
            else  # Sandbox
                . $WORKDIR/ENV_config/Sandbox.cfg
            fi
            ;;
        T)  CONTTYPE=${OPTARG}
            if [ "${CONTTYPE}" = "nquads" ]; then
                CONTTYPE="vnd.ecp.registry+nquads"
                SUFFIX=".quads"
            elif [ "${CONTTYPE}" = "trig" ]; then
                CONTTYPE="vnd.ecp.registry+trig"
                SUFFIX=".trig"
            fi
            ;;
        C)  CacheCtrl="Cache-Control: no-cache"
            ;;
        D)  CF_EARLIER="?cf=1990-01-01T00:00:00.000Z"
            ;;
        L)  xLatest="x-latest: true"
            ;;
        S)  SKIPTOKEN="true"    # Retrieve token from TOKEN_FILE without checking expiration period
            ;;
        i)  showEnv="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
    else
        # QA Env (default)
        . $WORKDIR/ENV_config/QA.cfg
    fi
fi

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***" 1>&2
fi

TOKENFILE="/tmp/.token_MR_${ENV}.aut"

if [ -f $TOKENFILE ]; then
    if [ -n "${SKIPTOKEN}" ]; then
        token=$(tail -n 1 $TOKENFILE)
    else
        tokenbuf="$(cat ${TOKENFILE})"
        tmstamp=$(echo "$tokenbuf" | head -n 1)
        curstamp=$(date +%s)
        if (( curstamp - tmstamp > 900 )); then
            refetch_token
        else
            token=$(echo "$tokenbuf" | tail -n 1)
        fi
    fi
else
    refetch_token
fi

if [ -n "${CacheCtrl}" ] && [ -n "${xLatest}" ]; then
    echo "*** ${CacheCtrl} ${xLatest} ***" 1>&2
    res=$(curl -w "Status_Code: %{http_code}\n" -s -X GET ${HOST}/metadata/thing/${ECPID}${CF_EARLIER} -H "Accept: application/${CONTTYPE};api-version=1" -H "x-api-key: ${APIKey}" -H "Authorization: ${token}" -H  "${CacheCtrl}" -H "${xLatest}")
elif [ -n "${CacheCtrl}" ]; then
    echo "*** ${CacheCtrl} ***" 1>&2
    res=$(curl -w "Status_Code: %{http_code}\n" -s -X GET ${HOST}/metadata/thing/${ECPID}${CF_EARLIER} -H "Accept: application/${CONTTYPE};api-version=1" -H "x-api-key: ${APIKey}" -H "Authorization: ${token}" -H  "${CacheCtrl}")
elif [ -n "${xLatest}" ]; then
    echo "*** ${xLatest} ***" 1>&2
    res=$(curl -w "Status_Code: %{http_code}\n" -s -X GET ${HOST}/metadata/thing/${ECPID}${CF_EARLIER} -H "Accept: application/${CONTTYPE};api-version=1" -H "x-api-key: ${APIKey}" -H "Authorization: ${token}" -H  "${xLatest}")
else
    res=$(curl -w "Status_Code: %{http_code}\n" -s -X GET ${HOST}/metadata/thing/${ECPID}${CF_EARLIER} -H "Accept: application/${CONTTYPE};api-version=1" -H "x-api-key: ${APIKey}" -H "Authorization: ${token}")
fi

staCodeStr=$(echo "$res" | grep -o "Status_Code: [2-5][0-9]\{2\}")
if [ "$staCodeStr" = "Status_Code: 200" ]; then
    #echo "$staCodeStr" 1>&2
    retThing=$(echo "$res" | sed -e 's/Status_Code: 200//;/^$/d')
	if [ -d "/tmp/things_redis/${ENV}/" ]; then
		echo "$retThing" > /tmp/things_redis/${ENV}/${ECPID}${SUFFIX}
	fi
    echo "$retThing"
elif [ -n "$staCodeStr" ]; then
    echo "$staCodeStr" 1>&2
    # Display raw error message
    retThing=$(echo "$res" | sed -e 's/Status_Code: [2-5][0-9]\{2\}//;/^$/d')
    echo "$retThing"
    # Remove exsiting files of the same ECPID
    ls /tmp/things_redis/${ENV}/${ECPID}* &> /dev/null
    if [ $? -eq 0 ]; then
        rm -f /tmp/things_redis/${ENV}/${ECPID}*
    fi
    exit 1
else
    echo "$res"
    exit 2
fi
