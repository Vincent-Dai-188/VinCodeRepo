#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 <OT_Id>"
    exit 1
fi

OTId=$1

sed "s/%OT_ID%/${OTId}/" query_CIs_by_OT.tpl > query_CIs_by_OT.sparql

#./sparql_query_common query_CIs_by_OT.sparql | jq -r '.results.bindings[].CI.value'
retCIs=$(./sparql_query_common query_CIs_by_OT.sparql | jq -r '.results.bindings[].CI.value')
if [ -n "$retCIs" ]; then
    for CIId in $retCIs; do
        CILabel=$(getLabel $CIId)
        echo "${CIId}  \"${CILabel}\""
   done
else
    echo "Not found."
fi
