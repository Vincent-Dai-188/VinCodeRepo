#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <-D|-C> <ecp-id> [-i] [-h] [-E <DEV|QA|Prod|Sandbox>]"
}

function refetch_token
{
    # Outputs to stderr to avoid potential parse error when using jq
    echo "Re-Fetch Token ..." 1>&2
    # -H 'Content-Length: 0' (To avoid: Content-Length missing for POST or PUT requests)
    token=$(curl -s -X POST \
        -H "Key: ${uKey}" \
        -H "SecretKey: ${SecretKey}" \
        -H "x-api-key: ${APIKey}" \
        -H "Content-Length: 0" \
        ${HOST}/auth)

    if [ -z "$token" ]; then
        echo "*** Failed to obtain token! ***"
        exit 1
    fi
    #echo -e "\nNew token:\n${token}\n"
    date +%s > $TOKENFILE
    echo $token >> $TOKENFILE
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

showEnv=""
SUFFIX=""

if (( $# >= 2 )); then
    OBJECT=$1
    ECPID=$2
    shift 2
else
    display_help
    exit 1
fi

if [ "${OBJECT}" = "-D" ]; then
    OBJECT="distributionpair"
else
    OBJECT="contentitem"
fi

while getopts :hiSE:T: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            elif [ "${ENV}" = "DEV" ]; then
                . $WORKDIR/ENV_config/DEV.cfg
            elif [ "${ENV}" = "Prod" ]; then
                . $WORKDIR/ENV_config/Prod.cfg
            else  # Sandbox
                . $WORKDIR/ENV_config/Sandbox.cfg
            fi
            ;;
        T)  CONTTYPE=${OPTARG}
            if [ "${CONTTYPE}" = "nquads" ]; then
                CONTTYPE="vnd.ecp.registry+nquads"
                SUFFIX=".quads"
            elif [ "${CONTTYPE}" = "trig" ]; then
                CONTTYPE="vnd.ecp.registry+trig"
                SUFFIX=".trig"
            fi
            ;;
        i)  showEnv="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
    else
        # QA Env (default)
        . $WORKDIR/ENV_config/QA.cfg
    fi
fi

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***" 1>&2
fi

TOKENFILE="/tmp/.token_MR_${ENV}.aut"

if [ -f $TOKENFILE ]; then
    if [ -n "${SKIPTOKEN}" ]; then
        token=$(tail -n 1 $TOKENFILE)
    else
        tokenbuf="$(cat ${TOKENFILE})"
        tmstamp=$(echo "$tokenbuf" | head -n 1)
        curstamp=$(date +%s)
        if (( curstamp - tmstamp > 900 )); then
            refetch_token
        else
            token=$(echo "$tokenbuf" | tail -n 1)
        fi
    fi
else
    refetch_token
fi

res=$(curl -s -X GET ${HOST}/metadata/dataset/${OBJECT}/${ECPID} -H "Accept: application/json;api-version=1" -H "x-api-key: ${APIKey}" -H "Authorization: ${token}")

echo "$res" | jq .

