#!/bin/bash

S3BUCKET="a204121-content-ecpmeta-qa-use1"

ECPID=$1
REV_ECPID=$(echo "$ECPID" | rev)

ret=$(aws --profile a-corporate-preprod s3 ls s3://${S3BUCKET}/${REV_ECPID}/NQuads/2.0.0/)
if [ $? -eq 0 ]; then
	#echo -n "ProjectID: "
	echo "$ret" | grep -o 'ecp:[^ ]*'
fi
