#!/bin/bash

function print_indent
{
    printf '%*s' $nInt
}

function traverse_DE    #ECP-Id #Params
{
    ECPID=$1
    shift
    if (( $# >= 1 )); then  # Transfer ENV (optional)
        retObj=$(getThing $ECPID $@)
    else
        retObj=$(getThing $ECPID)
    fi

    echo $retObj | egrep -i "not found|No matching data" &>/dev/null
    if [ $? -eq 0 ]; then
        print_indent
        #echo "*** $retObj ***"
        echo "$ECPID - (X)"
    else
        graphObj=$(echo $retObj | jq '."@graph"[] | ."@graph"')
        if [ "$graphObj" = "null" ]; then
            thingObj=$(echo $retObj | jq '."@graph"[]')
        else    # "@graph" array
            thingObj=$(echo $graphObj | jq '.[]')
        fi
    
        #echo $thingObj | grep '"@type"\s*: "https://graph.link/ecp/schema/CDF/SimpleDataElement"' &>/dev/null
		echo $thingObj | grep '"https://graph.link/ecp/schema/CDF/SimpleDataElement"' &>/dev/null
        if [ $? -eq 0 ]; then
            print_indent
            #echo "$ECPID - hasSimpleDataElement"
            DEType=$(echo $thingObj | jq -r '."https://graph.link/ecp/schema/CDF/hasSimpleDatatype"."@id"')
			DEType=$(echo ${DEType} | sed 's,https://graph.link/ecp/schema/,,')
            echo "$ECPID (${DEType}) - <>"
        else
            childDE=$(echo $thingObj | jq -r '."https://graph.link/ecp/schema/CDF/hasChildDataElement"')
            if [ "$childDE" != "null" ]; then
                DEType=$(echo $thingObj | grep -o '"@type"\s*: "https://graph.link/ecp/schema/CDF/[a-zA-Z]*DataElement"' \
                    | grep -o "[a-zA-Z]*DataElement" | sort -u)
                childEcpids=$(echo $childDE | jq -r 'if type=="array" then .[]."@id" else ."@id" end' | sort -u)
                # if [ "${childDE:0:1}" = "[" ]; then
                    # childEcpids=$(echo $childDE | jq -r '.[]."@id"')
                # else
                    # childEcpids=$(echo $childDE | jq -r '."@id"')
                # fi
                print_indent
                echo "$ECPID - ${DEType}"
                print_indent
                echo "{"
                (( nInt += 2 ))
                for childID in $childEcpids; do
                    traverse_DE $childID $nInt
                done
                (( nInt -= 2 ))
                print_indent
                echo "}"
            else
                echo "$ECPID - 'CDF/hasChildDataElement' not found!"
            fi
        fi
    fi
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 1 )); then
    echo "Usage: $UTILNAME <DataElement_ECPId> [\"-E <DEV|QA|Sandbox>\"]"
    exit 1
fi

nInt=0

traverse_DE $@
