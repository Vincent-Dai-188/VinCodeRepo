#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 \"<CIId_list_file>\""
    exit 2
fi

CILISTFILE=$1

sn=0
while read CIId; do
    (( sn += 1 ))
	CIJSON=$(getThing $CIId)
	CILabel=$(echo "$CIJSON" | jq -r -j '."@graph"[0]."http://www.w3.org/2000/01/rdf-schema#label"')
    printf "\n[%02d] CI: %s (\"%s\")\n" $sn $CIId $CILabel
    DEs=$(echo "$CIJSON" | jq -r '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasDataElement" | if type=="array" then .[]."@id" else ."@id" end')
    for DEId in $DEs; do
        #echo "  --> $DEId"
        ./traverse_DEs_indent.sh $DEId
    done
done < ${CILISTFILE}
