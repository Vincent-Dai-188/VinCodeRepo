#!/bin/bash

Host="https://registry-ecp-devs.a-corporate-preprod.aws-int.thomsonreuters.com"
ProjectID="ecp:8-db875efd-bde6-4e0e-82b9-478b4a8d94ee"
XAPIKey="pVw5gWw9d48wKssfe7PV41O61b7SsHDk9AjYQqFA"

CONTTYPE="vnd.ecp.registry+json"

token=$(curl -s -X POST \
    -H 'Key: u6025979' \
    -H 'SecretKey: Rjr>NJgR9\BD.V-T' \
    -H 'x-api-key: gDtAPG68Im8ObNx6G0ZyG4PbYSyzfpjt3qT8VN20' \
    ${Host}/auth)

echo $token

sn=0
while read THINGID;
do
    (( sn += 1 ))
    printf "[%03d]\n" ${sn}
    curl -X DELETE ${host}/metadata/project/${ProjectID}/thing/${THINGID}?setCurrentTo=true -H "Content-Type: application/${CONTTYPE}" -H "x-api-key: ${XAPIKey}" -H "Authorization: ${token}" -H 'api-version: 2'
done < ./ecpids.lst

#command line sample:
#curl -X DELETE https://registry-ecp-devs.a-corporate-preprod.aws-int.thomsonreuters.com/metadata/project/ecp:8-db875efd-bde6-4e0e-82b9-478b4a8d94ee/thing/ecp:9-dbfafed2-5ff8-44e9-9bcf-27d3ebf776d4 -H 'Content-Type: application/vnd.ecp.registry+json' -H 'x-api-key: gDtAPG68Im8ObNx6G0ZyG4PbYSyzfpjt3qT8VN20' -H 'Authorization: <token>' -H 'api-version: 2'