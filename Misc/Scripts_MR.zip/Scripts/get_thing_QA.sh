#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <ecp-id> [-h|-T <json|nquads|trig>]"
}

function refetch_token
{
    # Outputs to stderr to avoid potential parse error when using jq
    echo "Re-Fetch Token ..." 1>&2
    # -H 'Content-Length: 0' (To avoid: Content-Length missing for POST or PUT requests)
    token=$(curl -s -X POST \
        -H "Key: ${uKey}" \
        -H "SecretKey: ${SecretKey}" \
        -H "x-api-key: ${APIKey}" \
        -H "Content-Length: 0" \
        ${HOST}/auth)

    if [ -z "$token" ]; then
        echo "*** Failed to obtain token! ***"
        exit 1
    fi
    #echo -e "\nNew token:\n${token}\n"
    date +%s > $TOKENFILE
    echo $token >> $TOKENFILE
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))
TOKENFILE="/tmp/.token_MR_QA.aut"

# QA Env (default)
HOST="https://ecp-registry-qa-int.thomsonreuters.com"
uKey="u6064334"
SecretKey="M\$FFXR_tH8b?Y~9!"
APIKey="pVw5gWw9d48wKssfe7PV41O61b7SsHDk9AjYQqFA"

# Accept: JSON-LD (default)
CONTTYPE="vnd.ecp.registry+json"

if (( $# >= 1 )); then
    ECPID=$1
    shift
else
    display_help
    exit 1
fi

while getopts :hT: paras
do
    case "$paras" in
        T)  CONTTYPE=${OPTARG}
            if [ "${CONTTYPE}" = "nquads" ]; then
                CONTTYPE="vnd.ecp.registry+nquads"
            elif [ "${CONTTYPE}" = "trig" ]; then
                CONTTYPE="vnd.ecp.registry+trig"
            fi
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -f $TOKENFILE ]; then
    tmstamp=$(head -n 1 $TOKENFILE)
    curstamp=$(date +%s)
    if (( curstamp - tmstamp > 900 )); then
        refetch_token
    else
        token=$(tail -n 1 $TOKENFILE)
    fi
else
    refetch_token
fi

curl -s -X GET ${HOST}/metadata/thing/${ECPID} -H "Accept: application/${CONTTYPE};api-version=1" -H "x-api-key: ${APIKey}" -H "Authorization: ${token}"
