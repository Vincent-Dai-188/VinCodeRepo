#!/bin/bash

function ret_parentIDs_by_DE   # DE_Id
{
    DE_Id=$1
    sed "s/%DE_ID%/${DE_Id}/" $TplFile > $SparqlFile

    # Convert sparql in plain text to URL
    QUERYSPL=`./URL_convert_SparQL.sh "$(cat ${SparqlFile})"`

    ret=$(curl -s -X GET ${SPARQL_HOST}/metadata/sparql?query="${QUERYSPL}" -H "Accept: application/sparql-results+json" | jq -rj '."results"."bindings"[] | ."sub"."value", ",", ."rdfType"."value", "\n"' | sed 's,https://graph.link/ecp/schema/CDF/,,')
	if [ -n "$ret" ]; then
		echo "$ret" 
	else
		echo "null" 
	fi
}

function ret_CIs_by_DE
{
	local DEId=$1

	ret=$(ret_parentIDs_by_DE $DEId)
	if [ "$ret" != "null" ]; then
		for item in $ret; do
			echo "$item" | grep "ContentItem" &> /dev/null
			if [ $? -eq 0 ]; then
				echo ">> $item"
			else
				#echo "--> Non-CI DE: $item"
				pDEId=$(echo "$item" | awk -F',' '{print $1}')
				ret_CIs_by_DE $pDEId
			fi
		done
	fi
}

SPARQL_HOST="http://a204121qanlb-2588124a14c0d9c1.elb.us-east-1.amazonaws.com"
TplFile="query_parentIds_by_DEId.tpl"
SparqlFile="query_parentIds_by_DEId.sparql"

ret_CIs_by_DE $1
