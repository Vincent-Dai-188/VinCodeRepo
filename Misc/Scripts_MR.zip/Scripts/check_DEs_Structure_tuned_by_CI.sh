#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 \"<CIId1 CIId2 ...>\""
    exit 2
fi

CIs="$@"

RAMROOT="/tmp/ramdisk"

echo "$CIs" | grep "ecp:[0-9]-[0-9a-z-]*" &>/dev/null
if [ $? -ne 0 ]; then
    echo "Usage: $0 \"<CIId1 CIId2 ...>\""
    exit 2
fi

rm -f ${RAMROOT}/DEram_*.json

for CIId in ${CIs}; do
    retCI=$(getThing $CIId)
	CILabel=$(echo $retCI | jq -r '."@graph"[0]."http://www.w3.org/2000/01/rdf-schema#label"')
	# retrieve ContainerTypeId via .hasContainerType or .hasContainer property
	ContainerTypeId=$(echo "$retCI" | jq -r '."@graph"[0] | if ."https://graph.link/ecp/schema/CDF/hasContainerType"."@id"? then ."https://graph.link/ecp/schema/CDF/hasContainerType"."@id" else ."https://graph.link/ecp/schema/CDF/hasContainer"."@id" end')
	if [ "$ContainerTypeId" = "null" ]; then
		ContainerTypeLabel="Metadata(D)"
	else
		ContainerTypeLabel=$(getThing $ContainerTypeId | jq -r '."@graph"[0]."http://www.w3.org/2000/01/rdf-schema#label"' | sed 's/ Container//')
	fi
    echo -e "\n>> CI: $CIId  \"$CILabel\"  (${ContainerTypeLabel})"
    DEs_Raw=$(echo $retCI | jq -r '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasDataElement" | if type=="array" then .[]."@id" else ."@id" end')

	# Get raw DEs list re-ordered: SimpleDataElements first
	DEs_Ord=""
	for DEId in $DEs_Raw; do
		FnDE="DEram_${DEId:4:38}.json"
		getThing $DEId > "${RAMROOT}/${FnDE}"
		grep '"https://graph.link/ecp/schema/CDF/SimpleDataElement"' "${RAMROOT}/${FnDE}" &>/dev/null
		if [ $? -eq 0 ]; then
			DEs_Ord="${DEId} ${DEs_Ord}"
		else
			DEs_Ord="${DEs_Ord} ${DEId}"
		fi
	done

    for DEId in $DEs_Ord; do
        #echo "  --> $DEId"
        ./traverse_DEs_tuned_for_KEY_indent.sh $DEId
    done
done
