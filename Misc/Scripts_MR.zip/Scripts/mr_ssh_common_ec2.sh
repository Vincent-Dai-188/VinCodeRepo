#!/bin/bash

# Check login status
function check_login_status_aws
{
    ret=$(aws --profile ${PROFILE} s3 ls s3://a204121-vincent-test 2>&1)
    ret_code=$?
    if [ $ret_code -ne 0 ]; then
        echo $ret | grep "ExpiredToken" &>/dev/null
        if [ $? -eq 0 ]; then
            echo "- Token Expired! Re-login ..."
            /data/vincent/AWS/login_aws -M
            if [ $? -ne 0 ]; then
                exit 2
            fi
            echo
        else
            echo "### Failed to login AWS account. (errCode=$ret_code) ###"
            exit 1
        fi
    fi
}

function usage_help
{
    echo "Usage: $0 [-e|-w|-K] [-I PRIVATE-IP] [-h]"
}

PROFILE="a-corporate-preprod"

check_login_status_aws

EC2IP=""
VV=""

while getopts :AewMhI:K: paras
do
    case "$paras" in
        e)  EC2IP="10.49.117.146"
            echo "*** Access EC2_edge_MR_Vincent ($EC2IP) ***"
            ;;
        w)  EC2IP="10.49.116.73"
            echo "*** Access ec2_webserver_mr ($EC2IP) ***"
            ;;
        K)  EXTKEY=${OPTARG}
            ;;
        I)  EC2IP=${OPTARG}
            echo "*** private-ip of EC2 instance : $EC2IP ***"
            ;;
        h)  usage_help
            exit 0
            ;;
        *)  usage_help
            exit 2
            ;;
    esac
done

shift $((OPTIND -1))

if [ -z "$EC2IP" ]; then
    EC2IP="10.49.117.146"
    echo "*** Access EC2_edge_MR_Vincent ($EC2IP) ***"
fi

cloud-tool-fr --profile ${PROFILE} $VV ssh --private-ip ${EC2IP}
