#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <ECP-Id> [-E <DEV|QA|Sandbox>] [-f] [-i] [-h]"
}

if (( $# < 1 )); then
    echo "ECPID must be provided!"
    exit 1
fi

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))
showEnv=""
chkExist=""
SKIPTOKEN=""

ecpid=$1
shift

while getopts :hifE: paras
do
    case "$paras" in
        E)
            ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            elif [ "${ENV}" = "Sandbox" ]; then
                . $WORKDIR/ENV_config/Sandbox.cfg
            else  # DEV
                . $WORKDIR/ENV_config/DEV.cfg
            fi
            ;;
        i)  showEnv="true"
            ;;
        f)  chkExist="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
    else
        # DEV Env (default)
        . $WORKDIR/ENV_config/DEV.cfg
    fi
fi

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***" 1>&2
fi

ecpid_rev=$(echo $ecpid | rev)

for i in {1..2}; do
    retS3Str=$(aws --profile ${AWSPROFILE} s3 ls s3://${S3BUCKET}/${ecpid_rev}/NQuads/2.0.0/)
    ret_code=$?
    case $ret_code in
        0)  # Normal
            if [ -n "${chkExist}" ]; then
                echo "Exists."
                break
            else
                projectId=$(echo $retS3Str | grep -o "ecp:[0-9]-[0-9a-z]\{8\}-[0-9a-z]\{4\}-[0-9a-z]\{4\}-[0-9a-z]\{4\}-[0-9a-z]\{12\}")
                #echo ">> Copy MR data file '${projectId}' in S3 to /tmp/things_s3/ ..." 1>&2
                aws --profile ${AWSPROFILE} s3 cp s3://${S3BUCKET}/${ecpid_rev}/NQuads/2.0.0/${projectId} /tmp/things_s3/${ENV}/${ecpid} 1>&2
                cat /tmp/things_s3/${ENV}/${ecpid}
                break
            fi ;;
        1)  # Not found
            echo "Not found!"
            # Remove exsiting file of the same ECPID
            if [ -f "/tmp/things_s3/${ENV}/${ecpid}" ]; then
                rm -f /tmp/things_s3/${ENV}/${ecpid}
            fi
            exit 1 ;;
        255) # AWS Token Expired
            echo "- Token Expired! Re-login ..." 1>&2
            ${WORKDIR}/login_aws ${ENVOPT} 1>&2
            if [ $? -ne 0 ]; then
                echo "### Can not login AWS account! ###"
                exit 255
            fi
            continue ;;
        *)  # Unknown error
            echo "### Failed to access S3. (errCode=$ret_code) ###"
            exit 9 ;;
    esac
done

