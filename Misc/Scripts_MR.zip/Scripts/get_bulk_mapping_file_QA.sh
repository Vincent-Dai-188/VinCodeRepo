#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 <mapping_file_name|LIST>"
    exit 1
fi

S3BUCKET="a204121-content-ecpmeta-qa-use1"
ENVTAG="QA"

M_FILE=$1

if [ "${M_FILE}" = "LIST" ]; then
    aws --profile a-corporate-preprod s3 ls s3://${S3BUCKET}/bulk/mapping/
else
    echo "${M_FILE}" | grep '\.ecpIds' &>/dev/null
    if [ $? -ne 0 ]; then
        M_FILE="${M_FILE}.ecpIds"
    fi
    echo ">> Copy Bulk-mapping file '${M_FILE}' from S3://${S3BUCKET} to ./Bulk_mapping_files/${ENVTAG}/ ..."
    aws --profile a-corporate-preprod s3 cp s3://${S3BUCKET}/bulk/mapping/${M_FILE} /data/vincent/MR/Bulk_mapping_files/${ENVTAG}/
fi
