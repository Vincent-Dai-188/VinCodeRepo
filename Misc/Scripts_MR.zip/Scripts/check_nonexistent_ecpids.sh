#!/bin/bash

sourFile=$1

ENV=""
if (( $# == 2 )); then
    ENV=$2
fi

while read ECPID; do
    ret=$(getThing $ECPID ${ENV})
    echo $ret | egrep "not found|No matching data found" &>/dev/null
    if [ $? -eq 0 ]; then
        echo "- $ECPID    (X)"
    else
        echo "- $ECPID"
    fi
done < $sourFile
