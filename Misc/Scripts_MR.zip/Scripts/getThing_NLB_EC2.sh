#!/bin/bash

export http_proxy="webproxy.far.corp.services:80"
export https_proxy="webproxy.far.corp.services:80"
#export http_proxy="webproxy.hzl.corp.services:80"
#export https_proxy="webproxy.hzl.corp.services:80"

function display_help
{
    echo "Usage: $UTILNAME <ecp-id> [-i] [-L] [-D] [-M] [-C] [-h] [-E <DEV|QA>] [-T <json|nquads|trig>]"
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

# Accept: JSON-LD (default)
CONTTYPE="vnd.ecp.registry+json"

CacheCtrl=""
showEnv=""
CF_EARLIER=""
SUFFIX=""

if (( $# >= 1 )); then
    ECPID=$1
    shift
else
    display_help
    exit 1
fi

ShowMainInfo=""
while getopts :hiMCLDE:T: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            else
                . $WORKDIR/ENV_config/DEV.cfg
            fi
            ;;
        T)  CONTTYPE=${OPTARG}
            if [ "${CONTTYPE}" = "nquads" ]; then
                CONTTYPE="vnd.ecp.registry+nquads"
                SUFFIX=".quads"
            elif [ "${CONTTYPE}" = "trig" ]; then
                CONTTYPE="vnd.ecp.registry+trig"
                SUFFIX=".trig"
            fi
            ;;
        M)  ShowMainInfo="true"
            ;;
        C)  CacheCtrl="Cache-Control: no-cache"
            ;;
        D)  CF_EARLIER="?cf=1990-01-01T00:00:00.000Z"
            ;;
        L)  xLatest="x-latest: true"
            ;;
        i)  showEnv="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
    else
        # QA Env (default)
        . $WORKDIR/ENV_config/QA.cfg
    fi
fi

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***" 1>&2
fi

if [ -n "${CacheCtrl}" ] && [ -n "${xLatest}" ]; then
    echo "*** ${CacheCtrl} ${xLatest} ***" 1>&2
    res=$(curl -w "\nStatus_Code: %{http_code}\n" -s -X GET ${SPARQL_HOST}/metadata/thing/${ECPID}${CF_EARLIER} -H "Accept: application/${CONTTYPE};api-version=1" -H "x-api-key: ${APIKey}" -H "Authorization: ${token}" -H "${CacheCtrl}" -H "${xLatest}")
elif [ -n "${CacheCtrl}" ]; then
    echo "*** ${CacheCtrl} ***" 1>&2
    res=$(curl -w "\nStatus_Code: %{http_code}\n" -s -X GET ${SPARQL_HOST}/metadata/thing/${ECPID}${CF_EARLIER} -H "Accept: application/${CONTTYPE};api-version=1" -H "x-api-key: ${APIKey}" -H "Authorization: ${token}" -H  "${CacheCtrl}")
elif [ -n "${xLatest}" ]; then
    echo "*** ${xLatest} ***" 1>&2
    res=$(curl -w "\nStatus_Code: %{http_code}\n" -s -X GET ${SPARQL_HOST}/metadata/thing/${ECPID}${CF_EARLIER} -H "Accept: application/${CONTTYPE};api-version=1" -H "x-api-key: ${APIKey}" -H "Authorization: ${token}" -H  "${xLatest}")
else
    res=$(curl -w "\nStatus_Code: %{http_code}\n" -s -X GET ${SPARQL_HOST}/metadata/thing/${ECPID}${CF_EARLIER} -H "Accept: application/${CONTTYPE};api-version=1" -H "x-api-key: ${APIKey}" -H "Authorization: ${token}")
fi

staCode=$(echo "$res" | tail -n 1 | grep -o "[2-5][0-9]\{2\}")
if (( staCode == 200 )); then
    #echo "$staCode" 1>&2
    retThing=$(echo "$res" | sed '$d')
    if [ -n "${ShowMainInfo}" ]; then
        echo "$retThing" | jq -rj '."@graph"[0] | "Type: ", ."@type", ", Label: ", ."http://www.w3.org/2000/01/rdf-schema#label", ", Desc: ", ."http://purl.org/dc/elements/1.1/description", "\n"'
    else
        echo "$retThing"
    fi
elif [ -n "$staCode" ]; then
    #echo "Status_Code: $staCode" 1>&2
    # Display raw error message
    if [ "$staCode" = "404" ]; then
        echo "No matching data found (404)"
    else
        retThing=$(echo "$res" | sed '$d')
        echo "$retThing"
    fi
    exit 1
else
    echo "$res"
    exit 2
fi
