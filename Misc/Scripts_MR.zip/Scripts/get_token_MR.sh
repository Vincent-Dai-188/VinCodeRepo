#!/bin/bash

http_proxy="10.40.14.55:80"
host="http://a204618junjielb-324114725.us-east-1.elb.amazonaws.com"
ProjectID="ecp:8-aede0344-f3e2-474c-bd9d-9c872cabcdef"
#newecpid="ecp:6-abcd1234-e8c7-323f-fe8b-6d987gabcdef"

token=$(curl -s -X POST \
    -H 'Key: ecpregistry' \
    -H 'SecretKey: s2MK2d@uE' \
    -H 'x-api-key: gDtAPG68Im8ObNx6G0ZyG4PbYSyzfpjt3qT8VN20' \
    ${host}/auth)

echo -e "token:\n${token}"

# cmd="curl -X PUT \
    # ${host}/metadata/project/${ProjectID}/thing/${newecpid} \
    # -H 'Accept: application/vnd.ecp.registry+json' \
    # -H 'Authorization: ${token}' \
    # -H 'Content-Type: application/vnd.ecp.registry+json' \
    # -H 'x-api-key: ${APIKey}'"  # \
    # #-d '{"id":"${newecpid}","ontology":{"ontologyUri":"https://graph.link/ecp/1.0/schema/CDF","ontologyVersion":"2.0.0"},"description":{"value":"some description for bj e2e"},"label":{"value":"e2e-bj"},"type":{"value":"https://graph.link/ecp/schema/registry/Thing"},"jsonContext":{"description":"http://purl.org/dc/elements/1.1/description","label":"http://www.w3.org/2000/01/rdf-schema#label","type":"http://www.w3.org/1999/02/22-rdf-syntax-ns#type"}}'
    
echo -e "CMD:\n$CMD"
