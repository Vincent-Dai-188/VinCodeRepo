#!/bin/bash

APIKey="gDtAPG68Im8ObNx6G0ZyG4PbYSyzfpjt3qT8VN20"
http_proxy="10.40.14.55:80"
host="http://a204618junjielb-324114725.us-east-1.elb.amazonaws.com"
ProjectID="ecp:8-aede0344-f3e2-474c-bd9d-9c872cabcdef"
newecpid="ecp:6-abcd1234-e8c7-323f-fe8b-6d987gabcdef"

token="eyJraWQiOiJnU2xOeVZiQmFpSDNNaXJpa2oxdWlRNlwvVCtDN1l5R2RYWTVhcHdXRmVqMD0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJjNzE4NzA1Yy1mY2M1LTQ4MTAtYjZjZS05ODUyM2YyYWRjZDAiLCJhdWQiOiIyMDlkOTg4ZDRzNnJpNzllODhuajNyZ25xcyIsImVtYWlsX3ZlcmlmaWVkIjpmYWxzZSwiZXZlbnRfaWQiOiI4MTY5NDlkNS04MTk1LTQ1ZTYtOGExMC02MzViNWMyMGY1NGQiLCJ0b2tlbl91c2UiOiJpZCIsImF1dGhfdGltZSI6MTU2Njk3NjQ2MCwiaXNzIjoiaHR0cHM6XC9cL2NvZ25pdG8taWRwLnVzLWVhc3QtMS5hbWF6b25hd3MuY29tXC91cy1lYXN0LTFfSTM2UXpzNEdJIiwiY29nbml0bzp1c2VybmFtZSI6ImVjcHJlZ2lzdHJ5IiwiZXhwIjoxNTY2OTgwMDYwLCJnaXZlbl9uYW1lIjoiZWNwcmVnaXN0cnkiLCJpYXQiOjE1NjY5NzY0NjAsImZhbWlseV9uYW1lIjoiZWNwcmVnaXN0cnkifQ.TtaK41GFOgsBIMdy4s3nR6H19zbKkTSDNDep4kaziCrfObZQp3l7LTdtPqOyUyTrg24gwLcmdBOBdLfxjkY-31B64si6rp-lCZCtb6YQolxBIOQ_L8kqVm_l9CUQeFZL5f71M0n0Eg8GYziQMycxWaRYRY4HApvk7ofN3hV5DNrrlnMIHdhuOZi7YrXMMtVEYAAX8m6nd-C2yk8zjaEgnXuLXVnUhtT0xEs83dXNxL0uX3Tk0v27pSwp5Xdh8XlWk9AA9xku6uzVfSES4BiMA3ZmEwjJxgAxy5akU4FdHjMHqx87B0qdmj-_UXxFNGfrpCsj6jWFfr4iZcxjFlCisA"

# token=$(curl -s -X POST \
    # -H 'Key: ecpregistry' \
    # -H 'SecretKey: s2MK2d@uE' \
    # -H 'x-api-key: ${APIKey}' \
    # ${host}/auth)

# echo -e "token:\n${token}"

cmd="curl -X PUT \
    ${host}/metadata/project/${ProjectID}/thing/${newecpid} \
    -H 'Accept: application/vnd.ecp.registry+json' \
    -H 'Authorization: ${token}' \
    -H 'Content-Type: application/vnd.ecp.registry+json' \
    -H 'x-api-key: ${APIKey}'"  # \
    #-d '{"id":"${newecpid}","ontology":{"ontologyUri":"https://graph.link/ecp/1.0/schema/CDF","ontologyVersion":"2.0.0"},"description":{"value":"some description for bj e2e"},"label":{"value":"e2e-bj"},"type":{"value":"https://graph.link/ecp/schema/registry/Thing"},"jsonContext":{"description":"http://purl.org/dc/elements/1.1/description","label":"http://www.w3.org/2000/01/rdf-schema#label","type":"http://www.w3.org/1999/02/22-rdf-syntax-ns#type"}}'
    
echo -e "CMD:\n$CMD"

curl -X PUT -H 'Accept: application/vnd.ecp.registry+json' -H 'Authorization: eyJraWQiOiJnU2xOeVZiQmFpSDNNaXJpa2oxdWlRNlwvVCtDN1l5R2RYWTVhcHdXRmVqMD0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJjNzE4NzA1Yy1mY2M1LTQ4MTAtYjZjZS05ODUyM2YyYWRjZDAiLCJhdWQiOiIyMDlkOTg4ZDRzNnJpNzllODhuajNyZ25xcyIsImVtYWlsX3ZlcmlmaWVkIjpmYWxzZSwiZXZlbnRfaWQiOiI0MzBmZTE4Yi00ZmIwLTQzZmUtOGJmNy0xMmY5YWNjYjdjZjUiLCJ0b2tlbl91c2UiOiJpZCIsImF1dGhfdGltZSI6MTU2Njk3ODQ5NywiaXNzIjoiaHR0cHM6XC9cL2NvZ25pdG8taWRwLnVzLWVhc3QtMS5hbWF6b25hd3MuY29tXC91cy1lYXN0LTFfSTM2UXpzNEdJIiwiY29nbml0bzp1c2VybmFtZSI6ImVjcHJlZ2lzdHJ5IiwiZXhwIjoxNTY2OTgyMDk3LCJnaXZlbl9uYW1lIjoiZWNwcmVnaXN0cnkiLCJpYXQiOjE1NjY5Nzg0OTcsImZhbWlseV9uYW1lIjoiZWNwcmVnaXN0cnkifQ.cjKtqyislRrqR4ZETYxCK5PKKqIahuCRU2ZOytmvLWacKXGFkEkMu7gMmmqu-bBCjyzeYumi7WhURZ6aXWBRcrjA_gB2sMIVL4UlfIQVOfixbplk5iE60cmV4CYaJQiZMZJQpvAix3wsuCjfLyYNOR8kTC5kEeUoFd2JWRI4UTX6nE6InEz5-RhnaOrDiAW_eAdP-A1SE4TqzwzBRdWTO6Aq7gXQi40ONhfLlygVcF-symYXr2eEbiKfiMX0YeAAV7D7uW9DqaeuCN3E8FJfNmlCDWhKEF_tEDqsZbT0wUp148D9aS-xu_jJGjyRL4ouKvEZ80c9vuWqg7Pgml3wWA' -H 'Content-Type: application/vnd.ecp.registry+json' -H 'x-api-key: gDtAPG68Im8ObNx6G0ZyG4PbYSyzfpjt3qT8VN20' -d '{"id":"ecp:6-abcd1234-e8c7-323f-fe8b-6d987gabcdef","ontology":{"ontologyUri":"https://graph.link/ecp/1.0/schema/CDF","ontologyVersion":"2.0.0"},"description":{"value":"some description for bj e2e"},"label":{"value":"e2e-bj"},"type":{"value":"https://graph.link/ecp/schema/registry/Thing"},"jsonContext":{"description":"http://purl.org/dc/elements/1.1/description","label":"http://www.w3.org/2000/01/rdf-schema#label","type":"http://www.w3.org/1999/02/22-rdf-syntax-ns#type"}}' 'http://a204618junjielb-324114725.us-east-1.elb.amazonaws.com/metadata/project/ecp:8-aede0344-f3e2-474c-bd9d-9c872cabcdef/thing/ecp:6-abcd1234-e8c7-323f-fe8b-6d987gabcdef'


