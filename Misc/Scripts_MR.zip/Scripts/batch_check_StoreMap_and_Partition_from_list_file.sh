#!/bin/bash

if (( $# < 1 )); then
	echo "Usage: $0 <LIST-FILE>"
	exit 2
fi

LISTFILE=$1

export ENV_GLOBAL="Prod"

sn=0
while read LINE; do
	echo "$LINE" | grep "^ecp:" &> /dev/null
	if [ $? -eq 0 ]; then
		(( sn += 1 ))
		printf "[%02d] %s\n" $sn $LINE
		DP_CV=$(echo "$LINE" | awk -F',' '{print $1" "$2}')
		./ret_StoreMap_Partition_by_DP_CV.sh $DP_CV
	fi
done < $LISTFILE
