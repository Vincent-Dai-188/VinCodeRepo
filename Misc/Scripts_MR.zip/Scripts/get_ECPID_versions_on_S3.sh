#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 <ECPID>"
    exit 2
fi

MR_BUCKET_QA="a204121-content-ecpmeta-qa-use1"

ECPID=$1

printf ">> %s\n" $ECPID

#OBJID_REV="678b6fcde30a-f1aa-1dc4-cb9e-887616ce-1:pce"
OBJID_REV=$(echo $ECPID | rev)
retObj_S3=$(aws s3api list-object-versions --bucket ${MR_BUCKET_QA} --prefix "${OBJID_REV}/NQuads/2.0.0/ecp:")

if [ $? -eq 0 ]; then
    echo ${retObj_S3} | jq #-rj '.Versions [] | "  - ", .LastModified, ",", .IsLatest, "\n"'
fi
