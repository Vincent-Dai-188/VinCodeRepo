#!/bin/bash

. /data/vincent/slibs/fetch_token_MR.slib

function display_help
{
    echo "Usage: $UTILNAME <ecp-id> [-i] [-S] [-L] [-D] [-M] [-C] [-h] [-E <DEV|QA|Prod|Sandbox>] [-T <json|nquads|trig>]"
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

# Accept: JSON-LD (default)
CONTTYPE="vnd.ecp.registry+json"

CacheCtrl=""
showEnv=""
SKIPTOKEN=""
CF_EARLIER=""
SUFFIX=""

if (( $# >= 1 )); then
    ECPID=$1
    shift
else
    display_help
    exit 1
fi

ShowMainInfo=""
while getopts :hiMCLDSE:T: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            elif [ "${ENV}" = "DEV" ]; then
                . $WORKDIR/ENV_config/DEV.cfg
            elif [ "${ENV}" = "Prod" ]; then
                . $WORKDIR/ENV_config/Prod.cfg
            else  # Sandbox
                . $WORKDIR/ENV_config/Sandbox.cfg
            fi
            ;;
        T)  CONTTYPE=${OPTARG}
            if [ "${CONTTYPE}" = "nquads" ]; then
                CONTTYPE="vnd.ecp.registry+nquads"
                SUFFIX=".quads"
            elif [ "${CONTTYPE}" = "trig" ]; then
                CONTTYPE="vnd.ecp.registry+trig"
                SUFFIX=".trig"
            fi
            ;;
		M)  ShowMainInfo="true"
			;;
        C)  CacheCtrl="Cache-Control: no-cache"
            ;;
        D)  CF_EARLIER="?cf=1990-01-01T00:00:00.000Z"
            ;;
        L)  xLatest="x-latest: true"
            ;;
        S)  SKIPTOKEN="true"    # Retrieve token from TOKEN_FILE without checking expiration period
            ;;
        i)  showEnv="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
    else
        # QA Env (default)
        . $WORKDIR/ENV_config/QA.cfg
    fi
fi

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***" 1>&2
fi

TOKENFILE="/tmp/.token_MR_${ENV}.aut"

get_token_MR

if [ -n "${CacheCtrl}" ] && [ -n "${xLatest}" ]; then
    echo "*** ${CacheCtrl} ${xLatest} ***" 1>&2
    res=$(curl -w "\nStatus_Code: %{http_code}\n" -s -X GET ${SPARQL_HOST}/metadata/thing/${ECPID}${CF_EARLIER} -H "Accept: application/${CONTTYPE};api-version=1" -H "x-api-key: ${APIKey}" -H "Authorization: ${token}" -H  "${CacheCtrl}" -H "${xLatest}")
elif [ -n "${CacheCtrl}" ]; then
    echo "*** ${CacheCtrl} ***" 1>&2
    res=$(curl -w "\nStatus_Code: %{http_code}\n" -s -X GET ${SPARQL_HOST}/metadata/thing/${ECPID}${CF_EARLIER} -H "Accept: application/${CONTTYPE};api-version=1" -H "x-api-key: ${APIKey}" -H "Authorization: ${token}" -H  "${CacheCtrl}")
elif [ -n "${xLatest}" ]; then
    echo "*** ${xLatest} ***" 1>&2
    res=$(curl -w "\nStatus_Code: %{http_code}\n" -s -X GET ${SPARQL_HOST}/metadata/thing/${ECPID}${CF_EARLIER} -H "Accept: application/${CONTTYPE};api-version=1" -H "x-api-key: ${APIKey}" -H "Authorization: ${token}" -H  "${xLatest}")
else
    res=$(curl -w "\nStatus_Code: %{http_code}\n" -s -X GET ${SPARQL_HOST}/metadata/thing/${ECPID}${CF_EARLIER} -H "Accept: application/${CONTTYPE};api-version=1" -H "x-api-key: ${APIKey}" -H "Authorization: ${token}")
fi

#staCode=$(echo "$res" | grep -o "Status_Code: [2-5][0-9]\{2\}")
staCode=$(echo "$res" | tail -n 1 | grep -o "[2-5][0-9]\{2\}")
if (( staCode == 200 )); then
    #echo "$staCode" 1>&2
    retThing=$(echo "$res" | sed '$d')
    #if [ -d "/tmp/things_redis/${ENV}/" ]; then
    #    echo "$retThing" > /tmp/things_redis/${ENV}/${ECPID}${SUFFIX}
    #fi
    if [ -n "${ShowMainInfo}" ]; then
        echo "$retThing" | jq -rj '."@graph"[0] | "Type: ", ."@type", ", Label: ", ."http://www.w3.org/2000/01/rdf-schema#label", ", Desc: ", ."http://purl.org/dc/elements/1.1/description", "\n"'
    else
        echo "$retThing"
    fi
elif [ -n "$staCode" ]; then
    #echo "Status_Code: $staCode" 1>&2
    # Display raw error message
    if [ "$staCode" = "404" ]; then
        echo "No matching data found (404)"
    else
        retThing=$(echo "$res" | sed '$d')
        echo "$retThing"
    fi
    # Remove exsiting files of the same ECPID
    #ls /tmp/things_redis/${ENV}/${ECPID}* &> /dev/null
    #if [ $? -eq 0 ]; then
    #    rm -f /tmp/things_redis/${ENV}/${ECPID}*
    #fi
    exit 1
else
    echo "$res"
    exit 2
fi
