#!/bin/bash

function print_indent
{
    #printf '%*s' $nInt
    if (( nInt == 0 )); then
        printf '%s,%s,'  "${CI_ECPID}" "${CI_ECPID}"
	else
        printf '%s,%s,' "${CI_ECPID}" "${ParentID}"
    fi
}

function traverse_DE    #ECP-Id
{
    ECPID=$1

    FnDE="DEram_${ECPID:4:38}.json"
    if [ -f "${RAMROOT}/${FnDE}" ]; then
        retObj=$(cat "${RAMROOT}/${FnDE}")
    else
        retObj=$(getThing $ECPID)
    fi

    echo $retObj | grep "No matching data found" &>/dev/null
    if [ $? -eq 0 ]; then
        print_indent
        echo "$ECPID - (X)"
    else
        DELabel=$(echo $retObj | jq -r '."@graph"[0]."http://www.w3.org/2000/01/rdf-schema#label"')
        graphObj=$(echo $retObj | jq '."@graph"[] | ."@graph"')
        if [ "$graphObj" = "null" ]; then
            thingObj=$(echo $retObj | jq '."@graph"[]')
        else    # "@graph" array
            thingObj=$(echo $graphObj | jq '.[]')
        fi

        echo $thingObj | grep '"https://graph.link/ecp/schema/CDF/SimpleDataElement"' &>/dev/null
        if [ $? -eq 0 ]; then
            print_indent
            DEType=$(echo $thingObj | jq -r '."https://graph.link/ecp/schema/CDF/hasSimpleDatatype"."@id"')
            #DEType=$(echo ${DEType} | sed 's,https://graph.link/ecp/schema/CDF/SimpleDatatype-,,')
            DEType=$(echo ${DEType} | sed 's,https://graph.link/ecp/schema/CDF/,,')
            printf "%s,%s,%s\n" "$ECPID" "${DELabel}" "${DEType}"
        else
            childDE=$(echo $thingObj | jq -r '."https://graph.link/ecp/schema/CDF/hasChildDataElement"')
            if [ "$childDE" != "null" ]; then
                DEType=$(echo $thingObj | grep -o '"@type"\s*: "https://graph.link/ecp/schema/CDF/[a-zA-Z]*DataElement"' \
                    | grep -o "[a-zA-Z]*DataElement" | sort -u)
                childEcpids=$(echo $childDE | jq -r 'if type=="array" then .[]."@id" else ."@id" end' | sort -u)
                print_indent

               if (( nInt == 0 )) && [ "$DEType" = "OneToManyDataElement" ]; then
                    printf "%s,%s,%s\n" "+M>$ECPID" "${DELabel}" "${DEType}<M+"
                    ParentType="OTM"
                elif (( nInt == 0 )) && [ "$DEType" = "OneToOneDataElement" ]; then
                    printf "%s,%s,%s\n" "+o>$ECPID" "${DELabel}" "${DEType}<o+"
                    ParentType="OTO"
                elif (( nInt == 2 )) && [ "$DEType" = "OneToOneDataElement" ]; then
                    printf "%s,%s,%s\n" "$ECPID" "${DELabel}" "Map"
                else
                    printf "%s,%s,%s\n" "$ECPID" "${DELabel}" "${DEType}"
                fi
                ParentID="$ECPID"

                #print_indent && echo "{"
                (( nInt += 2 ))
                # Get raw childEcpids list re-ordered: SimpleDataElements first
                local declare childDEs_Array_Sim=()
                local declare childDEs_Array_OTX=()
                for childDEId in $childEcpids; do
                    FnDE="DEram_${childDEId:4:38}.json"
                    getThing $childDEId > "${RAMROOT}/${FnDE}"
                    grep '"https://graph.link/ecp/schema/CDF/SimpleDataElement"' "${RAMROOT}/${FnDE}" &>/dev/null
                    if [ $? -eq 0 ]; then
                        childDEs_Array_Sim+=("${childDEId}")
                    else
                        childDEs_Array_OTX+=("${childDEId}")
                    fi
                done
                if [ "$DEType" = "OneToOneDataElement" ] && (( ${#childDEs_Array_Sim[@]} == 0 )); then
                    (( nInt = 0 ))
                elif (( ${#childDEs_Array_Sim[@]} > 0 )); then
                    # Output all the childSimpleDataElements first
                    for childID in ${childDEs_Array_Sim[@]}; do
                        traverse_DE $childID
                    done

                    if (( nInt == 4 )); then
                        (( nInt -= 2 ))
                        #print_indent && echo "}"
                        (( nInt -= 2 ))
                        #print_indent && echo "}"
                    else
                        (( nInt -= 2 ))
                        #print_indent && echo "}"
                    fi
                fi
                # Traverse complex DataElements then
                for childID in ${childDEs_Array_OTX[@]}; do
                    traverse_DE $childID
                done
            else
                echo "$ECPID - 'CDF/hasChildDataElement' not found!"
            fi
        fi
    fi
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 2 )); then
    echo "Usage: $UTILNAME <DataElement_ECPId> <ContentItem_ECPID>"
    exit 1
fi

RAMROOT="/tmp/ramdisk"

nInt=0
ParentID=""
ParentType=""

DE_ID=$1
CI_ECPID=$2

traverse_DE ${DE_ID}

rm -f ${RAMROOT}/DEram_*.json