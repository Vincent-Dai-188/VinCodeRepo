#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 \"<CIId1 CIId2 ...>\""
    exit 2
fi

CIs="$@"

RAMROOT="/tmp/ramdisk"

echo "$CIs" | grep "ecp:[0-9]-[0-9a-z-]*" &>/dev/null
if [ $? -ne 0 ]; then
    echo "Usage: $0 \"<CIId1 CIId2 ...>\""
    exit 2
fi

rm -f ${RAMROOT}/DEram_*.json

for CIId in ${CIs}; do
    retCI=$(getThing $CIId)
    CILabel=$(echo $retCI | jq -r '."@graph"[0]."http://www.w3.org/2000/01/rdf-schema#label"')
    echo -e "\n>> CI: $CIId  \"$CILabel\""
    DEs_Raw=$(echo $retCI | jq -r '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasDataElement" | if type=="array" then .[]."@id" else ."@id" end')

    DEcount=$(echo ${DEs_Raw} | awk '{print NF}')
    if (( DEcount > 1 )); then
        # Get raw DEs list re-ordered: SimpleDataElements first
        declare DEs_Array_Sim=()
        declare DEs_Array_OTX=()
        for DEId in $DEs_Raw; do
            FnDE="DEram_${DEId:4:38}.json"
            getThing $DEId > "${RAMROOT}/${FnDE}"
            grep '"https://graph.link/ecp/schema/CDF/SimpleDataElement"' "${RAMROOT}/${FnDE}" &>/dev/null
            if [ $? -eq 0 ]; then
                DEs_Array_Sim+=("${DEId}")
            else
                DEs_Array_OTX+=("${DEId}")
            fi
        done
        for DEId in ${DEs_Array_Sim[@]}; do
            ./traverse_DEs_output_tuned_for_KEY_indent.sh $DEId
        done
        for DEId in ${DEs_Array_OTX[@]}; do
            ./traverse_DEs_output_tuned_for_KEY_indent.sh $DEId
        done
    else
        for DEId in $DEs_Raw; do
            ./traverse_DEs_output_tuned_for_KEY_indent.sh $DEId
        done
    fi
done
