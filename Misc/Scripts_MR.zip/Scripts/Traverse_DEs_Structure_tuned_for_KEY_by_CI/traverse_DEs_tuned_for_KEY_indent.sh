#!/bin/bash

function print_indent
{
    printf '%*s' $nInt
}

function traverse_DE    #ECP-Id
{
    ECPID=$1

    FnDE="DEram_${ECPID:4:38}.json"
    if [ -f "${RAMROOT}/${FnDE}" ]; then
        retObj=$(cat "${RAMROOT}/${FnDE}")
    else
        retObj=$(getThing $ECPID)
    fi

    echo $retObj | grep "No matching data found" &>/dev/null
    if [ $? -eq 0 ]; then
        print_indent
        #echo "*** $retObj ***"
        echo "$ECPID - (X)"
    else
        DELabel=$(echo $retObj | jq -r '."@graph"[0]."http://www.w3.org/2000/01/rdf-schema#label"')
        graphObj=$(echo $retObj | jq '."@graph"[] | ."@graph"')
        if [ "$graphObj" = "null" ]; then
            thingObj=$(echo $retObj | jq '."@graph"[]')
        else    # "@graph" array
            thingObj=$(echo $graphObj | jq '.[]')
        fi

        #echo $thingObj | grep '"@type"\s*: "https://graph.link/ecp/schema/CDF/SimpleDataElement"' &>/dev/null
        echo $thingObj | grep '"https://graph.link/ecp/schema/CDF/SimpleDataElement"' &>/dev/null
        if [ $? -eq 0 ]; then
            print_indent
            #echo "$ECPID - hasSimpleDataElement"
            DEType=$(echo $thingObj | jq -r '."https://graph.link/ecp/schema/CDF/hasSimpleDatatype"."@id"')
            DEType=$(echo ${DEType} | sed 's,https://graph.link/ecp/schema/CDF/SimpleDatatype-,,')
            #echo "$ECPID (${DEType}) - <>  \"${DELabel}\""
            printf "%-42s %-18s %s\n" $ECPID "(${DEType})-<>" "\"${DELabel}\""
        else
            childDE=$(echo $thingObj | jq -r '."https://graph.link/ecp/schema/CDF/hasChildDataElement"')
            if [ "$childDE" != "null" ]; then
                DEType=$(echo $thingObj | grep -o '"@type"\s*: "https://graph.link/ecp/schema/CDF/[a-zA-Z]*DataElement"' \
                    | grep -o "[a-zA-Z]*DataElement" | sort -u)
                childEcpids=$(echo $childDE | jq -r 'if type=="array" then .[]."@id" else ."@id" end' | sort -u)
                print_indent
                #echo "$ECPID \"${DELabel}\" - ${DEType}"
                printf "%-42s %-24s %s\n" $ECPID " - ${DEType}" "\"${DELabel}\""
                print_indent
                echo "{"
                (( nInt += 2 ))
                childDEcount=$(echo ${childEcpids} | awk '{print NF}')
                if (( childDEcount > 1 )); then
                    # Get raw childEcpids list re-ordered: SimpleDataElements first
                    local declare childDEs_Array_Sim=()
                    local declare childDEs_Array_OTX=()
                    for childDEId in $childEcpids; do
                        FnDE="DEram_${childDEId:4:38}.json"
                        getThing $childDEId > "${RAMROOT}/${FnDE}"
                        grep '"https://graph.link/ecp/schema/CDF/SimpleDataElement"' "${RAMROOT}/${FnDE}" &>/dev/null
                        if [ $? -eq 0 ]; then
                            childDEs_Array_Sim+=("${childDEId}")
                        else
                            childDEs_Array_OTX+=("${childDEId}")
                        fi
                    done
                    for childID in ${childDEs_Array_Sim[@]}; do
                        traverse_DE $childID
                    done
                    for childID in ${childDEs_Array_OTX[@]}; do
                        traverse_DE $childID
                    done
                else
                    for childID in $childEcpids; do
                        traverse_DE $childID
                    done
                fi
                (( nInt -= 2 ))
                print_indent
                echo "}"
            else
                echo "$ECPID - 'CDF/hasChildDataElement' not found!"
            fi
        fi
    fi
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 1 )); then
    echo "Usage: $UTILNAME <DataElement_ECPId>"
    exit 1
fi

RAMROOT="/tmp/ramdisk"

nInt=0

traverse_DE $1

rm -f ${RAMROOT}/DEram_*.json