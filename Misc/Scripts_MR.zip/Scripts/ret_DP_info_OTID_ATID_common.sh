#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <ECP-Id | IDs_list_file_name>"
}

function check_DP   # DPId
{
    DPID_set=$1

	for DPID in ${DPID_set}; do
		echo -e -n "\n>> DPID: $DPID  "

		DPJSON=$(getThing $DPID)
		if [ $? -ne 0 ]; then
			echo "$DPJSON"
			exit 2
		fi

		# Retrieve 'label' & 'description' of DistributionPair
		echo "${DPJSON}" | jq -r -j '."@graph"[0] | "-label: ", ."http://www.w3.org/2000/01/rdf-schema#label", "  -description: ", ."http://purl.org/dc/elements/1.1/description", "\n"'

		# Retrieve ObjectTypeId (supportID) & ArchetypeId associated with this DistributionPairId
		OTID=$(echo "${DPJSON}" | jq -r '."@graph"[0]."https://graph.link/ecp/schema/CDF/supports"."@id"')
		echo -n "  - ObjectTypeId: $OTID  "
		OTJSON=$(getThing $OTID)
		echo $OTJSON | jq -r -j '."@graph"[0] | "-label: ", ."http://www.w3.org/2000/01/rdf-schema#label", "  -description: ", ."http://purl.org/dc/elements/1.1/description", "\n"'

		ATID=$(echo "${OTJSON}" | jq -r '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasArchetype"."@id"')
		echo -n "    - ArchetypeId: $ATID  "
		ATJSON=$(getThing $ATID)
		echo $ATJSON | jq -r -j '."@graph"[0] | "-label: ", ."http://www.w3.org/2000/01/rdf-schema#label", "\n"'
	done
}

if (( $# < 1 )); then
    display_help
    exit 2
fi

DPIDs=$1

check_DP "${DPIDs}"
