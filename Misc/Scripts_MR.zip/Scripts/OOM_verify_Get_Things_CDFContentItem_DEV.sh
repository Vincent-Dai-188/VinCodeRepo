#!/bin/bash

Token=$(curl -s -X POST https://registry-ecp-devs.a-corporate-preprod.aws-int.thomsonreuters.com/auth -H 'Key: u6025979' -H 'SecretKey: Rjr>NJgR9\BD.V-T' -H 'x-api-key: gDtAPG68Im8ObNx6G0ZyG4PbYSyzfpjt3qT8VN20')

if [ -n "${Token}" ]; then
    echo ">> Token retrieved."
    echo ">> curl -X GET '{HOST_DEV}/metadata/things?uri=https://graph.link/ecp/schema/CDF/ContentItem'"

    curl -X GET 'https://registry-ecp-devs.a-corporate-preprod.aws-int.thomsonreuters.com/metadata/things?uri=https://graph.link/ecp/schema/CDF/ContentItem' -H 'Accept: application/vnd.ecp.registry+json;api-version=1' -H "Authorization: ${Token}" -H 'x-api-key: gDtAPG68Im8ObNx6G0ZyG4PbYSyzfpjt3qT8VN20'
fi

echo
