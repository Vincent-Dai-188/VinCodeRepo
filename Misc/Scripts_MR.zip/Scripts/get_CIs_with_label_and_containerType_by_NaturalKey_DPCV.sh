#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <ecpid_DP,ecpid_V> [-E DEV|QA|Prod] [-h]"
}

function refetch_token
{
    # Outputs to stderr to avoid potential parse error when using jq
    echo "Re-Fetch Token ..." 1>&2
    # -H 'Content-Length: 0' (To avoid: Content-Length missing for POST or PUT requests)
    token=$(curl -s -X POST \
        -H "Key: ${uKey}" \
        -H "SecretKey: ${SecretKey}" \
        -H "x-api-key: ${APIKey}" \
        -H "Content-Length: 0" \
        ${HOST}/auth)

    if [ -z "$token" ]; then
        echo "*** Failed to obtain token! ***"
        exit 1
    fi
    #echo -e "\nNew token:\n${token}\n"
    date +%s > $TOKENFILE
    echo $token >> $TOKENFILE
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

# Accept: JSON-LD (default)
CONTTYPE="vnd.ecp.registry+json"

if (( $# >= 1 )); then
    DPCV=$1
    shift 1
    ECPID_DP=$(echo "$DPCV" | awk -F, '{print $1}')
    ECPID_CV=$(echo "$DPCV" | awk -F, '{print $2}')
else
    display_help
    exit 1
fi

while getopts :hE: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            elif [ "${ENV}" = "DEV" ]; then
                . $WORKDIR/ENV_config/DEV.cfg
            elif [ "${ENV}" = "Prod" ]; then
                . $WORKDIR/ENV_config/Prod.cfg
            else  # Sandbox
                . $WORKDIR/ENV_config/Sandbox.cfg
            fi
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
    else
        # QA Env (default)
        . $WORKDIR/ENV_config/QA.cfg
    fi
fi

TOKENFILE="/tmp/.token_MR_${ENV}.aut"

if [ -f $TOKENFILE ]; then
    tokenbuf="$(cat ${TOKENFILE})"
    tmstamp=$(echo "$tokenbuf" | head -n 1)
    curstamp=$(date +%s)
    if (( curstamp - tmstamp > 1800 )); then
        refetch_token
    else
        token=$(echo "$tokenbuf" | tail -n 1)
    fi
else
    refetch_token
fi

# Put IDset into an associative array with index 
declare -A OTLArray=()

res=$(curl -w "\nStatus_Code: %{http_code}\n" -s -X GET ${HOST}/metadata/cdfcontentitems\?CDFComponent=${ECPID_DP}\&CDFVersion=${ECPID_CV} \
    -H "Accept: application/${CONTTYPE};api-version=1" -H "x-api-key: ${APIKey}" -H "Authorization: ${token}")

staCode=$(echo "$res" | tail -n 1 | grep -o "[2-5][0-9]\{2\}")
if (( staCode == 200 )); then
    retThing=$(echo "$res" | sed '$d')
    retCompact=$(echo "$retThing" | jq -c '.')
    echo "$retCompact" | grep -o '{"@graph":\[{"@graph":\[' &> /dev/null
    if [ $? -eq 0 ]; then
        retIds=$(echo "$retCompact" | jq -r '."@graph"[]."@graph"[0]."@id"')
    else
        retIds=$(echo "$retCompact" | jq -r '."@graph"[0]."@id"')
    fi
    #retIds=$(echo "$retThing" | jq -r '."@graph"[0] | if type=="array" then .[0]."@id" else ."@id" end')
    if [ "$retIds" != "null" ]; then
        #printf "#    %-45s %-45s %-45s %s\n" "CIId" "CILabel" "OTId" "OTLabel"
		printf "#    %-45s %-45s %-17s %-45s %s\n" "CIId" "CILabel" "ContainerType" "OTId" "OTLabel"
        # Assemble CILabel & OTId
        cnt=0
        for CIId in $retIds; do
            (( cnt++ ))
            CIthing=$(getThing $CIId)
			if [ $? -eq 0 ]; then
				CILabel=$(echo "$CIthing" | jq -r '."@graph"[0]."http://www.w3.org/2000/01/rdf-schema#label"')
				# retrieve ContainerTypeId via .hasContainerType or .hasContainer property
				ContainerTypeId=$(echo "$CIthing" | jq -r '."@graph"[0] | if ."https://graph.link/ecp/schema/CDF/hasContainerType"."@id"? then ."https://graph.link/ecp/schema/CDF/hasContainerType"."@id" else ."https://graph.link/ecp/schema/CDF/hasContainer"."@id" end')
				if [ "$ContainerTypeId" = "null" ]; then
					ContainerTypeLabel="Metadata(D)"
				else
					ContainerTypeLabel=$(getThing $ContainerTypeId | jq -r '."@graph"[0]."http://www.w3.org/2000/01/rdf-schema#label"' | sed 's/ Container//')
				fi
				OTId=$(echo "$CIthing" | jq -r '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasObjectType"."@id"')

				if [ "$OTId" != "null" ]; then
					# Check if this OTLabel is already cached
					OTLabel=$(echo ${OTLArray[$OTId]})
					if [ -z "$OTLabel" ]; then
						OTLabel=$(getThing $OTId | jq -r '."@graph"[0]."http://www.w3.org/2000/01/rdf-schema#label"')
						# Push this new OTLabel into cache
						OTLArray+=([$OTId]=${OTLabel})
					fi
				else
					OTLabel="null"
				fi
				#printf "[%02d] %-45s %-45s %-45s %s\n" "$cnt" "$CIId" "$CILabel" "$OTId" "$OTLabel"
				printf "[%02d] %-45s %-45s %-17s %-45s %s\n" "$cnt" "$CIId" "$CILabel" "$ContainerTypeLabel" "$OTId" "$OTLabel"
			else
				printf "[%02d] %-45s %s\n" "$cnt" "$CIId" "$CIthing"
			fi
        done
    else
        echo "\n Something went wrong, please check the original returned content:"
        echo "$retThing"
        exit 3
    fi
elif [ -n "$staCode" ]; then
    echo "Status_Code: $staCode" 1>&2
    # Display raw error message
    retThing=$(echo "$res" | sed '$d')
    echo "$retThing"
    exit 1
else
    echo "$res"
    exit 2
fi
