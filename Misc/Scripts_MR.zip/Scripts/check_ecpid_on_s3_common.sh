#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <ECP-Id> [-E <DEV|QA|Sandbox>] [-i] [-h]"
}

if (( $# < 1 )); then
    echo "ECPID must be provided!"
    exit 1
fi

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))
showEnv=""

ecpid=$1
shift

# DEV Env (default)
ENV="DEV"
AWSPROFILE="a-corporate-preprod"
S3BUCKET="a204121-content-ecpmeta-devsnapshot-use1"

while getopts :hiE: paras
do
    case "$paras" in
        E)
            ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                AWSPROFILE="a-corporate-preprod"
                S3BUCKET="a204121-content-ecpmeta-qa-use1"
            elif [ "${ENV}" = "Sandbox" ]; then
                AWSPROFILE="tr-fr-sandbox"
                S3BUCKET="a204618-content-ecpmeta-devjunjiesun-use1"
            else    # DEV
                AWSPROFILE="a-corporate-preprod"
                S3BUCKET="a204121-content-ecpmeta-devsnapshot-use1"
            fi
            ;;
        i)  showEnv="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***"
fi

ecpid_rev=$(echo $ecpid | rev)

projectId=$(aws --profile ${AWSPROFILE} s3 ls s3://${S3BUCKET}/${ecpid_rev}/NQuads/2.0.0/)

if [ -n "${projectId}" ]; then
    filenm=$(echo $projectId | grep -o "ecp:[0-9]-[0-9a-z]\{8\}-[0-9a-z]\{4\}-[0-9a-z]\{4\}-[0-9a-z]\{4\}-[0-9a-z]\{12\}")
    echo ">> Copy MR data file '${filenm}' in S3 to /tmp/things_s3/ ..." 1>&2
    aws --profile ${AWSPROFILE} s3 cp s3://${S3BUCKET}/${ecpid_rev}/NQuads/2.0.0/${filenm} /tmp/things_s3/${ecpid} 1>&2
    cat /tmp/things_s3/${ecpid}
else
    echo "Specified ECPID not found in S3!"
fi
