#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <DP_ECPID>"
}

function check_OT_by_DP   # DPID
{
    DPID_set=$1

    for DPID in ${DPID_set}; do
        #echo -e -n "\n>> DPID: $DPID  "

        DPJSON=$(getThing $DPID -D)
        if [ $? -ne 0 ]; then
            echo "$DPJSON"
            exit 2
        fi

        # Retrieve ObjectTypeId (supportID) & ArchetypeId associated with this DistributionPairId
        OTID=$(echo "${DPJSON}" | jq -r '."@graph"[0]."https://graph.link/ecp/schema/CDF/supports"."@id"')
        echo -n "$OTID  "
        OTJSON=$(getThing $OTID -D)
        echo "$OTJSON" | jq '."@graph"[0]."http://www.w3.org/2000/01/rdf-schema#label"'
    done
}

if (( $# < 1 )); then
    display_help
    exit 2
fi

DPId=$1

check_OT_by_DP "${DPId}"
