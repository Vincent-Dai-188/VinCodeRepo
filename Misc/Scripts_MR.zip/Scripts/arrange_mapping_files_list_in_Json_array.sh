#!/bin/bash

# Arrange the mapping files list in Json array, e.g., ["DS1","DS2","DS3","DS4"].

mappingStr="$(grep -o "[a-zA-Z0-9_-]\{1,50\}\.ecpIds" mapping_files_6.out)"
array="["
sn=0
for item in $mappingStr;
do
	DSstr=`echo $item | sed -e 's/^/"/;s/\.ecpIds/"/'`
	#echo $DSstr
	if (( sn == 0 )); then
		array=${array}${DSstr}
	else
		array=${array},${DSstr}
	fi
	(( sn += 1 ))
done
array="${array}]"

echo $array