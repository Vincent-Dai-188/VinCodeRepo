#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <ECP-Id> [-E <DEV|QA|Sandbox>] [-f] [-i] [-h]"
}

if (( $# < 1 )); then
    echo "ECPID must be provided!"
    exit 1
fi

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))
showEnv=""
chkExist=""
SKIPTOKEN=""

ecpid=$1
shift

if [ -n "${ENV_GLOBAL}" ]; then
    . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
else
    # DEV Env (default)
    . $WORKDIR/ENV_config/DEV.cfg
fi

while getopts :hifSE: paras
do
    case "$paras" in
        E)
            ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            elif [ "${ENV}" = "Sandbox" ]; then
                . $WORKDIR/ENV_config/Sandbox.cfg
            else  # DEV
                . $WORKDIR/ENV_config/DEV.cfg
            fi
            ;;
        i)  showEnv="true"
            ;;
        f)  chkExist="true"
            ;;
        S)  SKIPTOKEN="true"    # Skip checking AWS token expiration
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***" 1>&2
fi

ecpid_rev=$(echo $ecpid | rev)

projectId=$(aws s3 ls s3://${S3BUCKET}/${ecpid_rev}/NQuads/2.0.0/)

if [ -n "${projectId}" ]; then
    if [ -n "${chkExist}" ]; then
        echo "Exists."
    else
        filenm=$(echo $projectId | grep -o "ecp:[0-9]-[0-9a-z]\{8\}-[0-9a-z]\{4\}-[0-9a-z]\{4\}-[0-9a-z]\{4\}-[0-9a-z]\{12\}")
        echo ">> Copy MR data file '${filenm}' in S3 to /tmp/things_s3/ ..." 1>&2
        aws --profile ${AWSPROFILE} s3 cp s3://${S3BUCKET}/${ecpid_rev}/NQuads/2.0.0/${filenm} /tmp/things_s3/${ENV}/${ecpid} 1>&2
        cat /tmp/things_s3/${ENV}/${ecpid}
    fi
else
    echo "Not found!"
    exit 1
fi
