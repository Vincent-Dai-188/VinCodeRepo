#!/bin/bash

#http_proxy="10.40.14.55:80"
host="https://ecp-registry-qa-int.thomsonreuters.com"
ProjectID="ecp:8-aede0344-f3e2-474c-bd9d-9c872cabcdef"
newecpid="ecp:9-5c9fe076-8b2a-4d7d-adc1-a58bd5042efe"
APIKey="pVw5gWw9d48wKssfe7PV41O61b7SsHDk9AjYQqFA"

CONTTYPE="json"

token=$(curl -s -X POST \
    -H 'Key: u6064334' \
    -H 'SecretKey: M$FFXR_tH8b?Y~9!' \
    -H 'x-api-key: pVw5gWw9d48wKssfe7PV41O61b7SsHDk9AjYQqFA' \
    ${host}/auth)

echo -e "\nNew token:\n${token}\n"

if (( $# == 2 )); then
    QUERYPART=$1
    CONTTYPE=$2
    if [ "${CONTTYPE}" = "reg+" ]; then
        CONTTYPE="vnd.ecp.registry+json"
    fi
fi

curl -X GET ${host}/${QUERYPART} -H "Accept: application/${CONTTYPE}" -H "x-api-key: ${APIKey}" -H "Authorization: ${token}"
