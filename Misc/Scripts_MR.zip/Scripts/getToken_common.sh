#!/bin/bash

. /data/vincent/slibs/fetch_token_MR.slib

function display_help
{
    echo "Usage: getToken [-E <DEV|QA|Prod>] [-i] [-S] [-h]"
}

showEnv=""

# getopts relies on OPTIND to loop through the arguments provided. After sourcing the script, it
# will be set to some value greater than 1 by getopts according to how many arguments you pass.
# So the next time it is sourced, getopts will pick up from that OPTIND, rather than starting 
# from 1, that cause the arguments being "lost".
OPTIND=1
while getopts :iShE: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            elif [ "${ENV}" = "DEV" ]; then
                . $WORKDIR/ENV_config/DEV.cfg
            elif [ "${ENV}" = "Prod" ]; then
                . $WORKDIR/ENV_config/Prod.cfg
            else  # Sandbox
                . $WORKDIR/ENV_config/Sandbox.cfg
            fi
            ;;
        h)  display_help
            exit 0
            ;;
        i)  showEnv="true"
            ;;
        S)  SaveToken="true"
            ;;
        *)  display_help
            exit 1
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
    else
        # QA Env (default)
        . $WORKDIR/ENV_config/QA.cfg
    fi
fi

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***" 1>&2
fi

TOKENFILE="/tmp/.token_MR_${ENV}.aut"

get_token_MR
