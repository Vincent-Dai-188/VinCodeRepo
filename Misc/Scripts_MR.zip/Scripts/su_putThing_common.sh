#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <payload_file_json-ld> [-E <DEV|QA>] [-i] [-h]"
}

function fetch_token_su
{
    # -H 'Content-Length: 0' (To avoid: Content-Length missing for POST or PUT requests)
    token=$(curl -s -X POST \
        -H 'Key: EDGUser' \
        -H 'SecretKey: Su_EDG_R1@2022' \
        -H "x-api-key: ${APIKey}" \
        -H "Content-Length: 0" \
        ${HOST}/auth)

    if [ -z "$token" ]; then
        echo "*** Failed to obtain token! ***"
        exit 1
    fi
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

# Accept: JSON-LD (default)
CONTTYPE="vnd.ecp.registry+json"

CacheCtrl=""
showEnv=""
SKIPTOKEN=""

ProjectID="ecp:8-db875efd-bde6-4e0e-82b9-478b4a8d94ee"

if (( $# >= 1 )); then
    JSONLD_FILE=$1
    shift
else
    display_help
    exit 1
fi

if [ ! -f ${JSONLD_FILE} ]; then
    echo "File '${JSONLD_FILE}' not found!"
    exit 1
fi

while getopts :hiE: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            else  # DEV
                . $WORKDIR/ENV_config/DEV.cfg
            fi
            ;;
        i)  showEnv="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
    else
        # DEV Env (default)
        . $WORKDIR/ENV_config/DEV.cfg
    fi
fi

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***" 1>&2
fi

fetch_token_su

payload="$(cat ${JSONLD_FILE})"
ECPID=$(echo $payload | grep -o 'ecp:[0-9]-[^"]*' | head -n 1)
echo ">> putThing (su) $ECPID" 1>&2

curl -w "Status_Code: %{http_code}\n" -s -X PUT ${HOST}/metadata/project/${ProjectID}/thing/${ECPID} -H "Content-Type: application/${CONTTYPE};api-version=1" -H "x-api-key: ${APIKey}" -H "Authorization: ${token}" -d "${payload}"
