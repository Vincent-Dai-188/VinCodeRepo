#!/bin/bash

function refetch_token
{
    # Outputs to stderr to avoid potential parse error when using jq
    echo "Re-Fetch Token ..." 1>&2
    
    # -H 'Content-Length: 0' (To avoid: Content-Length missing for POST or PUT requests)
    token=$(curl -s -X POST \
        -H "Key: ${uKey}" \
        -H "SecretKey: ${SecretKey}" \
        -H "x-api-key: ${APIKey}" \
        -H "Content-Length: 0" \
        ${HOST}/auth)

    if [ -z "$token" ]; then
        echo "*** Failed to obtain token! ***"
        exit 1
    fi
    echo -e "\nNew token:\n${token}\n"
}

# Seems HTTP_PROXY / HTTPS_PROXY doesn't work
http_proxy="http://webproxy.lon.corp.services:80"
https_proxy="http://webproxy.lon.corp.services:80"

# Sandbox Env
HOST="http://a204618junjielb-324114725.us-east-1.elb.amazonaws.com"
uKey="u6025971"
SecretKey="Rjr>NJgR9\BD.V-T"
#uKey="ecpregistry"
#SecretKey="s2MK2d@uE"
APIKey="gDtAPG68Im8ObNx6G0ZyG4PbYSyzfpjt3qT8VN20"

refetch_token
