#!/bin/bash

getThing $1 | jq -r '."@graph"[0]."http://www.w3.org/2000/01/rdf-schema#label"'