#!/bin/bash

Host='https://ecp-registry-qa-int.thomsonreuters.com'
projectID='ecp:8-84d0f73c-7df4-4270-b526-a0e6875f64f7'

token=$(curl -s -X POST \
    -H 'Key: u6064334' \
    -H 'SecretKey: M$FFXR_tH8b?Y~9!' \
    -H 'x-api-key: pVw5gWw9d48wKssfe7PV41O61b7SsHDk9AjYQqFA' \
    ${Host}/auth)

echo $token

for((i=0;i<414;i++)); do
    # Retrieve specified json block (json-ld) from list (.key=0 ~ NUM-1)
    payload=$(jq -r "to_entries[] | select (.key==${i}) | .value" ./OEM_LD_414.json)
    # Return the ecp-id (the 1st one, 3 in total in this case)
    ecpid=$(echo $payload | grep -o 'ecp:[0-9]-[^"]*' | head -n 1)
    echo [$i] ecp-id: $ecpid
    curl -X PUT \
      ${Host}/project/${projectID}/thing/${ecpid} \
      -H "Authorization: ${token}" \
      -H 'Content-Type: application/vnd.ecp.registry+json;api-version=1' \
      -H 'x-api-key: pVw5gWw9d48wKssfe7PV41O61b7SsHDk9AjYQqFA' \
      -d "${payload}"
done
