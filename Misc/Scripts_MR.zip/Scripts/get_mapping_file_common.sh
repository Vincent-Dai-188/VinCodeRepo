#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME [-E <DEV|QA|Sandbox>] [-F <mapping_file_name>] [-i] [-S] [-h]"
}

# Check login status
function check_login_status_aws
{
    PROFILE=$1
    ENVOPT=$2
    ret=$(aws --profile ${PROFILE} s3 ls s3://${S3BUCKET_ENV} 2>&1)
    ret_code=$?
    if [ $ret_code -ne 0 ]; then
        echo $ret | grep "ExpiredToken" &>/dev/null
        if [ $? -eq 0 ]; then
            echo "- Token Expired! Re-login ..." 1>&2
            ${WORKDIR}/login_aws ${ENVOPT}
            if [ $? -ne 0 ]; then
                return 2
            fi
        else
            echo "### Failed to access AWS resource. (errCode=$ret_code) ###"
            return 1
        fi
    fi
    return 0
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))
showEnv=""
SKIPTOKEN=""
MAPPINGFILE=""


while getopts :hiSE:F: paras
do
    case "$paras" in
        E)
            ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            elif [ "${ENV}" = "Sandbox" ]; then
                . $WORKDIR/ENV_config/Sandbox.cfg
            else  # DEV
                . $WORKDIR/ENV_config/DEV.cfg
            fi
            ;;
        F)
            MAPPINGFILE=${OPTARG}
            ;;
        i)  showEnv="true"
            ;;
        S)  SKIPTOKEN="true"    # Skip checking AWS token expiration
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
    else
        # DEV Env (default)
        . $WORKDIR/ENV_config/DEV.cfg
    fi
fi

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***"
fi

if [ -z $SKIPTOKEN ]; then
    check_login_status_aws ${AWSPROFILE} ${ENVOPT}
fi

if [ -z "${MAPPINGFILE}" ]; then
    echo ">> aws --profile ${AWSPROFILE} s3 ls s3://${S3BUCKET}/bulk/mapping/" 1>&2
    aws --profile ${AWSPROFILE} s3 ls s3://${S3BUCKET}/bulk/mapping/
else
    echo ">> aws --profile ${AWSPROFILE} s3 cp s3://${S3BUCKET}/bulk/mapping/${MAPPINGFILE}.ecpIds /tmp/things_s3/" 1>&2
    aws --profile ${AWSPROFILE} s3 cp s3://${S3BUCKET}/bulk/mapping/${MAPPINGFILE}.ecpIds /tmp/things_s3/
    if [ -s "/tmp/things_s3/${MAPPINGFILE}.ecpIds" ]; then
        #jq '.' /tmp/things_s3/${MAPPINGFILE}.ecpIds
        ls -lh /tmp/things_s3/${MAPPINGFILE}.ecpIds
    else
        exit 2
    fi
fi

