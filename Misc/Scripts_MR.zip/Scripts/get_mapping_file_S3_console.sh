#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <Dataset_Name|LIST> [-E <DEV|QA|Sandbox>] [-i] [-S] [-C] [-h]"
}

# Check login status
function check_login_status_aws
{
    PROFILE=$1
    ENVOPT=$2
	ret=$(aws --profile ${PROFILE} s3 ls s3://${S3BUCKET_ENV} 2>&1)
	ret_code=$?
	if [ $ret_code -ne 0 ]; then
		echo $ret | grep "ExpiredToken" &>/dev/null
		if [ $? -eq 0 ]; then
			echo "- Token Expired! Re-login ..." 1>&2
			${WORKDIR}/login_aws ${ENVOPT}
			if [ $? -ne 0 ]; then
				return 2
			fi
		else
			echo "### Failed to access AWS resource. (errCode=$ret_code) ###"
			return 1
		fi
	fi
	return 0
}

if (( $# < 1 )); then
    echo "Dataset_Name must be provided!"
    exit 1
fi

PID=$$
UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))
showEnv=""
SKIPTOKEN=""
checkExist=""

datasetName=$1
shift

# DEV Env (default)
ENV="DEV"
AWSPROFILE="a-corporate-preprod"
S3BUCKET="a204121-content-ecpmeta-devsnapshot-use1"
S3BUCKET_ENV="a204121-vincent-test"
ENVOPT="-M"

while getopts :hiSCE: paras
do
    case "$paras" in
        E)
            ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                AWSPROFILE="a-corporate-preprod"
                S3BUCKET="a204121-content-ecpmeta-qa-use1"
                S3BUCKET_ENV="a204121-vincent-test"
                ENVOPT="-M"
            elif [ "${ENV}" = "Sandbox" ]; then
                AWSPROFILE="tr-fr-sandbox"
                S3BUCKET="a204618-content-ecpmeta-devjunjiesun-use1"
                S3BUCKET_ENV="repo-mr-report"
                ENVOPT="-S"
            else    # DEV
                AWSPROFILE="a-corporate-preprod"
                S3BUCKET="a204121-content-ecpmeta-devsnapshot-use1"
                S3BUCKET_ENV="a204121-vincent-test"
                ENVOPT="-M"
            fi
            ;;
        i)  showEnv="true"
            ;;
        S)  SKIPTOKEN="true"    # Skip checking AWS token expiration
            ;;
        C)  checkExist="true"   # check if the mapping file for the specified Dataset name exists or not
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***"
fi

if [ -z $SKIPTOKEN ]; then
    check_login_status_aws ${AWSPROFILE} ${ENVOPT}
fi

if [ "${datasetName}" = "LIST" ]; then
    #echo "Bulk Mapping files list on $ENV: "
    #mappingSet="$(aws --profile ${AWSPROFILE} s3 ls s3://${S3BUCKET}/bulk/mapping/ | grep -o '[a-zA-Z0-9_-]\{1,50\}\.ecpIds')"

    # Consider the situation that spaces might exist in mapping file name
    mappingSet="$(aws --profile ${AWSPROFILE} s3 ls s3://${S3BUCKET}/bulk/mapping/ | grep -o '[a-zA-Z][^.]\{1,49\}\.ecpIds')"
    if [ -n "${mappingSet}" ]; then     # Arrange the mapping files list in Json array, e.g., ["DS1","DS2","DS3","DS4"].
        tmpMappingFile="/tmp/mappingSet_${ENV}_${PID}.lst"
        echo "${mappingSet}" > ${tmpMappingFile}
        retArray="["
        sn=0
        while read item; do
            DSstr=`echo "$item" | sed -e 's/^/"/;s/\.ecpIds/"/'`
            if (( sn == 0 )); then
                retArray=${retArray}${DSstr}
            else
                retArray=${retArray},${DSstr}
            fi
            (( sn += 1 ))
        done < ${tmpMappingFile}
        retArray="${retArray}]"
        rm -f ${tmpMappingFile}
        #echo $retArray > ./Reports/${ENV}/Bulk_Mapping/mapping_files_list.json
        echo $retArray
    else
        #echo "" > ./Reports/${ENV}/Bulk_Mapping/mapping_files_list.json
        echo "    null"
    fi
else
    mappingFile=$(aws --profile ${AWSPROFILE} s3 ls s3://${S3BUCKET}/bulk/mapping/"${datasetName}".ecpIds)
    if [ -n "${mappingFile}" ]; then
        if [ -z "$checkExist" ]; then
            echo ">> Copy MR data file '${datasetName}.ecpIds' in S3 to /tmp/mapping_file_s3/${ENV}/ ..." 1>&2
            aws --profile ${AWSPROFILE} s3 cp s3://${S3BUCKET}/bulk/mapping/"${datasetName}".ecpIds /tmp/mapping_file_s3/${ENV}/"${datasetName}".ecpIds 1>&2
            #cat /tmp/mapping_file_s3/${ENV}/"${datasetName}".ecpIds
        else
            echo "*** $mappingFile ***"
        fi
    else
        rm -f /tmp/mapping_file_s3/${ENV}/"${datasetName}".ecpIds
        echo "Mapping file for Dataset '${datasetName}' not found in S3!"
        exit 1
    fi
fi
