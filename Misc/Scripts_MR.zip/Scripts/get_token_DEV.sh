#!/bin/bash

function refetch_token
{
    # Outputs to stderr to avoid potential parse error when using jq
    echo "Re-Fetch Token ..." 1>&2
    
    # -H 'Content-Length: 0' (To avoid: Content-Length missing for POST or PUT requests)
    token=$(curl -s -X POST \
        -H "Key: ${uKey}" \
        -H "SecretKey: ${SecretKey}" \
        -H "x-api-key: ${APIKey}" \
        -H "Content-Length: 0" \
        ${HOST}/auth)

    if [ -z "$token" ]; then
        echo "*** Failed to obtain token! ***"
        exit 1
    fi
    echo -e "\nNew token:\n${token}\n"
}

# DEV Env
HOST="https://registry-ecp-devs.a-corporate-preprod.aws-int.thomsonreuters.com"
uKey="u6025979"
SecretKey="Rjr>NJgR9\BD.V-T"
APIKey="pVw5gWw9d48wKssfe7PV41O61b7SsHDk9AjYQqFA"

refetch_token
