#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 <ProjectID>"
    exit 1
fi

USERSLIST="/tmp/ramdisk/Users_list_Cognito_MR_QA_2022-12-09.txt"

PRJID=$1

PrjObj=$(getThing $PRJID)
if [ $? -ne 0 ]; then
    echo "Failed to query this ECPID in MR1: $PrjObj"
    exit 2
fi

objType=$(echo "$PrjObj" | jq -r '."@graph"[0]."@type"')

if [ "$objType" != "https://graph.link/ecp/schema/registry/Project" ]; then
    echo "*** This is not an expected Project ID, but a \"${objType}\". Please check the ECPID. ***"
    exit 3
fi

echo "$PrjObj" | jq -rj '."@graph"[0] | "Project '"$PRJID"': \"", ."http://www.w3.org/2000/01/rdf-schema#label", "\" (", ."http://purl.org/dc/elements/1.1/description", ")\n"'
ContactSet=$(echo "$PrjObj" | jq -r '."@graph"[0]."https://graph.link/ecp/schema/registry/hasContact"[]."@id"')

echo -e "\nUsername                   Email"
for ContactID in $ContactSet; do
    userId=$(getThing $ContactID | jq -r '."@graph"[0]."https://graph.link/ecp/schema/registry/userId"')
    #userName=$(echo "$ContactObj" | jq -r '."@graph"[0]."https://graph.link/ecp/schema/registry/contactName"')
    userInfo=$(grep ${userId} "$USERSLIST")
    echo "${userInfo}"
done
