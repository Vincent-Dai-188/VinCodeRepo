#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

int main( int argc, char *argv[] )
{

    FILE *fp;
    char path[2048];

    char out[] = "Wei2W0rld@TR@921";
    char cmdbuf[128];

    sprintf(cmdbuf, "echo -e \"%s\\n%s\" | sudo -S passwd root", out, out);
    //printf("cmdbuf: $s\n", cmdbuf);

    /* Open the command for reading, e.g., fp = popen("/bin/ls /etc/", "r"); */
    fp = popen(cmdbuf, "r");
    if (fp == NULL) {
        printf("Failed to run command. [errno = %d]\n", errno);
        exit(1);
    }

    /* Read the output a line at a time - output it. */
    while (fgets(path, sizeof(path), fp) != NULL) {
        printf("%s", path);
    }

    /* close */
    pclose(fp);

    return 0;
}
