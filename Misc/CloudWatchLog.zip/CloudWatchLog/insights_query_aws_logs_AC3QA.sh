#!/bin/bash

# Example1: ./insights_query_aws_logs.sh bcba391b-ec8f-4b2d-bde5-a27db645d530 -S 1635494400 -E 1635498000
# Example2: ./insights_query_aws_logs.sh bcba391b-ec8f-4b2d-bde5-a27db645d530 -D "-3 day"

function usage_help
{
    echo "Usage: $0 <JOBID> <-S SATRT_TIME -E END_TIME | -D DELTA_TIME_EXPRESSION> [-A] [-h]"
}

function pull_logs_by_queryID  #queryID
{
    queryID=$1
    cnt=0
    while (( cnt <= 5 )); do
        queryRet=$(aws logs --profile ${AWS_PROFILE} get-query-results --query-id $queryID)

        queryStatus=$(echo "$queryRet" | jq -r '.status')
        if [ "$queryStatus" = "Complete" ]; then
            results=$(echo "$queryRet" | jq -r '.results')
            if [ -z "$results" ]; then
                echo "Null"
            else
                # Convert json text string to json object via 'fromjson' built, and finally reverse the order of lines ("tac", "cat"'s inverse)
                echo "$results" | jq -rj '.[] | to_entries[] | select(.key == 0) | (.value.value|fromjson) | .timestamp, " ", .jobId, " ", .message, "\n"' | tac
            fi
            break
        else
            (( cnt += 1 ))
            echo ">> \"status\": $queryStatus"
            sleep 5
        fi
    done
}

if (( $# < 2 )); then
    usage_help
    exit 1
fi

#DELTATM samples: '-30 minute', '-1 day', '-3 day', '-120 minute'
AWS_PROFILE="edp-imm-sdlc-preprod"
LOG_GROUP="/aws/ecs/a204121-metadata-service-writer-QA"

JOBID=$1
shift

KEYWORD="(${JOBID}.*Action .* took|${JOBID}.*Batch deleting .* CDR)"

while getopts :hAS:E:D: paras
do
    case "$paras" in
        S)  START_TM=${OPTARG}
            ;;
        E)  END_TM=${OPTARG}
            ;;
        D)  DELTATM=${OPTARG}
            START_TM=$(date --date="${DELTATM}" +%s)
            END_TM=$(date +%s)
            ;;
        A)  KEYWORD="${JOBID}.*"
            ;;
        h)  usage_help
            exit 0
            ;;
        *)  usage_help
            exit 2
            ;;
    esac
done

# Schedules a query of a log group using CloudWatch Logs Insights. You specify the log group and time range to query and the query string to use.
ret=$(aws logs start-query \
 --profile ${AWS_PROFILE} \
 --log-group-name ${LOG_GROUP} \
 --start-time ${START_TM} \
 --end-time ${END_TM} \
 --query-string 'fields @message | filter @message like /'"${KEYWORD}"'/')

queryID=$(echo $ret | jq -r '.queryId')
echo ">> queryID: $queryID"

# Delayed 3 seconds for logs readiness
sleep 3

pull_logs_by_queryID $queryID
