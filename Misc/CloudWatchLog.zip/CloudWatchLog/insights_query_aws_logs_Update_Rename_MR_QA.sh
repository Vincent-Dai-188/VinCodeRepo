#!/bin/bash

# Example1: ./insights_query_aws_logs.sh ecp:9-31cff4fc-31d4-4f24-b62d-195c01ede172 -s "2022-12-08T10:25" -e "2022-12-08T10:40"
# Example2: ./insights_query_aws_logs.sh ecp:9-31cff4fc-31d4-4f24-b62d-195c01ede172 -S 1635494400 -E 1635498000
# Example3: ./insights_query_aws_logs.sh ecp:9-31cff4fc-31d4-4f24-b62d-195c01ede172 -D "-3 hour"

function usage_help
{
    echo "Usage: $0 <THINGID> <-s SATRT_DATETIME -e END_DATETIME | -S SATRT_TIME(s) -E END_TIME(s) | -D DELTA_TIME_EXPRESSION> [-L LIMITS] [-h]"
}

function pull_logs_by_queryID  #queryID
{
    queryID=$1
    cnt=0
    while (( cnt <= 5 )); do
        queryRet=$(aws logs --profile ${AWS_PROFILE} get-query-results --query-id $queryID)

        queryStatus=$(echo "$queryRet" | jq -r '.status')
        if [ "$queryStatus" = "Complete" ]; then
            results=$(echo "$queryRet" | jq -r '.results')
            if [ -z "$results" ]; then
                echo "Null"
            else
                echo "$results" | jq '[.[] | .[0]."value"| fromjson | with_entries(select (.key != "requestHeaders"))]'
            fi
            break
        else
            (( cnt += 1 ))
            echo ">> \"status\": $queryStatus"
            sleep 5
        fi
    done
}

if (( $# < 2 )); then
    usage_help
    exit 1
fi

#DELTATM samples: '-30 minute', '-1 day', '-3 hour', '-120 minute'
AWS_PROFILE="a-corporate-preprod"
LOG_GROUP="/ecs/a204121-auditlogs-meta-qa-use1"
LIMITS="100"

THINGID=$1
shift

while getopts :hs:e:S:E:D:L: paras
do
    case "$paras" in
        s)  DT_START=${OPTARG}
            START_TM=$(date -d"${DT_START}" +%s)
            ;;
        e)  DT_END=${OPTARG}
            END_TM=$(date -d"${DT_END}" +%s)
            ;;
        S)  START_TM=${OPTARG}
            ;;
        E)  END_TM=${OPTARG}
            ;;
        D)  DELTATM=${OPTARG}
            START_TM=$(date --date="${DELTATM}" +%s)
            END_TM=$(date +%s)
            ;;
        L)  LIMITS=${OPTARG}
            ;;
        h)  usage_help
            exit 0
            ;;
        *)  usage_help
            exit 2
            ;;
    esac
done

KEYWORD="(UpdateThing.*${THINGID}|RenameThing.*${THINGID})"

# Schedules a query of a log group using CloudWatch Logs Insights. You specify the log group and time range to query and the query string to use.
ret=$(aws logs start-query \
 --profile ${AWS_PROFILE} \
 --log-group-name ${LOG_GROUP} \
 --start-time ${START_TM} \
 --end-time ${END_TM} \
 --query-string 'fields @message | filter @message like /'"${KEYWORD}"'/ | limit '${LIMITS}'')

queryID=$(echo $ret | jq -r '.queryId')
echo ">> queryID: $queryID"

# Delayed 3 seconds for logs readiness
sleep 3

pull_logs_by_queryID $queryID
