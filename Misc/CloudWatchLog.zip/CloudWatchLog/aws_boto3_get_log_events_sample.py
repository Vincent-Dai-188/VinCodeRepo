import boto3

client = boto3.client('logs')

response = client.get_log_events(
    logGroupName='AutoPilot_CAT_AWS',
    logStreamName='i-01bab6026bd1904ce',
    startTime=1554712587000,
    endTime=1554838787000,
    limit=20,
    startFromHead=False
)

print response

------------------------------------------

(venv_awslogs) [204618-PowerUser@ip-10-0-137-62 venv_awslogs]$ python ./test_log.py
{'ResponseMetadata': {'RetryAttempts': 0, 'HTTPStatusCode': 200, 'RequestId': 'c59db196-5c17-11e9-82f7-410316abe9af', 'HTTPHeaders': {'x-amzn-requestid': 'c59db196-5c17-11e9-82f7-410316abe9af', 'date': 'Thu, 11 Apr 2019 05:07:57 GMT', 'content-length': '5375', 'content-type': 'application/x-amz-json-1.1'}}, u'nextForwardToken': u'f/34671258650902890964996083152734010178953663099791147011', u'events': [{u'ingestionTime': 1554712597641, u'timestamp': 1554712591480, u'message': u'Terminate_Cluster_EMR                                            NOTSTARTED                                   2019-04-03 09:59:46 '}, {u'ingestionTime': 1554712635727, u'timestamp': 1554712630497, u'message': u'Action                                                           Status      Spark job id                     Last updated        '}, {u'ingestionTime': 1554712635727, u'timestamp': 1554712630498, u'message': u'------                                                           ------      ------------                     ------------        '}, {u'ingestionTime': 1554712635727, u'timestamp': 1554712630498, u'message': u'DataNorm_DealsNI_BondPkgInfo                                     SUCCESS     j-1NPHHN2JAYQ7Z::s-ZABL95N3XO55  2019-04-04 09:32:16 '}, {u'ingestionTime': 1554712635727, u'timestamp': 1554712630498, u'message': u'DataNorm_DIR_Full                                                SUCCESS     j-1NPHHN2JAYQ7Z::s-3UAM7U9WOFY1R 2019-04-04 09:43:16 '}, {u'ingestionTime': 1554712635727, u'timestamp': 1554712630498, u'message': u'Terminate_Cluster_EMR                                            SUCCESS                                      2019-04-04 09:43:19 '}, {u'ingestionTime': 1554712990155, u'timestamp': 1554712984108, u'message': u'Action                                                           Status      Spark job id                     Last updated        '}, {u'ingestionTime': 1554712990155, u'timestamp': 1554712984108, u'message': u'------                                                           ------      ------------                     ------------        '}, {u'ingestionTime': 1554712990155, u'timestamp': 1554712984109, u'message': u'EnrichBatch_TRF_stdtempview                                      SUCCESS     j-1P978O2SWSGIN::s-XJIS4DU5LEWK  2019-04-03 10:11:49 '}, {u'ingestionTime': 1554712990155, u'timestamp': 1554712984109, u'message': u'EnrichBatch_TRF_industrygroup                                    FAILED      j-1P978O2SWSGIN::s-LQLRPGSO8ELE  2019-04-03 10:17:18 '}, {u'ingestionTime': 1554712990155, u'timestamp': 1554712984110, u'message': u'Terminate_Cluster_EMR                                            NOTSTARTED                                   2019-04-03 09:59:46 '}, {u'ingestionTime': 1554712990155, u'timestamp': 1554712984110, u'message': u'Action                                                           Status      Spark job id                     Last updated        '}, {u'ingestionTime': 1554712990155, u'timestamp': 1554712984111, u'message': u'------                                                           ------      ------------                     ------------        '}, {u'ingestionTime': 1554712990155, u'timestamp': 1554712984111, u'message': u'DataNorm_DealsNI_BondPkgInfo                                     SUCCESS     j-1NPHHN2JAYQ7Z::s-ZABL95N3XO55  2019-04-04 09:32:16 '}, {u'ingestionTime': 1554712990155, u'timestamp': 1554712984111, u'message': u'DataNorm_DIR_Full                                                SUCCESS     j-1NPHHN2JAYQ7Z::s-3UAM7U9WOFY1R 2019-04-04 09:43:16 '}, {u'ingestionTime': 1554712990155, u'timestamp': 1554712984112, u'message': u'Terminate_Cluster_EMR                                            SUCCESS                                      2019-04-04 09:43:19 '}, {u'ingestionTime': 1554713013227, u'timestamp': 1554713008119, u'message': u'Pipeline                                                    Status              '}, {u'ingestionTime': 1554713013227, u'timestamp': 1554713008119, u'message': u'--------                                                    ------              '}, {u'ingestionTime': 1554713013227, u'timestamp': 1554713008119, u'message': u'DataNorm_autotest_D2_r32x3_023                              Stopped             '}, {u'ingestionTime': 1554713013227, u'timestamp': 1554713008119, u'message': u'Enrich_TRF_autotest_r44x4_023                               Stopped            n'}], u'nextBackwardToken': u'b/34671249359542712194395787584021157201576973501436919812'}


{
  'ResponseMetadata': {
    'RetryAttempts': 0,
    'HTTPStatusCode': 200,
    'RequestId': 'c59db196-5c17-11e9-82f7-410316abe9af',
    'HTTPHeaders': {
      'x-amzn-requestid': 'c59db196-5c17-11e9-82f7-410316abe9af',
      'date': 'Thu, 11 Apr 2019 05:07:57 GMT',
      'content-length': '5375',
      'content-type': 'application/x-amz-json-1.1'
    }
  },
  u 'nextForwardToken': u 'f/34671258650902890964996083152734010178953663099791147011',
  u 'events': [{
      u 'ingestionTime': 1554712597641,
      u 'timestamp': 1554712591480,
      u 'message': u 'Terminate_Cluster_EMR                                            NOTSTARTED                                   2019-04-03 09:59:46 '
    }, {
      u 'ingestionTime': 1554712635727,
      u 'timestamp': 1554712630497,
      u 'message': u 'Action                                                           Status      Spark job id                     Last updated        '
    }, {
      u 'ingestionTime': 1554712635727,
      u 'timestamp': 1554712630498,
      u 'message': u '------                                                           ------      ------------                     ------------        '
    }, {
      u 'ingestionTime': 1554712635727,
      u 'timestamp': 1554712630498,
      u 'message': u 'DataNorm_DealsNI_BondPkgInfo                                     SUCCESS     j-1NPHHN2JAYQ7Z::s-ZABL95N3XO55  2019-04-04 09:32:16 '
    }, {
      u 'ingestionTime': 1554712635727,
      u 'timestamp': 1554712630498,
      u 'message': u 'DataNorm_DIR_Full                                                SUCCESS     j-1NPHHN2JAYQ7Z::s-3UAM7U9WOFY1R 2019-04-04 09:43:16 '
    }, {
      u 'ingestionTime': 1554712635727,
      u 'timestamp': 1554712630498,
      u 'message': u 'Terminate_Cluster_EMR                                            SUCCESS                                      2019-04-04 09:43:19 '
    }, {
      u 'ingestionTime': 1554712990155,
      u 'timestamp': 1554712984108,
      u 'message': u 'Action                                                           Status      Spark job id                     Last updated        '
    }, {
      u 'ingestionTime': 1554712990155,
      u 'timestamp': 1554712984108,
      u 'message': u '------                                                           ------      ------------                     ------------        '
    }, {
      u 'ingestionTime': 1554712990155,
      u 'timestamp': 1554712984109,
      u 'message': u 'EnrichBatch_TRF_stdtempview                                      SUCCESS     j-1P978O2SWSGIN::s-XJIS4DU5LEWK  2019-04-03 10:11:49 '
    }, {
      u 'ingestionTime': 1554712990155,
      u 'timestamp': 1554712984109,
      u 'message': u 'EnrichBatch_TRF_industrygroup                                    FAILED      j-1P978O2SWSGIN::s-LQLRPGSO8ELE  2019-04-03 10:17:18 '
    }, {
      u 'ingestionTime': 1554712990155,
      u 'timestamp': 1554712984110,
      u 'message': u 'Terminate_Cluster_EMR                                            NOTSTARTED                                   2019-04-03 09:59:46 '
    }, {
      u 'ingestionTime': 1554712990155,
      u 'timestamp': 1554712984110,
      u 'message': u 'Action                                                           Status      Spark job id                     Last updated        '
    }, {
      u 'ingestionTime': 1554712990155,
      u 'timestamp': 1554712984111,
      u 'message': u '------                                                           ------      ------------                     ------------        '
    }, {
      u 'ingestionTime': 1554712990155,
      u 'timestamp': 1554712984111,
      u 'message': u 'DataNorm_DealsNI_BondPkgInfo                                     SUCCESS     j-1NPHHN2JAYQ7Z::s-ZABL95N3XO55  2019-04-04 09:32:16 '
    }, {
      u 'ingestionTime': 1554712990155,
      u 'timestamp': 1554712984111,
      u 'message': u 'DataNorm_DIR_Full                                                SUCCESS     j-1NPHHN2JAYQ7Z::s-3UAM7U9WOFY1R 2019-04-04 09:43:16 '
    }, {
      u 'ingestionTime': 1554712990155,
      u 'timestamp': 1554712984112,
      u 'message': u 'Terminate_Cluster_EMR                                            SUCCESS                                      2019-04-04 09:43:19 '
    }, {
      u 'ingestionTime': 1554713013227,
      u 'timestamp': 1554713008119,
      u 'message': u 'Pipeline                                                    Status              '
    }, {
      u 'ingestionTime': 1554713013227,
      u 'timestamp': 1554713008119,
      u 'message': u '--------                                                    ------              '
    }, {
      u 'ingestionTime': 1554713013227,
      u 'timestamp': 1554713008119,
      u 'message': u 'DataNorm_autotest_D2_r32x3_023                              Stopped             '
    }, {
      u 'ingestionTime': 1554713013227,
      u 'timestamp': 1554713008119,
      u 'message': u 'Enrich_TRF_autotest_r44x4_023                               Stopped            n'
    }
  ],
  u 'nextBackwardToken': u 'b/34671249359542712194395787584021157201576973501436919812'
}
