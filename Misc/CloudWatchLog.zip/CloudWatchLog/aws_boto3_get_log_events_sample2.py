import boto3
import json

client = boto3.client('logs')

response_dict = client.get_log_events(
    logGroupName='AutoPilot_CAT_AWS',
    logStreamName='i-01bab6026bd1904ce',
    startTime=1554712587000,
    endTime=1554838787000,
    limit=5,
    startFromHead=False
)

events_list = response_dict['events']

''' Output 'message' via json object '''
for litem in events_list:
    #print type(litem)              # Output <type 'dict'>
    #print litem                    # {u'ingestionTime': 1554713013227, u'timestamp': 1554713008119, u'message': u'DataNorm_autotest_D2_r32x3_023                              Stopped             '}
    dictstr = json.dumps(litem, indent=2, sort_keys=True)     # Convert dict to string
    print dictstr
    jsonobj = json.loads(dictstr)   # With "json.loads(str(litem))" directly, will hit "ValueError: Expecting property name: line 1 column 2" /* cuased by the unicode mark 'u' */
    #print type(jsonobj)            # Output <type 'dict'>
    print jsonobj['message']

''' Output 'message' from dictionary object directly '''
for litem in events_list:
    print litem['message']
