#!/bin/bash

if (( $# < 2 )); then
	echo "Usgae: $0 <json_file> <keyword>"
	exit 2
fi

JSONFILE=$1
keyWord=$2

ret=$(jq -c --arg argV "$keyWord" 'paths | select(.[-1] == $argV)' $JSONFILE)
echo "$ret" | sed -e "s/,\([0-9]\{1,3\}\),/[\1]./g;s/\",\"/\".\"/g;s/^\[/./g;s/\]$//g"
#echo "$ret"
