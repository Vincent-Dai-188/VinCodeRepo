#!/bin/bash

JSONFILE=$1
JSONCONTENT=$(cat "${JSONFILE}")

# Validation check on: 1) "IsCollectionKeySet": 'Y' should be set to OneToManyDataElement only, 2) DEParentId belongs to corresponding ContentItemId
echo -e "\n========= Validation check on: 1) \"IsCollectionKeySet\":'Y' for OneToManyDataElement (OTM) only, 2) OTMId belongs to paired CIId ========="
CIandOTMSet=$(echo "$JSONCONTENT" | jq -rj '.[] | select (."IsCollectionKeySet" == "Y") | ."ContentItemId", ",", ."DataElementParentId", "\n"')
for itemSet in $CIandOTMSet; do
	CIId=$(echo "$itemSet" | awk -F',' '{print $1}')
	OTMId=$(echo "$itemSet" | awk -F',' '{print $2}')
	echo -n "- CIId,OTMId: $CIId,$OTMId  "
	retThing=$(getThing $OTMId)
    if [ $? -eq 0 ]; then
		dataType=$(echo "$retThing" | jq -r '."@graph"[0]."@type"' | sed 's,https://graph.link/ecp/schema/CDF/,,')
		if [ "$dataType" == "OneToManyDataElement" ]; then
			echo -n "PASS  "
		else
			echo -n "ERROR ($dataType)  "
		fi
		#ret=$(check_DEs_dataStructure_by_CI.sh $CIId | grep $OTMId)
		ret=$(./ret_CIs_by_DE.sh $OTMId | grep $CIId)
		if [ $? -eq 0 ]; then
			echo "PASS"
		else
			echo "ERROR"
		fi
	else
		echo "ERROR ($retThing)"
	fi
done

# Validation check on situation of 'Y' for both "IsCollectionKeySet" & "IsCollectionKeyElement" columns
echo -e "\n======= Validation check on 'Y' for both \"IsCollectionKeySet\" & \"IsCollectionKeyElement\" ======="
ErrKeyElementSet=$(echo "$JSONCONTENT" | jq -rj '.[] | select ((."IsCollectionKeySet" == "Y") and (."IsCollectionKeyElement" == "Y")) | ."DataElementParentId", ",", ."DataElementId","\n"')
if [ -z "$ErrKeyElementSet" ]; then
	echo "PASS"
else
	echo "ERRORs detected for DEs below with 'Y' for both \"IsCollectionKeySet\" & \"IsCollectionKeyElement\":"
	echo "DEParentId,DEId"
	for errItem in $ErrKeyElementSet; do
		echo $errItem
	done
fi

CISet=$(echo "$JSONCONTENT" | jq -r '.[] | select (."ContentItemId" | startswith("ecp:")) | ."ContentItemId"' | awk '!x[$0]++')

# Validation check on combination of "IsCollectionKeySet" and "IsCollectionKeyElement"
echo -e "\n===== Validation check on combination of \"IsCollectionKeySet\" and \"IsCollectionKeyElement\" ====="

CIIdx=0
for CIId in $CISet; do
    (( CIIdx++ ))
    printf "[%02d] CI: %s " $CIIdx $CIId

    CICONTENT=$(echo "$JSONCONTENT" | jq --arg vCIId "$CIId" '[.[] | select (."ContentItemId" == $vCIId)]')

    # Retrieve number of unique OTMs for IsCollectionKeySet
    KeySetOTMNum=$(echo "$CICONTENT" | jq -r '.[] | select (."IsCollectionKeySet" == "Y") | ."DataElementParentId"' | awk '!x[$0]++' | wc -l)
    if (( KeySetOTMNum > 0 )); then
        echo -n "( KeySets: $KeySetOTMNum    "
    else
        echo -n "( KeySets: null "
    fi
    # Retrieve number of unique OTOs for IsCollectionKeyElement
    KeyEleOTONum=$(echo "$CICONTENT" | jq -r '.[] | select (."IsCollectionKeyElement" == "Y") | ."DataElementParentId"' | awk '!x[$0]++' | wc -l)
    if (( KeyEleOTONum > 0 )); then
        echo -n " KeyElements: $KeyEleOTONum    )"
    else
        echo -n " KeyElements: null )"
        KElementVal=1
    fi
    if (( KeySetOTMNum == KeyEleOTONum )); then
        echo "  PASS"
    else
        echo "  ERROR"
    fi
done

# Validation check on "Order" ("seq") in collectionKey array
echo -e "\n================= Validation check on \"Order\" in each collectionKeySet (array) ================="

# Retrieve all the unique DataElementParentId (OTOIds, valid only) from collectionKey population json with the order of original occurrence
OTOIdSet=$(echo "$JSONCONTENT" | jq -r '.[] | select ((."DataElementParentId" | startswith("ecp:")) and (."IsCollectionKeyElement" == "Y")) | ."DataElementParentId"' | awk '!x[$0]++')
for OTOId in $OTOIdSet; do
    echo -n " - OTOId: $OTOId  "
    seqSet=$(echo "$JSONCONTENT" | jq --arg vOTOID "$OTOId" -r '[sort_by(."seq") | .[] | select ((."DataElementParentId" == $vOTOID) and (."IsCollectionKeyElement" == "Y")) | .]')
    seqNum=$(echo "$seqSet" | jq '. | length')
    (( seqNum-- ))
    seqSet=$(echo "$seqSet" | jq -r '.[] | ."seq"')
    seqSetStr=$(echo "Act:["${seqSet}"]")
    printf "%-18s" "$seqSetStr"
    exp_seqSet=$(seq 0 $seqNum)
    exp_seqSetStr=$(echo "Exp:["${exp_seqSet}"]")
    printf "%-18s" "$exp_seqSetStr"
    if [ "$seqSet" = "$exp_seqSet" ]; then
        echo "PASS"
    else
        echo "ERROR"
    fi

# Validation check on "minLength" & "maxLength" with value of 0
echo -e "\n================= Validation check on on \"minLength\" and \"maxLength\" with value of 0 ================="

miniZeroSet=$(echo "$JSONCONTENT" | jq -rj '.[] | select( (."minLength" == 0) or (."maxLength" == 0)) | ."DataElementId", ",", ."minLength", ",", ."maxLength","\n"')
if [ -z "$miniZeroSet" ]; then
	echo "PASS"
else
	echo "ERRORs detected for DEs below with \"minLength\" or \"maxLength\" of 0:"
	echo "DataElementId,minLength,maxLength"
	for miniZeroLine in $miniZeroSet; do
		echo $miniZeroLine
	done
fi
