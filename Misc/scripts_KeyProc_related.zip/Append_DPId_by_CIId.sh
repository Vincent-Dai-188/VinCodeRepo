#!/bin/bash

function get_DPId_by_CIId	# CIId
{
	CIID=$1
    sed "s/%CIID%/${CIID}/" $TplFile > $SparqlFile

	# Convert sparql in plain text to URL
	QUERYSPL=`./URL_convert_SparQL.sh "$(cat ${SparqlFile})"`

	ret=$(curl -s -X GET ${SPARQL_HOST}/metadata/sparql?query="${QUERYSPL}" -H "Accept: application/sparql-results+json")

	if [ -n "$ret" ]; then
		echo "$ret" | jq -r '."results"."bindings"[0].dpId.value'
	else
		exit 1
	fi
}

SPARQL_HOST="http://a204121qanlb-2588124a14c0d9c1.elb.us-east-1.amazonaws.com"
TplFile="sparql_ret_DPCV_by_CI.tpl"
SparqlFile="sparql_ret_DPCV_by_CI.sparql"

sourceFile="Fundies_Full_Test.json"
outputFile="output_${sourceFile}"

JSONCONTENT=$(cat "${sourceFile}")

CISet=$(echo "$JSONCONTENT" | jq -r '.[]."ContentItemId"' | sort -u)

CIIdx=0
for CIId in $CISet; do
	(( CIIdx++ ))
	printf "[%02d] CI: %s\n" $CIIdx $CIId
	# Get DPId by CIId
	DPId=$(get_DPId_by_CIId $CIId)

	if [ $? -ne 0 ]; then
		echo "Failed to retrieve DP Id by CI Id!"
		exit 2
	fi
	echo " - DP: $DPId"
	# Replace CI with combination of DP & CI
	JSONCONTENT=$(echo "$JSONCONTENT" | sed "s/\"ContentItemId\":\"${CIId}\"/\"DistributionPairId\":\"${DPId}\",\"ContentItemId\":\"${CIId}\"/g")
done

# Finally, write modified content to json file
echo ">>> Save JSONCONTENT to '${outputFile}'. <<<"
echo "$JSONCONTENT" > "${outputFile}"
