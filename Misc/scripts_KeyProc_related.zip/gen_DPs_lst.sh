#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 <collectionKey population json file>"
    exit 2
fi

SOURCEFILE=$1

TAG=$(echo $SOURCEFILE | awk -F'_' '{print $1}')

jq -r '.[] | select (."DistributionPairId" | startswith("ecp:")) | ."DistributionPairId"' $SOURCEFILE | awk '!x[$0]++' > ${TAG}_DPs.lst

echo "Generate '${TAG}_DPs.lst', done."
