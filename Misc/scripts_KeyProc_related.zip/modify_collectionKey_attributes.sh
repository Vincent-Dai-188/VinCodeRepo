#!/bin/bash

function ret_path_otm_oto_csv	#JSONCONTENT
{
    JSONCONTENT=$1
    keyPaths=$(echo "$JSONCONTENT" | jq -c 'paths | select(.[-1] == "collectionKey")')
	echo "keyBasePath,OTMId,OTOId" > $PATH_OTM_OTO_FILE_PER_DP
    for pathItem in $keyPaths; do
        basePath=$(echo "$pathItem" | sed 's/\,"collectionKey"//')
		OTM_OTO=$(echo "$JSONCONTENT" | jq --argjson bPATH "$basePath" -rj 'getpath($bPATH) | ."_meta"."businessId", ";", ."isCollectionOf"."_meta"."businessId", "\n"')
		echo "${basePath};${OTM_OTO}" >> $PATH_OTM_OTO_FILE_PER_DP
	done
}

collKey_population="Fundamentals_collectionKey_population.json"

TMPWORKDIR="./tmp_workplace"
source_dir_payload="./export_RCF/orig"
output_dir_payload="./export_RCF/collKey_Mod"

# Retrieve all the unique DPIds from collectionKey population json
DPIdSet=$(jq -r '.[]."DistributionPairId"' "$collKey_population" | uniq)
echo " [DBG] DPIdSet:" && echo "$DPIdSet"

for DPId in $DPIdSet; do
	DPtag="${DPId:38:4}"

	PATH_OTM_OTO_FILE_PER_DP="${TMPWORKDIR}/path_OTM_OTO_per_DP_${DPtag}.txt"
	collKeyArraysPerDP="${TMPWORKDIR}/collectionKey_arrays_per_DP_${DPtag}.json"
	collKeyItemsPerDP="${TMPWORKDIR}/collectionKey_items_per_DP_${DPtag}.json"

    Fn=$(echo "$DPId" | sed 's/ecp://')
	payloadFn="$(ls ${source_dir_payload}/${Fn}_*.json 2> /dev/null)"
	if [ -z "$payloadFn" ]; then
		echo "*** Payload file for DPId '$DPId' not found! ****"
		continue
	else
		echo " [DBG] Payload file for DPId '$DPId': $payloadFn "
		baseName=$(basename "$payloadFn")
		Payload_full_per_DP="${output_dir_payload}/$baseName"
		JsonContent_per_DP=$(cat "$payloadFn")
	fi

	collKey_population_per_DP=$(echo "$collKey_population" | sed -e "s,^,${TMPWORKDIR}/per_DP_${DPtag}_,")
	# Extract each collectionKey population json per DPId
	jq --arg vID "$DPId" '[.[] | select (."DistributionPairId" == $vID)]' "$collKey_population" > $collKey_population_per_DP

	# Generate 'PATH_OTM_OTO' file
	ret_path_otm_oto_csv "$JsonContent_per_DP"
	echo ">> Generate 'PATH_OTM_OTO' file, done."

	# Generate 'collectionKey_Arrays' file
	jq '[.[] | select (."IsCollectionKey" == "y") | with_entries(select ((.key | startswith("ContentItem") or startswith("DataElement")) or .key == "IsCollectionKey"))]' "$collKey_population_per_DP" > "$collKeyArraysPerDP"
	echo ">> Generate 'collectionKey_Arrays' file, done."

	# Generate 'collectionKey_Items' file
	jq '[.[] | select (."Is Collection Key" == "y") | with_entries(select (.key != "IsCollectionKey"))]' "$collKey_population_per_DP" > "$collKeyItemsPerDP"
	echo ">> Generate 'collectionKey_Items' file, done."

	OTMIdSet=$(jq -r '.[]."DataElementParentId"' "$collKeyArraysPerDP" | uniq)
	cnt=0
	for OTMID in $OTMIdSet; do
		(( cnt++ ))
		printf "[%02d] OTMID: %s\n" $cnt $OTMID

		# Get the base path to collectionKey array for specified OTMId
		basePath=$(grep $OTMID $PATH_OTM_OTO_FILE_PER_DP | awk -F';' '{print $1}')

		# Get OTOId under OTMId from envelope payload json
		Path_to_OTOId=$(echo "${basePath}" | sed 's/]$/,"isCollectionOf","_meta","businessId"]/')
		OTOID=$(echo "$JsonContent_per_DP" | jq --argjson vPath "$Path_to_OTOId" -r 'getpath($vPath)')
		#echo ">> OTOID: $OTOID"

		# Retrieve DEIds with collectionKey item by OTOId from collectionKey population json
		keyDEIdset=$(jq --arg OTOId "${OTOID}" -r 'sort_by(."seq") | .[] | select (."DataElementParentId" == $OTOId) | ."DataElementId"' "${collKeyItemsPerDP}")
		#echo ">> keyDEIdset: $keyDEIdset"
		if [ -z "$keyDEIdset" ]; then
			echo "*** Failed to get DEIds with collectionKey item by OTOId '{OTOID}' from collectionKey population json! ***"
			continue
		fi

		# Retrieve all the DEIds under OTOId in envelope payload json
		Path_to_DEs_array=$(echo "${basePath}" | sed 's/]$/,"isCollectionOf","consistsOf"]/')
		IDset=$(echo "$JsonContent_per_DP" | jq --argjson vPath "${Path_to_DEs_array}" -r 'getpath($vPath)[] | ."_meta"."businessId"')
		#echo ">> IDset: $IDset"

		# Put IDset into an associative array with index (0,1,...)
		declare -A DEArray=()
		i=0
		for ID in $IDset; do
			DEArray+=([$ID]=$((i++)))
		done

		declare -a Array_keyIems=()
		for tgtID in ${keyDEIdset}; do
			echo ">> DEId: $tgtID"
			idx=$(echo ${DEArray[$tgtID]})
			echo "  - idx = $idx"

			# Get collectionKey attributes (excluding all the keys with value of "-") for given DE from collectionKey population json
			keyAttr=$(jq --arg ID "$tgtID" -c '.[] | select (."DataElementId" == $ID) | with_entries(select ((.key | startswith("min") or startswith("max")) or .key == "seq")) | del(..|select(. == "-"))' "${collKeyItemsPerDP}")
			echo "  - keyAttr: $keyAttr"

			Path_to_DE=$(echo "${basePath}" | sed "s/]$/,\"isCollectionOf\",\"consistsOf\",$idx]/")
			# Get the combined new collectionKey item payload with collectionKey attributes
			keyItem=$(echo "$JsonContent_per_DP" | jq --argjson vPath "${Path_to_DE}" --argjson keyAttArg "${keyAttr}" -c 'getpath($vPath) | .+=$keyAttArg | with_entries(select (.key!="_meta" and .key!="oldLabel" and .key!="required"))')
			echo "  - keyItem: $keyItem"
			Array_keyIems+=("$keyItem")

			# Get the combined new DE payload with collectionKey attributes (not include "seq")
			newDEAttr=$(echo "$JsonContent_per_DP" | jq --argjson vPath "${Path_to_DE}" --argjson keyAttArg "${keyAttr}" -c 'getpath($vPath) | .+=$keyAttArg | with_entries(select (.key != "seq"))')

			JsonContent_per_DP=$(echo "$JsonContent_per_DP" | jq --argjson vPath "${Path_to_DE}" --argjson keyAttArg "${newDEAttr}" 'setpath($vPath; $keyAttArg)')
			echo "  - Check modified DE with collectionKey attributes in 'JsonContent_per_DP':"
			echo "$JsonContent_per_DP" | jq --argjson vPath "${Path_to_DE}" 'getpath($vPath)'
		done

		# Generate the combined collectionKey items payload
		keyArrayPayload="["
		for item in ${Array_keyIems[@]}; do
			if [ "$keyArrayPayload" = "[" ]; then
				keyArrayPayload+="${item}"
			else
				keyArrayPayload+=",${item}"
			fi
		done
		keyArrayPayload+="]"

		echo -e "\nFinal combined payload of collectionKey array:"
		Path_to_collKey=$(echo "${basePath}" | sed 's/]$/,"collectionKey"]/')
		JsonContent_per_DP=$(echo "$JsonContent_per_DP" | jq --argjson vPath "${Path_to_collKey}" --argjson keyArrayArg "${keyArrayPayload}" 'setpath($vPath; $keyArrayArg)')

		echo -e "\nCheck modified collectionKey array in 'JsonContent_per_DP':"
		echo "$JsonContent_per_DP" | jq --argjson vPath "${Path_to_collKey}" 'getpath($vPath)'
	done
	echo "* Save 'JsonContent_payload_full_per_DP' to '${Payload_full_per_DP}'. *"
	echo "$JsonContent_per_DP" > "${Payload_full_per_DP}"
done
