#!/bin/bash

function compare_with_TBM_list   #DPset_KEY  #DPset_TBM
{
    DPsetKEY=$1
    DPsetTBM=$2

    DParray=()
    for DPIdKEY in $DPsetKEY; do
        for DPIdTBM in $DPsetTBM; do
            if [ "$DPIdKEY" = "$DPIdTBM" ]; then
                DParray+=("$DPIdTBM")
                break
            fi
        done
    done
    Len=${#DParray[@]}
    if (( Len >= 1 )); then
        echo ${DParray[@]}
    else
        return 1
    fi
}

WORKDIR=$(dirname $(readlink -f "$0"))

. ${WORKDIR}/keyUpdate.cfg

# OUTPUTBASE="${WORKDIR}/output_collectionKey_Mod"
# FILENAMESUFF="_collectionKey_population.json"
# POPULATIONDIR="${WORKDIR}/collectionKey_population"
# TBM_DPCV_list_file="/data/vincent/MR/MigrationTool_MR2.0/mrmt-3.0.1_mVERs_PerCS_AC3QA_OMDv2_sv25/Migration_list_Per_ContentSet/ToBeMigrated_DPCV_list.csv"

if [ ! -f "${TBM_DPCV_list_file}" ]; then
    echo "*** [ERROR} TBM_DPCV_list_file '${TBM_DPCV_list_file}' not found. Abort! ***"
    exit 2
fi

# Generate timestamp for all the DataSets to be modified with collectionKey
TIMESTAMP=$(date +"%Y-%m-%dT%H%M%S")

WORKSPACEDIR="${OUTPUTBASE}/${TIMESTAMP}"

mkdir -p $WORKSPACEDIR

echo "- Output dir: '$WORKSPACEDIR' -"

DSList=$(ls "${POPULATIONDIR}")

DPIdSet_TBM=$(cat "$TBM_DPCV_list_file" | grep -o '^ecp:[^,]*')

for DSname in $DSList; do

    WORKSPACEDIR_DS="${WORKSPACEDIR}/${DSname}"
    LOGFILE="${WORKSPACEDIR}/keyUpdate_${DSname}_${TIMESTAMP}.log"
    mkdir -p "$WORKSPACEDIR_DS"

    echo -e "\n>> Process collectionKey for DataSet: '$DSname'"
    DPLISTFILE="${POPULATIONDIR}/${DSname}/${DSname}_DPs.lst"
    if [ ! -f "$DPLISTFILE" ]; then
        echo "*** [ERROR} DPs list file '${DSname}_DPs.lst' not found. Abort! ***"
        continue
    fi
    DPIdSet_DS=$(cat "$DPLISTFILE")
    DPIdSet=$(compare_with_TBM_list "$DPIdSet_DS" "$DPIdSet_TBM")
    if [ $? -eq 0 ]; then
        DPsn=0
        echo "   DPs to be processed:"
        for DPId in $DPIdSet; do
             (( DPsn++ ))
             printf "   (%02d) %s\n" $DPsn $DPId
        done
        ${WORKDIR}/Update_collectionKey_attributes_EC2_perDS_schemaV2.5.sh "$DSname" "$TIMESTAMP" &> "$LOGFILE"
        if [ $? -ne 0 ]; then
            echo "Failed to update collectionKey for DataSet: $DSname, check '$LOGFILE' for detail."
            exit 1
        else
            echo "  Update result: SUCCEEDED"
            echo "  ----------------------------------------------------------------------------------"
            echo "  - Updated payload files:"
            fileSet=$(tail -n 100 "$LOGFILE" | grep '^[1-9]-[^.]*\.json$')
            for fline in $fileSet; do echo "  $fline" ; done
            echo "  ----------------------------------------------------------------------------------"
            echo "  Log file: '$LOGFILE'"
        fi
    else
        MSG="*** No DPs involved in collectionKey update found in current ToBeMigrated list. Skip ... ***"
        echo "$MSG"
        echo "$MSG" > $LOGFILE

        # Backup TBM_DPCV_list_file & collectionKey population json
        cp "$TBM_DPCV_list_file" "${WORKSPACEDIR}"
        cp "${POPULATIONDIR}/${DSname}/${DSname}${FILENAMESUFF}" "$WORKSPACEDIR_DS"
    fi
    sleep 1
done

