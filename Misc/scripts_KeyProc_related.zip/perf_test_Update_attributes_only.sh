#!/bin/bash

function ret_path_otm_oto_csv   #JSONCONTENT
{
    JSONCONTENT=$1
    keyPaths=$(echo "$JSONCONTENT" | jq -c 'paths | select(.[-1] == "collectionKey")')
    echo "keyBasePath,OTMId,OTOId" > $PATH_OTM_OTO_FILE_PER_DP
    for pathItem in $keyPaths; do
        basePath=$(echo "$pathItem" | sed 's/\,"collectionKey"//')
        OTM_OTO=$(echo "$JSONCONTENT" | jq --argjson bPATH "$basePath" -rj 'getpath($bPATH) | ."_meta"."masterId", ";", ."isCollectionOf"."_meta"."masterId", "\n"')
        echo "${basePath};${OTM_OTO}" >> $PATH_OTM_OTO_FILE_PER_DP
    done
}

function compare_with_TBM_list   #DPset_KEY  #DPset_TBM
{
    DPsetKEY=$1
    DPsetTBM=$2

    DParray=()
    for DPIdKEY in $DPsetKEY; do
        for DPIdTBM in $DPsetTBM; do
            if [ "$DPIdKEY" = "$DPIdTBM" ]; then
                DParray+=("$DPIdTBM")
                break
            fi
        done
    done
    Len=${#DParray[@]}
    if (( Len >= 1 )); then
        echo ${DParray[@]}
    else
        return 1
    fi
}

WORKDIR=$(dirname $(readlink -f "$0"))

FILENAMESUFF="_collectionKey_population.json"

POPULATIONDIR="${WORKDIR}/collectionKey_population"
OUTPUTBASE="${WORKDIR}/output_collectionKey_Mod"

ENVOPT="DEV"

source_dir_payload="/data/vincent/MR/MigrationTool_MR2.0/mrmt-3.1.8_AC3${ENVOPT}_OMDv2_sv27_hasProperties/Full_Export_TBM/singleVersion"
TBM_DPCV_list_file="/data/vincent/MR/MigrationTool_MR2.0/mrmt-3.1.8_AC3${ENVOPT}_OMDv2_sv27_hasProperties/Migration_list_Per_ContentSet/ToBeMigrated_DPCV_list.csv"


if [ ! -f "${TBM_DPCV_list_file}" ]; then
    echo "*** [ERROR} TBM_DPCV_list_file '${TBM_DPCV_list_file}' not found. Abort! ***"
    exit 2
fi

TMPWORKDIR="${WORKDIR}/tmp_workplace"
TIMESTAMP=$(date +"%Y-%m-%dT%H%M%S")

DSname="CIQMInstrument"

OUTPUTTM="${OUTPUTBASE}/${TIMESTAMP}"

mkdir -p "$TMPWORKDIR"
mkdir -p "$OUTPUTTM"

# Copy TBM_DPCV_list_file to workspace for backup
cp "$TBM_DPCV_list_file" "${OUTPUTTM}"

echo -e "\n+++++++++++++++++++ DS: $DSname +++++++++++++++++++"
collKey_population="${DSname}${FILENAMESUFF}"
fullpath_collKey_population="${POPULATIONDIR}/${DSname}/${collKey_population}"
if [ ! -f "$fullpath_collKey_population" ]; then
    echo "*** [ERROR] collectionKey population file '$fullpath_collKey_population' not found! ***"
    exit 2
fi

# Cleanup temporary dir
rm -f ${TMPWORKDIR}/*.*

# Create workspace dir for DS
mkdir -p "${OUTPUTTM}/${DSname}"

# Copy collectionKey population json to DS workspace for backup
cp "$fullpath_collKey_population" "${OUTPUTTM}/${DSname}"

# Retrieve all the unique DPIds (valid only!) from collectionKey population json with the order of original occurrence
DPIdSet=$(jq -r '.[] | select (."DistributionPairId" | startswith("ecp:")) | ."DistributionPairId"' "$fullpath_collKey_population" | awk '!x[$0]++')
#echo " [DBG] DPIdSet_KEY:" && echo "$DPIdSet"

if [ -n "$TBM_DPCV_list_file" ]; then
    DPIdSet_TBM=$(cat "$TBM_DPCV_list_file" | grep -o '^ecp:[^,]*')
    #echo " [DBG] DPIdSet_TBM:" && echo "$DPIdSet_TBM"

    DPIdSet=$(compare_with_TBM_list "$DPIdSet" "$DPIdSet_TBM")
    retCode=$?
    #echo " [DBG] DPIdSet_MOD:"
    # DPsn=0
    # for DPId in $DPIdSet; do
         # (( DPsn++ ))
         # printf "(%02d) %s\n" $DPsn $DPId
    # done
    if [ $retCode -eq 0 ]; then
        output_dir_backup="${OUTPUTTM}/${DSname}/orig_payload"
        output_dir_payload="${OUTPUTTM}/${DSname}/keyAttrs_Mod"

        echo ">> Prepare workspace for '${DSname}' ..."
        mkdir -p ${output_dir_backup} ${output_dir_payload}
    else
        echo "*** No DPs involved in collectionKey update found in current ToBeMigrated list. Skip ... ***"
        exit 0
    fi
fi

DPsn=0
for DPId in $DPIdSet; do
    (( DPsn++ ))
    DPtag="${DPId:38:4}"

    Fn=$(echo "$DPId" | sed 's/ecp://')
    payloadFn="$(ls ${source_dir_payload}/${Fn}_*.json 2> /dev/null)"
    if [ -z "$payloadFn" ]; then
        printf "\n##### %02d. DPId: '%s', Original payload: file not found! #####\n" $DPsn $DPId
        echo "*** [ERROR] Expected original exported payload file for DPId '$DPId' not found. ***"
        exit 3
    else
        #echo -e "\n##### [DBG] DPId: '$DPId', Original payload: '$payloadFn' #####"
        printf "\n##### %02d. DPId: '%s', Original payload: '%s' #####\n" $DPsn $DPId "$payloadFn"
        cp "$payloadFn" "$output_dir_backup"
        baseName=$(basename "$payloadFn")
        # Prepare the full path name of the output payload (modified)
        Payload_full_per_DP="${output_dir_payload}/$baseName"
        JsonContent_per_DP=$(cat "$payloadFn")
    fi

    echo "================= Process additional attributes for DP: \"$DPId\" ================="
    addAttrs_population_per_DP=$(echo "$collKey_population" | sed -e "s,^,${TMPWORKDIR}/addAttrs_per_DP_${DPtag}_,;s,\.json,.txt,")

    # Extract all additional attributes per DPId
    #jq --arg vID "$DPId" -c '.[] | select (."DistributionPairId" == $vID and ."IsCollectionKeySet" != "Y" and ."IsCollectionKeyElement" != "Y") | with_entries(select (.key!="IsCollectionKeySet" and .key!="IsCollectionKeyElement" and .key!="seq"))' "$fullpath_collKey_population" > $addAttrs_population_per_DP
    jq --arg vID "$DPId" -c '.[] | select (."DistributionPairId" == $vID and ."IsCollectionKeySet" != "Y" and ."IsCollectionKeyElement" != "Y") | with_entries(select (.key!="IsCollectionKeySet" and .key!="IsCollectionKeyElement" and .key!="DistributionPairId" and .key!="DataElementParentId" and .key!="DataType" and .key!="seq"))' "$fullpath_collKey_population" > $addAttrs_population_per_DP
    cnt=0
    while read attrJsonString; do
        (( cnt++ ))
        printf "[%02d] attrJsonString: %s\n" $cnt "$attrJsonString"

        # Get DEId
        DEId=$(echo "$attrJsonString" | jq -r '."DataElementId"' | grep -o 'ecp:[^ ]*')
        if [ $? -ne 0 ]; then
            #echo "*** [WARN] Found invalid DataElementId: '$DEId', ignore. ***"
            continue
        fi

        # Get additional attributes (not include "seq" and exclude all the keys with value of "-" or "") for given DE from collectionKey population json
        addAttr=$(echo "$attrJsonString" | jq -c '. | with_entries(select ((.key | startswith("min") or startswith("max")) or .key == "decimalPlaces" or .key == "valueDomainId")) | del(..|select(. == "-" or . == ""))')
        echo "  - addAttr: $addAttr"

        if [ "$addAttr" = "{}" ]; then
            echo "*** [INFO] No valid attributes, skip update. ***"
            continue
        fi

        # Get paths to DEId from payload json
        Paths_to_DEId=$(echo "$JsonContent_per_DP" | jq --arg vID "${DEId}" -c 'paths as $path | select(getpath($path) == $vID) | $path')
        if [ -z "$Paths_to_DEId" ]; then
            echo "*** [WARN] Cannot find the path to DEId '$DEId' in CdfObject payload json. Skip it. ***"
            continue
        fi

        #echo " [DBG] Paths_to_DE: $Paths_to_DEId"
        for DEPath in ${Paths_to_DEId}; do
            Path_to_DE=$(echo "${DEPath}" | sed 's/,"_meta","masterId"//')

            # Get the combined new DE payload with additional attributes
            newDEAttr=$(echo "$JsonContent_per_DP" | jq --argjson vPath "${Path_to_DE}" --argjson addAttrArg "${addAttr}" -c 'getpath($vPath) | .+=$addAttrArg')

            JsonContent_per_DP=$(echo "$JsonContent_per_DP" | jq --argjson vPath "${Path_to_DE}" --argjson addAttrArg "${newDEAttr}" 'setpath($vPath; $addAttrArg)')
            #echo "  - Check modified DE with additional attributes in 'JsonContent_per_DP':"
            #echo "$JsonContent_per_DP" | jq --argjson vPath "${Path_to_DE}" 'getpath($vPath)'
        done
    done < $addAttrs_population_per_DP

    echo ">>> Done. <<<"
done
