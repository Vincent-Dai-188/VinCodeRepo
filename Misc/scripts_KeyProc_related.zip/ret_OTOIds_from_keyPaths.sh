#!/bin/bash

QRY=""
Path_ARRAY=()
while read keyPATH; do
	Path_ARRAY+=($keyPATH)
    OTO_Path=$(echo "$keyPATH" | sed 's/"collectionKey"/"isCollectionOf"."_meta"."businessId"/')
    if [ -z "$QRY" ]; then
        QRY="${OTO_Path}"
    else
        QRY="${QRY}, ${OTO_Path}"
    fi
done < paths_envelope_OA5_aa19.txt

OTOId_ARRAY=()
Ids=$(jq -r "$QRY" payload_envelope_OA5_aa19_Mar_0313.json)

for id in $Ids; do
	OTOId_ARRAY+=($id)
done

echo ">> OTOId_ARRAY:"
for item in "${OTOId_ARRAY[@]}";
do
	echo "  - $item"
done

TargetID="ecp:9-df92b693-4991-4c5b-9ca9-433b82360781"

echo -e "\nTargetID: $TargetID"
idx=0
for item in "${OTOId_ARRAY[@]}";
do
	if [ "$item" = "$TargetID" ]; then
		echo "Index = $idx"
		echo "KeyPath: ${Path_ARRAY[$idx]}"
		break
	else
		(( idx += 1 ))
	fi
done
