#!/bin/bash

# "IsCollectionKey": 'y' - CollectionKeySet; "Is Collection Key": 'y' - CollectionKeyItem
collKey_population="Fundamentals_collectionKey_population.json"

TMPWORKDIR="./tmp_workplace"
#source_dir_payload="./export_RCF/orig"
source_dir_payload="./export_RCF/Long_d1f7"

# Retrieve all the unique DPIds from collectionKey population json
DPIdSet=$(jq -r '.[]."DistributionPairId"' "$collKey_population" | uniq)
#echo " [DBG] DPIdSet:" && echo "$DPIdSet"

echo -e ">> Cleanup ...\n"
rm -f ${TMPWORKDIR}/*.*

ErrCount=0

DPsn=0
for DPId in $DPIdSet; do
    (( DPsn++ ))
	DPtag="${DPId:38:4}"

    Fn=$(echo "$DPId" | sed 's/ecp://')
	payloadFn="$(ls ${source_dir_payload}/${Fn}_*.json 2> /dev/null)"
	if [ -z "$payloadFn" ]; then
		echo "*** Payload file for DPId '$DPId' not found! ****"
		continue
	else
		#echo " [DBG] Payload file for DPId '$DPId': $payloadFn "
		printf "\n##### %02d. DPId: '%s', Original payload: '%s' #####\n" $DPsn $DPId "$payloadFn"
		JsonContent_per_DP=$(cat "$payloadFn")
	fi

	addAttrs_population_per_DP=$(echo "$collKey_population" | sed -e "s,^,${TMPWORKDIR}/addAttrs_per_DP_${DPtag}_,;s,\.json,.txt,")
	# Extract all additional attributes per DPId
	jq --arg vID "$DPId" -c '.[] | select (."DistributionPairId" == $vID and ."IsCollectionKey" != "y") | with_entries(select (.key!="IsCollectionKey" and .key!="seq"))' "$collKey_population" > $addAttrs_population_per_DP

	cnt=0
	while read attrJsonString; do
		(( cnt++ ))
		#printf "[%02d] attrJsonString: %s\n" $cnt "$attrJsonString"

		# Get DEId
		DEId=$(echo "$attrJsonString" | jq -r '."DataElementId"')
		echo "$DEId" | grep "^ecp:" &>/dev/null
		if [ $? -ne 0 ]; then
			#echo "*** Found invalid DataElementId: '$DEId', ignore! ***"
			continue
		fi
		printf "[%02d] DE: %s\n" $cnt "$DEId"

		# Get "DataType" attribute
		dataTypeInAttr=$(echo "$attrJsonString" | jq -r '."DataType"')
		echo "  - DataType(Attrs): $dataTypeInAttr"

		# Get paths to DEId from payload json
		Paths_to_DEId=$(echo "$JsonContent_per_DP" | jq --arg vID "${DEId}" -c 'paths as $path | select(getpath($path) == $vID) | $path')
		
		#echo " [DBG] Paths_to_DE: $Paths_to_DEId"
		for DEPath in ${Paths_to_DEId}; do
			Path_to_DE=$(echo "${DEPath}" | sed 's/"_meta","businessId"/"isOfDataType"/')

			# Get "DataType" attribute from payload json
			dataTypeInPayload=$(echo "$JsonContent_per_DP" | jq --argjson vPath "${Path_to_DE}" -r 'getpath($vPath)')
			echo "  - DataType(Payload): $dataTypeInPayload"
			dataTypeInPayload=$(echo "$dataTypeInPayload" | sed 's,https://graph.link/ecp/schema/CDF/,,')
			if [ "$dataTypeInPayload" = "$dataTypeInAttr" ]; then
				echo "  - Check result: OK"
			else
				(( ErrCount++ ))
				echo "  - Check result: FAILED"
				echo "    > attrJsonString: $attrJsonString <"
			fi
		done
	done < $addAttrs_population_per_DP
done

if (( ErrCount == 0 )); then
	echo -e "\n****** PASS ******"
else
	echo -e "\n*** [ERROR] < ${ErrCount} > DataType Mismatching found! ***"
	exit 2
fi
