#!/bin/bash

function get_DPId_by_CIId   # CIId
{
    CIID=$1
    sed "s/%CIID%/${CIID}/" $TplFile > $SparqlFile

    # Convert sparql in plain text to URL
    QUERYSPL=`./URL_convert_SparQL.sh "$(cat ${SparqlFile})"`

    ret=$(curl -s -X GET ${SPARQL_HOST}/metadata/sparql?query="${QUERYSPL}" -H "Accept: application/sparql-results+json" | jq -r '."results"."bindings"[].dpId.value' | sort -u)
    if [ -n "$ret" ]; then
        echo "$ret" 
    else
        echo "null" 
    fi
}

SPARQL_HOST="http://a204121qanlb-2588124a14c0d9c1.elb.us-east-1.amazonaws.com"
TplFile="sparql_ret_DPCV_by_CI.tpl"
SparqlFile="sparql_ret_DPCV_by_CI.sparql"

# Exclusion list of DPs 
BLACKLIST="ecp:9-3dca77f5-1cf3-4d17-af73-8dcd3036cc0d ecp:9-8da14d0f-6209-4a1d-8e8e-36f7ba23b581 ecp:9-e0f073a9-bcf3-4b98-8da9-92dd7929344c ecp:9-ff015e60-5f5a-4156-9150-2084012c0bcb"

if (( $# < 1 )); then
    echo "Usage: $0 <GX-File>"
    exit 2
fi

ExcelFile=$1
outputFile=$(echo "$ExcelFile" | sed 's/xlsx/json/')

echo ">> Convert '${ExcelFile}' to json file '${outputFile}' ..."
node ./xlsxTojson_params.js ${ExcelFile} ${outputFile} "GX-Fields"

if [ ! -f "${outputFile}" ]; then
    echo "*** Converted '${outputFile}' not found! ***"
    exit 1
fi

echo ">> Get rid of records with abnormal ContentItemId ..."
JSONCONTENT=$(jq -c '[.[] | select (."ContentItemId" | startswith("ecp:"))]' ${outputFile})

echo ">> Get rid of unnecessary fields ..."
JSONCONTENT=$(echo "$JSONCONTENT" | jq -c '[.[] | with_entries(select ((.key | startswith("UX-") or startswith("INT-") or endswith("Label") or endswith("Path") | not) and .key != "DE#" and .key != "CmpPermId" and .key != "Glossary-Title"))]')

echo ">> Change \"y\" column to \"Y\" ..."
JSONCONTENT=$(echo "$JSONCONTENT" | sed 's/"y"/"Y"/g')

echo ">> Change \"ValueDomainId\" column to \"valueDomainId\" ..."
JSONCONTENT=$(echo "$JSONCONTENT" | sed 's/"ValueDomainId"/"valueDomainId"/g')

echo ">> Change \"Order\" column to \"seq\" ..."
JSONCONTENT=$(echo "$JSONCONTENT" | sed 's/"Order"/"seq"/g')

echo ">> Change \"IsCollectionKey\" & \"Is Collection Key\" columns to \"IsCollectionKeySet\" & \"IsCollectionKeyElement\" ..."
JSONCONTENT=$(echo "$JSONCONTENT" | sed -e 's/"IsCollectionKey"/"IsCollectionKeySet"/g;s/"Is Collection Key"/"IsCollectionKeyElement"/g')

echo ">> Convert all the decimal number strings in json file to decimal numeral ..."
JSONCONTENT=$(echo "$JSONCONTENT" | sed -e 's/"minLength":"\([0-9][0-9]*\)"/"minLength":\1/g;s/"minValue":"\([0-9][0-9]*\)"/"minValue":\1/g;s/"maxLength":"\([0-9][0-9]*\)"/"maxLength":\1/g;s/"maxValue":"\([0-9][0-9]*\)"/   "maxValue":\1/g;s/"seq":"\([0-9][0-9]*\)"/"seq":\1/g;s/"decimalPlaces":"\([0-9][0-9]*\)"/"decimalPlaces":\1/g')

echo ">> Append DPId by CIId ..."
# Retrieve all the unique CIs (valid only!) from collectionKey population json with the order of original occurrence
CISet=$(echo "$JSONCONTENT" | jq -r '.[] | select (."ContentItemId" | startswith("ecp:")) | ."ContentItemId"' | awk '!x[$0]++')

CIIdx=0
for CIId in $CISet; do
    (( CIIdx++ ))
    printf "[%02d] CI: %s\n" $CIIdx $CIId
    # Get DPId by CIId
    DPId=$(get_DPId_by_CIId $CIId)
    num=$(echo $DPId | awk '{print NF}')
    if (( num >= 2 )); then
        echo "[WARN] Multiple DPs returned via SparQL: [ "$DPId" ], filtering with exclusion list ..."
        for BLitem in $BLACKLIST; do
            DPId=$(echo "$DPId" | sed "s/${BLitem}//")
        done
        DPId=$(echo "$DPId" | grep -o 'ecp:[^ ]*')
        num=$(echo $DPId | awk '{print NF}')
        if (( num >= 2 )); then
            echo "[ERROR] Multiple DPs remained even after filtering: [ "$DPId" ]"
            exit 2
        fi
    fi
    echo " - DP: $DPId"
    # Replace CI with combination of DP & CI
    JSONCONTENT=$(echo "$JSONCONTENT" | sed "s/\"ContentItemId\":\"${CIId}\"/\"DistributionPairId\":\"${DPId}\",\"ContentItemId\":\"${CIId}\"/g")
done


# Finally, write modified content to json file
echo -e "\n>>> Save finalized JSON CONTENT to '${outputFile}'. <<<"
echo "$JSONCONTENT" | jq '.' > "${outputFile}"

# Validation check on: 1) "IsCollectionKeySet": 'Y' should be set to OneToManyDataElement only, 2) DEParentId (OTMId) belongs to corresponding ContentItemId, 3) DEParentId (OTMId) is the parent of DEId (OTOId)
echo -e "\n========== Validation check on: 1) \"IsCollectionKeySet\":'Y' is set for OneToMany (OTM), 2) OTMId belongs to paired CIId, 3) OTMId is the parent of OTOId =========="
CIandOTMSet=$(echo "$JSONCONTENT" | jq -rj '.[] | select (."IsCollectionKeySet" == "Y") | ."ContentItemId", ",", ."DataElementParentId", ",", ."DataElementId", ",", ."DataType", "\n"')
for itemSet in $CIandOTMSet; do
    CIId=$(echo "$itemSet" | awk -F',' '{print $1}')
    OTMId=$(echo "$itemSet" | awk -F',' '{print $2}')
    OTOId=$(echo "$itemSet" | awk -F',' '{print $3}')
    DType=$(echo "$itemSet" | awk -F',' '{print $4}')

    if [ "${DType}" == "OneToManyDataElement" ]; then
        containerType=$(./check_CI_containerType.sh "$CIId")
        if [ "${containerType}" != "Timeseries" ]; then
            containerType="ERROR <${containerType}>"
        fi
        # For TimeSeries Container case, "DataElementId" here is actually the OTMID
        OTMId=${OTOId}
        # '--' is being interpreted as an option (in this case, to signify that there are no more options).
        printf -- "- CI,OTM,OTO: %s,%s,%-42s  " $CIId $OTMId "--- $containerType ---"
    else
        echo -n "- CI,OTM,OTO: $CIId,$OTMId,$OTOId  "
    fi

    retThing=$(getThing $OTMId)
    if [ $? -eq 0 ]; then
        dataType=$(echo "$retThing" | jq -r '."@graph"[0]."@type"' | sed 's,https://graph.link/ecp/schema/CDF/,,')
        if [ "$dataType" == "OneToManyDataElement" ]; then
            echo -n "PASS  "
        else
            echo -n "ERROR ($dataType)  "
        fi

        ret=$(./ret_CIs_by_DE.sh $OTMId | grep $CIId)
        if [ $? -eq 0 ]; then
            echo -n "PASS  "
        else
            echo -n "ERROR  "
        fi

        if [ "${DType}" == "Map" ] || [ "${DType}" == "map" ] || [ "${DType}" == "MAP" ]; then
            ret=$(./ret_OTMId_by_OTOId.sh $OTOId | grep $OTMId)
            if [ $? -eq 0 ]; then
                echo "PASS"
            else
                echo "ERROR"
            fi
        elif [ "${containerType}" == "Timeseries" ] && [ "${DType}" == "OneToManyDataElement" ]; then
            echo "PASS (OTM)"
        else
            echo "ERROR (${DType})"
        fi
    else
        echo "ERROR ($retThing)"
    fi
done

# Validation check on situation of 'Y' for both "IsCollectionKeySet" & "IsCollectionKeyElement" columns
echo -e "\n======= Validation check on 'Y' for both \"IsCollectionKeySet\" & \"IsCollectionKeyElement\" ======="
ErrKeyElementSet=$(echo "$JSONCONTENT" | jq -rj '.[] | select ((."IsCollectionKeySet" == "Y") and (."IsCollectionKeyElement" == "Y")) | ."DataElementParentId", ",", ."DataElementId","\n"')
if [ -z "$ErrKeyElementSet" ]; then
    echo "PASS"
else
    echo "ERRORs detected for DEs below with 'Y' for both \"IsCollectionKeySet\" & \"IsCollectionKeyElement\":"
    echo "DEParentId,DEId"
    for errItem in $ErrKeyElementSet; do
        echo $errItem
    done
fi

# Validation check on combination of "IsCollectionKeySet" and "IsCollectionKeyElement"
echo -e "\n===== Validation check on combination of \"IsCollectionKeySet\" and \"IsCollectionKeyElement\" ====="

CIIdx=0
for CIId in $CISet; do
    (( CIIdx++ ))
    printf "[%02d] CI: %s " $CIIdx $CIId

    CICONTENT=$(echo "$JSONCONTENT" | jq --arg vCIId "$CIId" '[.[] | select (."ContentItemId" == $vCIId)]')

    # Retrieve number of unique OTMs for IsCollectionKeySet
    KeySetOTMNum=$(echo "$CICONTENT" | jq -r '.[] | select (."IsCollectionKeySet" == "Y") | ."DataElementParentId"' | awk '!x[$0]++' | wc -l)
    if (( KeySetOTMNum > 0 )); then
        echo -n "( KeySets: $KeySetOTMNum    "
    else
        echo -n "( KeySets: null "
    fi
    # Retrieve number of unique OTOs for IsCollectionKeyElement
    KeyEleOTONum=$(echo "$CICONTENT" | jq -r '.[] | select (."IsCollectionKeyElement" == "Y") | ."DataElementParentId"' | awk '!x[$0]++' | wc -l)
    if (( KeyEleOTONum > 0 )); then
        echo -n " KeyElements: $KeyEleOTONum    )"
    else
        echo -n " KeyElements: null )"
        KElementVal=1
    fi
    if (( KeySetOTMNum == KeyEleOTONum )); then
        echo "  PASS"
    else
        echo "  ERROR"
    fi
done

# Validation check on "Order" ("seq") in collectionKey array
echo -e "\n================= Validation check on \"Order\" in each collectionKeySet (array) ================="

CIIdx=0
# Retrieve all the unique DataElementParentId (OTOIds, valid only) under each CI from collectionKey population json with the order of original occurrence
for CIId in $CISet; do
    OTOIdSet=$(echo "$JSONCONTENT" | jq --arg vCIId "$CIId" -r '.[] | select ((."DataElementParentId" | startswith("ecp:")) and (."ContentItemId" == $vCIId) and (."IsCollectionKeyElement" == "Y")) | ."DataElementParentId"' | awk '!x[$0]++')
    (( CIIdx++ ))
    printf "[%02d] CI: %s\n" $CIIdx $CIId
    for OTOId in $OTOIdSet; do
        echo -n " - OTOId: $OTOId  "
        seqSet=$(echo "$JSONCONTENT" | jq --arg vCIId "$CIId" --arg vOTOID "$OTOId" -r '[sort_by(."seq") | .[] | select ((."DataElementParentId" == $vOTOID) and (."ContentItemId" == $vCIId) and (."IsCollectionKeyElement" == "Y")) | .]')
        seqNum=$(echo "$seqSet" | jq '. | length')
        (( seqNum-- ))
        seqSet=$(echo "$seqSet" | jq -r '.[] | ."seq"')
        seqSetStr=$(echo "Act:["${seqSet}"]")
        printf "%-18s" "$seqSetStr"
        exp_seqSet=$(seq 0 $seqNum)
        exp_seqSetStr=$(echo "Exp:["${exp_seqSet}"]")
        printf "%-18s" "$exp_seqSetStr"
        if [ "$seqSet" = "$exp_seqSet" ]; then
            echo "PASS"
        else
            echo "ERROR"
        fi
    done
done

# Validation check on "minLength" & "maxLength" with value of 0
echo -e "\n============== Validation check on \"minLength\" and \"maxLength\" with value of 0 =============="

miniZeroSet=$(echo "$JSONCONTENT" | jq -rj '.[] | select( (."minLength" == 0) or (."maxLength" == 0)) | ."DataElementId", ",", ."minLength", ",", ."maxLength","\n"')
if [ -z "$miniZeroSet" ]; then
    echo "PASS"
else
    echo "ERRORs detected for DEs below with \"minLength\" or \"maxLength\" of 0:"
    echo "DataElementId,minLength,maxLength"
    for miniZeroLine in $miniZeroSet; do
        echo $miniZeroLine
    done
fi

# Validation check on DataElementIds with both valid additional attributes and non-SimpleDatatype
echo -e "\n============== Validation check on DEs with both valid additional attributes and non-SimpleDatatype =============="

nonSimpleDESet=$(echo "$JSONCONTENT" | jq -c '.[] | select (."IsCollectionKeySet" != "Y" and ."IsCollectionKeyElement" != "Y") | del(..|select(. == "-" or . == "")) | with_entries(select ((.key | endswith("Length") or endswith("Value")) or .key=="DataElementId" or .key=="DataType" or .key=="decimalPlaces" or .key=="valueDomainId")) | select((.|length) >= 3) | .' | grep -v 'SimpleDatatype-')
if [ -z "$nonSimpleDESet" ]; then
    echo "PASS"
else
    echo "ERRORs detected for DEs below with both additional attributes and non-SimpleDatatype:"
    echo "DataElementId,DataType"
    for errLine in $nonSimpleDESet; do
        echo "$errLine" | jq -rj '.DataElementId, ",", ."DataType", "\n"'
    done
fi

DPsListFile=$(echo "$ExcelFile" | sed 's/\.xlsx/_DPs.lst/')
echo -e "\n>>> Generate DistributionPair IDs list file '${DPsListFile}' ..."
echo "$JSONCONTENT" | jq -r '.[] | select (."DistributionPairId" | startswith("ecp:")) | ."DistributionPairId"' | awk '!x[$0]++' > "${DPsListFile}"
echo "Done."
