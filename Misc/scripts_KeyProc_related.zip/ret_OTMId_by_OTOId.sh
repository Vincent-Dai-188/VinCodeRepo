#!/bin/bash

function ret_OTMId_by_OTOId   # DE_Id
{
    DE_Id=$1
    sed "s/%DE_ID%/${DE_Id}/" $TplFile > $SparqlFile

    # Convert sparql in plain text to URL
    QUERYSPL=`./URL_convert_SparQL.sh "$(cat ${SparqlFile})"`

    ret=$(curl -s -X GET ${SPARQL_HOST}/metadata/sparql?query="${QUERYSPL}" -H "Accept: application/sparql-results+json" | jq -r '."results"."bindings"[]."sub"."value"')
    if [ -n "$ret" ]; then
        echo "$ret"
    else
        echo "null"
    fi
}

SPARQL_HOST="http://a204121qanlb-2588124a14c0d9c1.elb.us-east-1.amazonaws.com"
TplFile="query_parentIds_by_DEId.tpl"
SparqlFile="query_OTMId_by_OTOId.sparql"

ret_OTMId_by_OTOId $1
