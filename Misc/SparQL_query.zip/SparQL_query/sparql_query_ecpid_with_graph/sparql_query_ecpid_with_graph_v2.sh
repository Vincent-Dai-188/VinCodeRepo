#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <ecp-id> [-J] [-S] [-i] [-h] [-E <DEV|QA|Prod|Sandbox>]"
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

JPARSE="true"
showEnv=""
SKIPTOKEN=""

if (( $# >= 1 )); then
    ECPID=$1
    shift
else
    display_help
    exit 1
fi

while getopts :hiJSE: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            elif [ "${ENV}" = "DEV" ]; then
                . $WORKDIR/ENV_config/DEV.cfg
            elif [ "${ENV}" = "Prod" ]; then
                . $WORKDIR/ENV_config/Prod.cfg
            else  # Sandbox
                . $WORKDIR/ENV_config/Sandbox.cfg
            fi
            ;;
        J)  JPARSE="true"
            ;;
        S)  SKIPTOKEN="true"    # Retrieve token from TOKEN_FILE without checking expiration period
            ;;
        i)  showEnv="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
    else
        # QA Env (default)
        . $WORKDIR/ENV_config/QA.cfg
    fi
fi

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***" 1>&2
fi

# === Query NamedGraph info ===
TemplateFile_NG="${WORKDIR}/query_graph_def.tpl"
SparqlFile_NG="${WORKDIR}/query_graph_def.sparql"

# Assemble target ecp-id into SparQL string 
sed "s/%ECP_ID%/${ECPID}/" ${TemplateFile_NG} > ${SparqlFile_NG}

# Convert sparql in plain text to URL
QUERYSPL=`${WORKDIR}/URL_convert_SparQL.sh "$(cat ${SparqlFile_NG})"`

ret=`curl -s -X GET ${SPARQL_HOST}/metadata/sparql?query="${QUERYSPL}" \
-H "Accept: application/sparql-results+json" \
-H "x-api-key: ${APIKey}" \
-H "Authorization: ${token}"`
#echo -e "\n----- NameGraph -----"
#echo $ret | jq -rj '.results.bindings[] | "<", .graph.value // "--", "> <", .pre.value // "--", "> <", .obj.value // "--", ">\n"'
#echo $ret | jq -rj '.results.bindings[] | (if .graph.type=="uri" then "<", .graph.value, "> " else "\"", .graph.value, "\" " end), (if .pre.type=="uri" then "<", .pre.value, "> " else "\"", .pre.value, "\" " end), (if .obj.type=="uri" then "<", .obj.value, "> ." else "\"", .obj.value, "\" ." end), "\n"'
echo "$ret" | jq -rj '.results.bindings[] | (if .graph.type=="uri" then "<", .graph.value, "> " else "\"", .graph.value, "\" " end), (if .pre.type=="uri" then "<", .pre.value, "> " else "\"", .pre.value, "\" " end), (if .obj.type=="uri" then "<", .obj.value, "> ." else (if .obj.datatype? then "\"", .obj.value, "\"^^<", .obj.datatype, "> ." else "\"", .obj.value, "\" ." end) end), "\n"' > /tmp/sparql_ecpid/${ENV}/${ECPID}

# === Query Thing info ===
TemplateFile_Thing="${WORKDIR}/query_ecpid.tpl"
SparqlFile_Thing="${WORKDIR}/query_ecpid.sparql"

# Assemble target ecp-id into SparQL string 
sed "s/%ECP_ID%/${ECPID}/" ${TemplateFile_Thing} > ${SparqlFile_Thing}

ret=`curl -s -X POST ${SPARQL_HOST}/metadata/sparql \
-H "Content-Type: application/sparql-query" \
-H "Accept: application/sparql-results+json" \
-H "x-api-key: ${APIKey}" \
-H "Authorization: ${token}" \
-d @${SparqlFile_Thing}`

#echo -e "\n----- Thing -----"
#echo $ret | jq -rj '.results.bindings[] | "<", .predicate.value, "> : \"", .object.value, "\"\n"'
#echo $ret | jq -rj ".results.bindings[] | \"<${ECPID}> <\", .predicate.value, \"> : \\\"\", .object.value, \"\\\"\n\""
#echo $ret | jq -rj ".results.bindings[] | \"<${ECPID}> \", (if .predicate.type==\"uri\" then \"<\", .predicate.value, \"> \" else \"\\\"\", .predicate.value, \"\\\" \" end), (if .object.type==\"uri\" then \"<\", .object.value, \"> .\" else \"\\\"\", .object.value, \"\\\" .\" end), \"\n\""
echo "$ret" | jq -rj ".results.bindings[] | \"<${ECPID}> \", (if .predicate.type==\"uri\" then \"<\", .predicate.value, \"> \" else \"\\\"\", .predicate.value, \"\\\" \" end), (if .object.type==\"uri\" then \"<\", .object.value, \"> \" else (if .object.datatype? then \"\\\"\", .object.value, \"\\\"^^<\", .object.datatype, \"> \" else \"\\\"\", .object.value, \"\\\" \" end) end), (if .graph.type==\"uri\" then \"<\", .graph.value, \"> .\" else \"\\\"\", .graph.value, \"\\\" .\" end),
\"\n\"" >> /tmp/sparql_ecpid/${ENV}/${ECPID}

cat /tmp/sparql_ecpid/${ENV}/${ECPID}
