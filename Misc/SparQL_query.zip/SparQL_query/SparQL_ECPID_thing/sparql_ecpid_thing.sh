#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <ecp-id> [-i] [-S] [-h] [-J] [-E <DEV|QA|Sandbox>]"
}

function refetch_token
{
    # Outputs to stderr to avoid potential parse error when using jq
    echo "Re-Fetch Token ..." 1>&2
    # -H 'Content-Length: 0' (To avoid: Content-Length missing for POST or PUT requests)
    token=$(curl -s -X POST \
        -H "Key: ${uKey}" \
        -H "SecretKey: ${SecretKey}" \
        -H "x-api-key: ${APIKey}" \
        -H "Content-Length: 0" \
        ${HOST}/auth)

    if [ -z "$token" ]; then
        echo "*** Failed to obtain token! ***"
        exit 1
    fi
    #echo -e "\nNew token:\n${token}\n"
    date +%s > $TOKENFILE
    echo $token >> $TOKENFILE
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

#JPARSE="true"
JPARSE=""
showEnv=""
SKIPTOKEN=""


if (( $# >= 1 )); then
    ECPID=$1
    shift
else
    display_help
    exit 1
fi

while getopts :hiJSE: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            elif [ "${ENV}" = "Sandbox" ]; then
                . $WORKDIR/ENV_config/Sandbox.cfg
            else  # DEV
                . $WORKDIR/ENV_config/DEV.cfg
            fi
            ;;
        J)  JPARSE="true"
            ;;
        S)  SKIPTOKEN="true"    # Retrieve token from TOKEN_FILE without checking expiration period
            ;;
        i)  showEnv="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
    else
        # DEV Env (default)
        . $WORKDIR/ENV_config/DEV.cfg
    fi
fi

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***" 1>&2
fi

TOKENFILE="/tmp/.token_MR_${ENV}.aut"

if [ -f $TOKENFILE ]; then
    if [ -n "${SKIPTOKEN}" ]; then
        token=$(tail -n 1 $TOKENFILE)
    else
        tokenbuf="$(cat ${TOKENFILE})"
        tmstamp=$(echo "$tokenbuf" | head -n 1)
        curstamp=$(date +%s)
        if (( curstamp - tmstamp > 1800 )); then
            refetch_token
        else
            token=$(echo "$tokenbuf" | tail -n 1)
        fi
    fi
else
    refetch_token
fi

TemplateFile="${WORKDIR}/query_ecpid.tpl"
SparqlFile="${WORKDIR}/query_ecpid.sparql"

# Assemble target ecp-id into SparQL string
sed "s/%ECP_ID%/${ECPID}/" ${TemplateFile} > ${SparqlFile}

ret=`curl -s -X POST ${SPARQL_HOST}/metadata/sparql \
-H "Content-Type: application/sparql-query" \
-H "Accept: application/sparql-results+json" \
-H "x-api-key: ${APIKey}" \
-H "Authorization: ${token}" \
-d @${SparqlFile}`

if [ -n "$JPARSE" ]; then
    echo "$ret" | jq -rj '.results.bindings[] | "\"", .predicate.value, "\" : \"", .object.value, "\" <", .graph.value, "> .\n"'
else
    echo "$ret" | jq .
fi

# -d 'PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
# PREFIX xsd: <http://www.w3.org/2001/XMLSchema#>
# PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
# PREFIX ecp: <http://registry.ecp.ontology.thomsonreuters.com/>
# PREFIX cmp: <http://registry.ecp.ontology.thomsonreuters.com/CMP/>
# select ?p ?o
#    where {GRAPH ?graph
#        { <ecp:1-0f2b070a-2f31-4984-9b4f-0a844788bd89> ?p ?o . } }'
