#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <source_SparQL_string>"
}

function rawurlencode
{
  OrigStr="$1"
  strLen=${#OrigStr}
  encodedStr=""

  for (( pos=0; pos<strLen; pos++ )); do
     char=${OrigStr:$pos:1}
     case "$char" in
        [-_.~a-zA-Z0-9]) out="${char}" ;;
       *)               printf -v out '%%%02X' "'${char}"
     esac
     encodedStr+="${out}"
  done
  echo "${encodedStr}"    # You can either set a return variable (FASTER)
  REPLY="${encodedStr}"
}

# Returns a string in which the sequences with percent (%) signs followed by
# two hex digits have been replaced with literal characters.
function rawurldecode
{

  # This is perhaps a risky gambit, but since all escape characters must be
  # encoded, we can replace %NN with \xNN and pass the lot to printf -b, which
  # will decode hex for us

  printf -v decodedStr '%b' "${1//%/\\x}" # You can either set a return variable (FASTER)

  echo "${decodedStr}"  #+or echo the result (EASIER)... or both... :p
}

#REPLY=""

#SparqlStr="PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> PREFIX ecpcdf: <https://graph.link/ecp/schema/CDF/> SELECT DISTINCT ?map WHERE { ?map rdf:type ecpcdf:DistributionPairVersionContentItemMap . ?map ecpcdf:hasDistributionPair <ecp:9-ea4f9a1c-7273-4297-9a23-8c05560c5cfd> . }"

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 1 )); then
    display_help
    exit 1
fi

#rawurlencode "$SparqlStr"
#rawurldecode "$REPLY"
rawurlencode "$1"
