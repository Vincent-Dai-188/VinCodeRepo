#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <SparQL_file> [-J] [-i] [-h] [-E <DEV|QA|Prod|Sandbox>]"
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

JPARSE="true"
showEnv=""

if (( $# >= 1 )); then
    SparqlFile=$1
    if [ ! -f $SparqlFile ]; then
        echo "Specified SparQL file '$SparqlFile' not found!" 1>&2
        exit 2
    fi
    shift
else
    display_help
    exit 1
fi

while getopts :hiJE: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            elif [ "${ENV}" = "DEV" ]; then
                . $WORKDIR/ENV_config/DEV.cfg
            elif [ "${ENV}" = "Prod" ]; then
                . $WORKDIR/ENV_config/Prod.cfg
            else  # Sandbox
                . $WORKDIR/ENV_config/Sandbox.cfg
            fi
            ;;
        J)  JPARSE="true"
            ;;
        i)  showEnv="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
    else
        # QA Env (default)
        . $WORKDIR/ENV_config/QA.cfg
    fi
fi

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***" 1>&2
fi

# Convert sparql in plain text to URL
QUERYSPL=`${WORKDIR}/URL_convert_SparQL.sh "$(cat ${SparqlFile})"`

ret=$(curl -s -X GET ${SPARQL_HOST}/metadata/sparql?query="${QUERYSPL}" -H "Accept: application/sparql-results+json")

if [ -n "$ret" ]; then
    echo "$ret" | jq '.results.bindings'
fi
