#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <graph-id> [-J] [-i] [-h] [-E <DEV|QA|Sandbox>]"
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

JPARSE="true"
showEnv=""

if (( $# >= 1 )); then
    GRAPH_ID=$1
    shift
else
    display_help
    exit 1
fi

while getopts :hiJE: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            elif [ "${ENV}" = "Sandbox" ]; then
                . $WORKDIR/ENV_config/Sandbox.cfg
            else  # DEV
                . $WORKDIR/ENV_config/DEV.cfg
            fi
            ;;
        J)  JPARSE="true"
            ;;
        i)  showEnv="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
    else
        # DEV Env (default)
        . $WORKDIR/ENV_config/DEV.cfg
    fi
fi

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***" 1>&2
fi

TemplateFile_ThingIDs="${WORKDIR}/sparql_thingIDs_by_graphID.tpl"
SparqlFile_ThingIDs="${WORKDIR}/sparql_thingIDs_by_graphID.sparql"

# Assemble target ecp-id into SparQL string
sed "s/%GRAPHID%/${GRAPH_ID}/" ${TemplateFile_ThingIDs} > ${SparqlFile_ThingIDs}

ret=`curl -s -X POST ${SPARQL_HOST}/metadata/sparql \
-H "Content-Type: application/sparql-query" \
-H "Accept: application/sparql-results+json" \
-H "x-api-key: ${APIKey}" \
-H "Authorization: ${token}" \
-d @${SparqlFile_ThingIDs}`

# Get sub.type == "uri" (other type: bnode) && ECPIDs only
uri_set=$(echo "$ret" | jq -r '."results"."bindings"[].sub | select(.type=="uri") | .value' 2>/dev/null | grep "^ecp:")

if [ $? -eq 0 ]; then
    num=$(echo "$uri_set" | wc -l)
    echo "$num"
else
    echo "Failed to get response from Neptune"
    exit 1
fi
