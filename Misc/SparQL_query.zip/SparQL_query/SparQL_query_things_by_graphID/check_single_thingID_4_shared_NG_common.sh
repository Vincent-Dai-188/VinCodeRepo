#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <graph-id> [-i] [-h] [-E <DEV|QA|Sandbox>]"
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 1 )) ; then
    echo " A thing ECPID must be supplied!"
    exit 2
fi

id=$1
shift

while getopts :hiE: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            ;;
        i)  showEnv="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        ENV=${ENV_GLOBAL}
    else
        ENV="QA"    # default
    fi
fi

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***" 1>&2
fi

LOCALSTOREDIR="/tmp/things_redis/${ENV}"

printf "ThingID: %s\n" $id
if [ -f "${LOCALSTOREDIR}/${id}" ]; then
    retThing=$(cat "${LOCALSTOREDIR}/${id}")
else
    echo "  >> getThing ..."
    retThing=$(getThing $id -E ${ENV})
fi
if [ $? -eq 0 ]; then
    #echo "$retThing" | jq -c -j '."@graph"[]."@type", " \"", ."@graph"[]."http://www.w3.org/2000/01/rdf-schema#label" // "", "\" <", ."@id", ">\n"'
    GraphID=$(echo $retThing | jq -r '."@id"')
    if [ "$GraphID" != "null" ]; then   # single graph
        echo -n "  - $GraphID  "
        sparql_ret_num_thingIDs_by_graphID $GraphID -E ${ENV}
    else
        GraphID=$(echo $retThing | jq -r '."@graph"[] | ."@id"')    # multiple graphs
        if [ "$GraphID" != "null" ]; then
            for ngId in $GraphID; do
                echo -n "  - $ngId  "
                sparql_ret_num_thingIDs_by_graphID $ngId -E ${ENV}
            done
        else
            echo -n "<null>"
        fi
    fi
else
    exit 1
fi
