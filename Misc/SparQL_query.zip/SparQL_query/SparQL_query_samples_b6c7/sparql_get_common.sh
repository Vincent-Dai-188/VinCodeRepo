#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME [-i] [-E <DEV|QA|Sandbox>] [-h]"
}

function refetch_token
{
    # Outputs to stderr to avoid potential parse error when using jq
    echo "Re-Fetch Token ..." 1>&2
    # -H 'Content-Length: 0' (To avoid: Content-Length missing for POST or PUT requests)
    token=$(curl -s -X POST \
        -H "Key: ${uKey}" \
        -H "SecretKey: ${SecretKey}" \
        -H "x-api-key: ${APIKey}" \
        -H "Content-Length: 0" \
        ${HOST}/auth)

    if [ -z "$token" ]; then
        echo "*** Failed to obtain token! ***"
        exit 1
    fi
    #echo -e "\nNew token:\n${token}\n"
    date +%s > $TOKENFILE
    echo $token >> $TOKENFILE
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))
JPARSE="true"
showEnv=""

# DEV Env (default)
ENV="DEV"
HOST="https://registry-ecp-devs.a-corporate-preprod.aws-int.thomsonreuters.com"
SPARQL_HOST="http://a204121devsnapshotlb-1014498750.us-east-1.elb.amazonaws.com"
uKey="u6025979"
SecretKey="Rjr>NJgR9\BD.V-T"
APIKey="pVw5gWw9d48wKssfe7PV41O61b7SsHDk9AjYQqFA"

while getopts :hiJE: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                HOST="https://ecp-registry-qa-int.thomsonreuters.com"
                SPARQL_HOST="http://a204121qalb-1726422575.us-east-1.elb.amazonaws.com"
                uKey="u6064334"
                SecretKey="M\$FFXR_tH8b?Y~9!"
                APIKey="pVw5gWw9d48wKssfe7PV41O61b7SsHDk9AjYQqFA"
            elif [ "${ENV}" = "Sandbox" ]; then
                HOST="http://a204618junjielb-324114725.us-east-1.elb.amazonaws.com"
                SPARQL_HOST=$HOST
                uKey="u6025971"
                SecretKey="Rjr>NJgR9\BD.V-T"
                APIKey="gDtAPG68Im8ObNx6G0ZyG4PbYSyzfpjt3qT8VN20"
            else    # DEV
                HOST="https://registry-ecp-devs.a-corporate-preprod.aws-int.thomsonreuters.com"
                SPARQL_HOST="http://a204121devsnapshotlb-1014498750.us-east-1.elb.amazonaws.com"
                uKey="u6025979"
                SecretKey="Rjr>NJgR9\BD.V-T"
                APIKey="pVw5gWw9d48wKssfe7PV41O61b7SsHDk9AjYQqFA"
            fi
            ;;
        J)  JPARSE="true"
            ;;
        i)  showEnv="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***"
fi

TOKENFILE="/tmp/.token_MR_${ENV}.aut"

if [ -f $TOKENFILE ]; then
    tmstamp=$(head -n 1 $TOKENFILE)
    curstamp=$(date +%s)
    if (( curstamp - tmstamp > 900 )); then
        refetch_token
    else
        token=$(tail -n 1 $TOKENFILE)
    fi
else
    refetch_token
fi

SparqlFile="${WORKDIR}/query_def.sparql"

# Convert sparql in plain text to URL
QUERYSPL=`${WORKDIR}/URL_convert_SparQL.sh "$(cat ${SparqlFile})"`

ret=`curl -s -X GET ${HOST}/metadata/sparql?query="${QUERYSPL}" \
-H "Accept: application/sparql-results+json" \
-H "x-api-key: ${APIKey}" \
-H "Authorization: ${token}"`

if [ -n "$JPARSE" ]; then
    echo $ret | jq -rj '.results.bindings[] | "<", .subject.value, ">  <", .predicate.value, ">  <", .object.value, ">  <", .graph.value, ">\n"'
else
    echo $ret | jq .
fi