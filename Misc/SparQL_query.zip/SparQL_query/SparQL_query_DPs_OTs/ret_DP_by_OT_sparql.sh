#!/bin/bash

ID=$1

sed "s/%OT_ID%/${ID}/" query_DP_by_OT.tpl > query_DP_by_OT.sparql
./sparql_query_common query_DP_by_OT.sparql