#!/bin/bash

# Usage sample: ./ret_DPs_OTs_by_sparql.sh Sparql_DPs_OTs.sparql

# Run SparQL query and get result
ret=$(sparql_query_common "$1")

# Output length of list (number of DP-OT pairs)
len=$(echo "$ret" | jq '. | length')
echo "Length = $len"

# Output each DP-OT with ECPIDs
echo "$ret" | jq -r -j '.[] | "DP: ",.DP.value, "  OT: ",.OT.value, "\n"'