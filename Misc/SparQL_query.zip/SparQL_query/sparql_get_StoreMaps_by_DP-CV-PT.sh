#!/bin/bash

#
# Query the DistributionPairPartitionVersionStoreMap which has "hasDistributionPair" property of specified DistributionPairID
# and "hasVersion" property of specified CDFVersionID, and in addition, has "hasPartition" property of specified PartitionID
#

. /data/vincent/slibs/fetch_token_MR.slib

function display_help
{
    echo "Usage: $UTILNAME <DistributionPairID> <CDFVersionID> <PartitionID> [-h|-E <DEV|QA|Prod|Sandbox>]"
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 2 )); then
    display_help
    exit 1
fi

ECPID_DP=$1
ECPID_V=$2
ECPID_PT=$3
shift 3

while getopts :hiJSE: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            elif [ "${ENV}" = "DEV" ]; then
                . $WORKDIR/ENV_config/DEV.cfg
            elif [ "${ENV}" = "Prod" ]; then
                . $WORKDIR/ENV_config/Prod.cfg
            else  # Sandbox
                . $WORKDIR/ENV_config/Sandbox.cfg
            fi
            ;;
        J)  JPARSE="true"
            ;;
        S)  SKIPTOKEN="true"    # Retrieve token from TOKEN_FILE without checking expiration period
            ;;
        i)  showEnv="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
    else
        # QA Env (default)
        . $WORKDIR/ENV_config/QA.cfg
    fi
fi

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***" 1>&2
fi

TOKENFILE="/tmp/.token_MR_${ENV}.aut"

get_token_MR

TemplateFile="${WORKDIR}/query_StoreMaps_PT.tpl"
SparqlFile="${WORKDIR}/query_StoreMaps_PT.sparql"

# Assemble target ecp-id into SparQL string
sed "s/%ECPID_DP%/${ECPID_DP}/" ${TemplateFile} > ${SparqlFile}
sed -i -e "s/%ECPID_V%/${ECPID_V}/;s/%ECPID_PT%/${ECPID_PT}/" ${SparqlFile}

${WORKDIR}/sparql_query_common ${SparqlFile}
