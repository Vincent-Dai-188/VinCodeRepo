#!/bin/bash

function display_help
{
    echo "Usage: $0 <DP_Id> <CV_Id>"
}

if (( $# < 2 )); then
    display_help
    exit 1
fi

DP=$1
CV=$2

printf "{ DP: %s CV: %s }\n" ${DP} ${CV}
StoreMap=$(./sparql_get_StoreMaps_by_DP-CV.sh ${DP} ${CV} | jq -r ".results.bindings[].map.value")
if [ -z "${StoreMap}" ]; then
    echo "*** No StoreMap found! ***"
    exit 2
fi

for item in $StoreMap; do
    echo "- StoreMap: $item"
    ret=$(./getThing $item)
    if [ $? -eq 0 ] ; then
        echo -n "  - Store: "
        ST=$(echo "$ret" | jq -r '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasStore"."@id"')
        echo "$ST"
        echo -n "  - Partition: "
        PT=$(echo "$ret" | jq -r '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasPartition"."@id"')
        echo "$PT"
        thing_PT=$(./getThing $PT)
        if [ $? -eq 0 ] ; then
            echo "$thing_PT" | jq -rj '."@graph"[0] | "    >> label: ", ."http://www.w3.org/2000/01/rdf-schema#label", "  description: ", ."http://purl.org/dc/elements/1.1/description", "\n"'
        fi
    else
       echo "  - Store/Partition: None"
    fi
done
