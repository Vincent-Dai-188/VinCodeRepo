#!/bin/bash

#
# Query the DistributionPairPartitionVersionStoreMap which has "hasDistributionPair" property of specified DistributionPairID
# and "hasVersion" property of specified CDFVersionID
#

. /data/vincent/slibs/fetch_token_MR.slib

function display_help
{
    echo "Usage: $UTILNAME <DistributionPairID> <CDFVersionID> [-i] [-E <DEV|QA|Sandbox>] [-h]"
    #echo "       TYPE: VersionView|VersionContentItem|PartitionVersionStore|InstanceAgentRole"
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 2 )); then
    display_help
    exit 1
fi

ECPID_DP=$1
ECPID_V=$2
shift 3

showEnv=""
while getopts :ihE: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            elif [ "${ENV}" = "Sandbox" ]; then
                . $WORKDIR/ENV_config/Sandbox.cfg
            else  # DEV
                . $WORKDIR/ENV_config/DEV.cfg
            fi
            ;;
        i)  showEnv="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
    else
        # QA Env (default)
        . $WORKDIR/ENV_config/QA.cfg
    fi
fi

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***" 1>&2
fi

TOKENFILE="/tmp/.token_MR_${ENV}.aut"

get_token_MR

TemplateFile="${WORKDIR}/query_StoreMaps.tpl"
SparqlFile="${WORKDIR}/query_StoreMaps.sparql"

# Assemble target ecp-id into SparQL string
sed -e "s/%ECPID_DP%/${ECPID_DP}/;s/%ECPID_V%/${ECPID_V}/" ${TemplateFile} > ${SparqlFile}

${WORKDIR}/sparql_query_common ${SparqlFile}
