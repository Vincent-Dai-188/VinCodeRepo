#!/bin/bash

#
# Query all the DistributionPairVersionContentItemMap(s) which has "hasDistributionPair" property of specified DistributionPairID
#

function display_help
{
    echo "Usage: $UTILNAME <DistributionPairID> [-h|-E <DEV|Sandbox>]"
}

function refetch_token
{
    # Outputs to stderr to avoid potential parse error when using jq
    echo "Re-Fetch Token ..." 1>&2
    # -H 'Content-Length: 0' (To avoid: Content-Length missing for POST or PUT requests)
    token=$(curl -s -X POST \
        -H "Key: ${uKey}" \
        -H "SecretKey: ${SecretKey}" \
        -H "x-api-key: ${APIKey}" \
        -H "Content-Length: 0" \
        ${HOST}/auth)

    if [ -z "$token" ]; then
        echo "*** Failed to obtain token! ***"
        exit 1
    fi
    #echo -e "\nNew token:\n${token}\n"
    date +%s > $TOKENFILE
    echo $token >> $TOKENFILE
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 1 )); then
    display_help
    exit 1
fi

ECPID_V=$1
shift


while getopts :hE: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "DEV" ]; then
                HOST="https://registry-ecp-devs.a-corporate-preprod.aws-int.thomsonreuters.com"
                SPARQL_HOST="http://a204121devsnapshotlb-1014498750.us-east-1.elb.amazonaws.com"
                uKey="u6025979"
                SecretKey="Rjr>NJgR9\BD.V-T"
                APIKey="pVw5gWw9d48wKssfe7PV41O61b7SsHDk9AjYQqFA"
            elif [ "${ENV}" = "Sandbox" ]; then
                HOST="http://a204618junjielb-324114725.us-east-1.elb.amazonaws.com"
                SPARQL_HOST=$HOST
                uKey="u6025971"
                SecretKey="Rjr>NJgR9\BD.V-T"
                APIKey="gDtAPG68Im8ObNx6G0ZyG4PbYSyzfpjt3qT8VN20"
            fi
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

TOKENFILE="/tmp/.token_MR_${ENV}.aut"

if [ -f $TOKENFILE ]; then
    tmstamp=$(head -n 1 $TOKENFILE)
    curstamp=$(date +%s)
    if (( curstamp - tmstamp > 1800 )); then
        refetch_token
    else
        token=$(tail -n 1 $TOKENFILE)
    fi
else
    refetch_token
fi

TemplateFile="${WORKDIR}/query_ViewMap_by_ViewId.tpl"
SparqlFile="${WORKDIR}/query_ViewMap_by_ViewId.sparql"

# Assemble target ecp-id into SparQL string
sed "s/%ECPID_V%/${ECPID_V}/" ${TemplateFile} > ${SparqlFile}

curl -s -X POST ${SPARQL_HOST}/metadata/sparql \
-H "Content-Type: application/sparql-query" \
-H "Accept: application/sparql-results+json" \
-H "x-api-key: ${APIKey}" \
-H "Authorization: ${token}" \
-d @${SparqlFile}

