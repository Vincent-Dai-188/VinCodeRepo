#!/bin/bash

. /data/vincent/slibs/fetch_token_MR.slib

function display_help
{
    echo "Usage: $UTILNAME <DistributionPairID,CDFVersionID> [-i] [-E <DEV|QA|Prod>] [-h]"
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 1 )); then
    display_help
    exit 1
fi

DPCV=$1
shift 1
ECPID_DP=$(echo "$DPCV" | awk -F, '{print $1}')
ECPID_CV=$(echo "$DPCV" | awk -F, '{print $2}')

showEnv=""
while getopts :ihE: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            elif [ "${ENV}" = "DEV" ]; then
                . $WORKDIR/ENV_config/DEV.cfg
            elif [ "${ENV}" = "Prod" ]; then
                . $WORKDIR/ENV_config/Prod.cfg
            else  # Sandbox
                . $WORKDIR/ENV_config/Sandbox.cfg
            fi
			;;
        i)  showEnv="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
    else
        # QA Env (default)
        . $WORKDIR/ENV_config/QA.cfg
    fi
fi

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***" 1>&2
fi

TOKENFILE="/tmp/.token_MR_${ENV}.aut"

get_token_MR

TemplateFile="${WORKDIR}/query_CIMaps.tpl"
SparqlFile="${WORKDIR}/query_CIMaps.sparql"

# Assemble target ecp-id into SparQL string
sed -e "s/%ECPID_DP%/${ECPID_DP}/;s/%ECPID_CV%/${ECPID_CV}/" ${TemplateFile} > ${SparqlFile}

retJson=$(${WORKDIR}/sparql_query_common ${SparqlFile})

CIMapSet=$(echo $retJson | jq -r '.results.bindings[].map.value')
for CIMapId in $CIMapSet; do
	echo -e "\n>> CIMapId: $CIMapId"
	echo "ContentItem Ids:"
	getThing $CIMapId | jq -r '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasContentItem" | if type=="array" then .[]."@id" else ."@id" end'
done
