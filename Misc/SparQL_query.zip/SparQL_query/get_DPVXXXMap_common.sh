#!/bin/bash

#
# Query the DistributionPair<TYPE>Map which has "hasDistributionPair" property of specified DistributionPairID and "hasVersion" property of specified CDFVersionID
#

function display_help
{
    echo "Usage: $UTILNAME <TYPE> <DistributionPairID> <CDFVersionID> [-h] [-E <DEV|QA|Sandbox>]"
    echo "       TYPE: VersionView|VersionContentItem|PartitionVersionStore|InstanceAgentRole"
}

function refetch_token
{
    # Outputs to stderr to avoid potential parse error when using jq
    echo "Re-Fetch Token ..." 1>&2
    # -H 'Content-Length: 0' (To avoid: Content-Length missing for POST or PUT requests)
    token=$(curl -s -X POST \
        -H "Key: ${uKey}" \
        -H "SecretKey: ${SecretKey}" \
        -H "x-api-key: ${APIKey}" \
        -H "Content-Length: 0" \
        ${HOST}/auth)

    if [ -z "$token" ]; then
        echo "*** Failed to obtain token! ***"
        exit 1
    fi
    #echo -e "\nNew token:\n${token}\n"
    date +%s > $TOKENFILE
    echo $token >> $TOKENFILE
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 3 )); then
    display_help
    exit 1
fi

TYPE=$1
ECPID_DP=$2
ECPID_V=$3
shift 3


while getopts :hE: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            elif [ "${ENV}" = "Sandbox" ]; then
                . $WORKDIR/ENV_config/Sandbox.cfg
            else  # DEV
                . $WORKDIR/ENV_config/DEV.cfg
            fi
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

TOKENFILE="/tmp/.token_MR_${ENV}.aut"

if [ -f $TOKENFILE ]; then
        tokenbuf="$(cat ${TOKENFILE})"
        tmstamp=$(echo "$tokenbuf" | head -n 1)
        curstamp=$(date +%s)
        if (( curstamp - tmstamp > 1800 )); then
            refetch_token
        else
            token=$(echo "$tokenbuf" | tail -n 1)
        fi
else
    refetch_token
fi

TemplateFile="${WORKDIR}/query_DPVXXXMap.tpl"
SparqlFile="${WORKDIR}/query_DPVXXXMap.sparql"

# Assemble target ecp-id into SparQL string
sed -e "s/%TYPE%/${TYPE}/;s/%ECPID_DP%/${ECPID_DP}/;s/%ECPID_V%/${ECPID_V}/" ${TemplateFile} > ${SparqlFile}

curl -s -X POST ${SPARQL_HOST}/metadata/sparql \
-H "Content-Type: application/sparql-query" \
-H "Accept: application/sparql-results+json" \
-H "x-api-key: ${APIKey}" \
-H "Authorization: ${token}" \
-d @${SparqlFile}

# # Convert sparql in plain text to URL
# QUERYSPL=`${WORKDIR}/URL_convert_SparQL.sh "$(cat ${SparqlFile})"`

# curl -s -X GET ${SPARQL_HOST}/metadata/sparql?query="${QUERYSPL}" \
# -H "Accept: application/sparql-results+json" \
# -H "x-api-key: ${APIKey}" \
# -H "Authorization: ${token}"

#-d 'PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> PREFIX ecpcdf: <https://graph.link/ecp/schema/CDF/> SELECT DISTINCT ?map WHERE { ?map rdf:type ecpcdf:DistributionPairVersionContentItemMap . ?map ecpcdf:hasDistributionPair <ecp:9-1fd631a7-92b0-4fd4-b813-9ec36dbff21e> . ?map ecpcdf:hasVersion <ecp:9-92a0ca30-8df4-4eb0-8e15-35581dd5cdc8> .}'

