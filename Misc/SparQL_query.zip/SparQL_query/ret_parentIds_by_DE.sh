#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 <DE_Id>"
    exit 1
fi

DEId=$1

sed "s/%OT_ID%/${DEId}/" query_parentIds_by_DEId.tpl > query_parentIds_by_DEId.sparql

./sparql_run query_parentIds_by_DEId.sparql
