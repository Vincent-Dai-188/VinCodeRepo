#!/bin/bash

DPID=$1

sed "s/%BTGDPID%/${DPID}/" query_BTG_Version_via_StoreMap.tpl > query_BTG_Version_via_StoreMap.sparql
./sparql_query_common query_BTG_Version_via_StoreMap.sparql

