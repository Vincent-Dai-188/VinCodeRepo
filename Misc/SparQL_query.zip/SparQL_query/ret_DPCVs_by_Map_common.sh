#!/bin/bash

if (( $# < 2 )); then
    echo "Usage: $0 <Map_name> <Map_ecpid>"
    exit 1
fi

MAPname=$1
MAPId=$2

sed -e "s/%MAP_ID%/${MAPId}/;s/%MAP_NAME%/${MAPname}/" query_DPCV_by_Map_common.tpl > query_DPCV_by_Map_common.saprql

ret=$(./sparql_run query_DPCV_by_Map_common.saprql | jq -rj '."results"."bindings"[] | "DP: ", ."DPId"."value", ", CV: ", ."CVId"."value", "\n"')
if [ -n "$ret" ]; then
    echo $ret
else
    echo "null"
fi
