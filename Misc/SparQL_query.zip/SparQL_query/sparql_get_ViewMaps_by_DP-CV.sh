#!/bin/bash

#
# Query all the DistributionPairVersionContentItemMap(s) which has "hasDistributionPair" property of specified DistributionPairID
#

function display_help
{
    echo "Usage: $UTILNAME <DistributionPairID> <CDFVersionID> [-h|-E <DEV|QA|Prod|Sandbox>]"
}

function refetch_token
{
    # Outputs to stderr to avoid potential parse error when using jq
    echo "Re-Fetch Token ..." 1>&2
    # -H 'Content-Length: 0' (To avoid: Content-Length missing for POST or PUT requests)
    token=$(curl -s -X POST \
        -H "Key: ${uKey}" \
        -H "SecretKey: ${SecretKey}" \
        -H "x-api-key: ${APIKey}" \
        -H "Content-Length: 0" \
        ${HOST}/auth)

    if [ -z "$token" ]; then
        echo "*** Failed to obtain token! ***"
        exit 1
    fi
    #echo -e "\nNew token:\n${token}\n"
    date +%s > $TOKENFILE
    echo $token >> $TOKENFILE
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 2 )); then
    display_help
    exit 1
fi

ECPID_DP=$1
ECPID_V=$2
shift 2

while getopts :hiJSE: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            elif [ "${ENV}" = "DEV" ]; then
                . $WORKDIR/ENV_config/DEV.cfg
            elif [ "${ENV}" = "Prod" ]; then
                . $WORKDIR/ENV_config/Prod.cfg
            else  # Sandbox
                . $WORKDIR/ENV_config/Sandbox.cfg
            fi
            ;;
        J)  JPARSE="true"
            ;;
        S)  SKIPTOKEN="true"    # Retrieve token from TOKEN_FILE without checking expiration period
            ;;
        i)  showEnv="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
    else
        # QA Env (default)
        . $WORKDIR/ENV_config/QA.cfg
    fi
fi

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***" 1>&2
fi

TOKENFILE="/tmp/.token_MR_${ENV}.aut"

if [ -f $TOKENFILE ]; then
    tmstamp=$(head -n 1 $TOKENFILE)
    curstamp=$(date +%s)
    if (( curstamp - tmstamp > 1800 )); then
        refetch_token
    else
        token=$(tail -n 1 $TOKENFILE)
    fi
else
    refetch_token
fi

TemplateFile="${WORKDIR}/query_StoreMaps.tpl"
SparqlFile="${WORKDIR}/query_StoreMaps.sparql"

# Assemble target ecp-id into SparQL string
sed "s/%ECPID_DP%/${ECPID_DP}/" ${TemplateFile} > ${SparqlFile}
sed -i "s/%ECPID_V%/${ECPID_V}/" ${SparqlFile}

curl -s -X POST ${SPARQL_HOST}/metadata/sparql \
-H "Content-Type: application/sparql-query" \
-H "Accept: application/sparql-results+json" \
-H "x-api-key: ${APIKey}" \
-H "Authorization: ${token}" \
-d @${SparqlFile}

#-d 'PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> PREFIX ecpcdf: <https://graph.link/ecp/schema/CDF/> SELECT DISTINCT ?map WHERE { ?map rdf:type ecpcdf:DistributionPairVersionContentItemMap . ?map ecpcdf:hasDistributionPair <ecp:9-1fd631a7-92b0-4fd4-b813-9ec36dbff21e> . }'
