#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <ecpid_DP> <ecpid_V> [-h|-E <DEV|Sandbox>|-T <json|nquads|trig>]"
}

function refetch_token
{
    # Outputs to stderr to avoid potential parse error when using jq
    echo "Re-Fetch Token ..." 1>&2
    # -H 'Content-Length: 0' (To avoid: Content-Length missing for POST or PUT requests)
    token=$(curl -s -X POST \
        -H "Key: ${uKey}" \
        -H "SecretKey: ${SecretKey}" \
        -H "x-api-key: ${APIKey}" \
        -H "Content-Length: 0" \
        ${HOST}/auth)

    if [ -z "$token" ]; then
        echo "*** Failed to obtain token! ***"
        exit 1
    fi
    #echo -e "\nNew token:\n${token}\n"
    date +%s > $TOKENFILE
    echo $token >> $TOKENFILE
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

# Accept: JSON-LD (default)
CONTTYPE="vnd.ecp.registry+json"

if (( $# >= 2 )); then
    ECPID_DP=$1
    ECPID_V=$2
    shift 2
else
    display_help
    exit 1
fi

while getopts :hE:T: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            elif [ "${ENV}" = "Sandbox" ]; then
                . $WORKDIR/ENV_config/Sandbox.cfg
            else  # DEV
                . $WORKDIR/ENV_config/DEV.cfg
            fi
            ;;
        T)  CONTTYPE=${OPTARG}
            if [ "${CONTTYPE}" = "nquads" ]; then
                CONTTYPE="vnd.ecp.registry+nquads"
            elif [ "${CONTTYPE}" = "trig" ]; then
                CONTTYPE="vnd.ecp.registry+trig"
            fi
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
    else
        # QA Env (default)
        . $WORKDIR/ENV_config/QA.cfg
    fi
fi

TOKENFILE="/tmp/.token_MR_${ENV}.aut"

if [ -f $TOKENFILE ]; then
    tokenbuf="$(cat ${TOKENFILE})"
    tmstamp=$(echo "$tokenbuf" | head -n 1)
    curstamp=$(date +%s)
    if (( curstamp - tmstamp > 1800 )); then
        refetch_token
    else
        token=$(echo "$tokenbuf" | tail -n 1)
    fi
else
    refetch_token
fi

curl -w "\n- status_code: %{http_code} -\n" -s -X GET ${HOST}/metadata/cdfview\?CDFComponent=${ECPID_DP}\&CDFVersion=${ECPID_V} \
    -H "Accept: application/${CONTTYPE};api-version=1" -H "x-api-key: ${APIKey}" -H "Authorization: ${token}"
