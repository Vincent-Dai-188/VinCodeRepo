#!/bin/bash

function display_help
{
    echo "Usage: $0 <DP-CV_list_filename"
}

function check_in_migration_scope	#ObjTypeID #DPID
{
	OBJID=$1
	DPID=$2

	ret=$(while read FILE; do egrep -s -l "${OBJID}|${DPID}" $FILE; done < exported_json_files_v1.1.79.lst)
	if [ -n "$ret" ]; then
		echo "$ret"
	else
		echo "None"
	fi
}

if (( $# < 1 )); then
    display_help
    exit 1
fi

DPCV_LIST_FILE=$1

echo "---------------------------- ${DPCV_LIST_FILE} ----------------------------"

sn=0
while read LINE; do
    DP_CV=$(echo $LINE | sed 's/,/ /')
    (( sn+=1 ))
    printf "\n[%02d] %s\n" $sn "${DP_CV}"
    StoreMap=$(./sparql_get_StoreMaps_by_DP-CV.sh ${DP_CV} | jq -r ".results.bindings[].map.value")
    for item in $StoreMap; do
        echo "- StoreMap: $item"
        ret=$(./getThing $item)
        if [ $? -eq 0 ] ; then
            echo -n "  - Partition: "
            PT=$(echo "$ret" | jq -r '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasPartition"."@id"')
            echo "$PT"
            thing_PT=$(./getThing $PT)

            relatedObjID=$(echo ${thing_PT} | jq -jr '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasRelatedObjectType"."@id"')
            echo "    - RelatedObjectType: $relatedObjID"
            echo -n "        - DP_Related: "            
            DP_Related=$(./ret_DP_by_OT_sparql.sh $relatedObjID | jq -r '."results"."bindings"[].sub | select(.type=="uri") | .value')
            if [ -n "${DP_Related}" ]; then
                echo ${DP_Related}
				echo -n "        >> [Check in migration scope]: "  
				check_in_migration_scope $relatedObjID $DP_Related
            else
                echo "None"
            fi

            relationObjID=$(echo ${thing_PT} | jq -jr '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasRelationObjectType"."@id"')
            echo "    - RelationObjectType: $relationObjID"
            echo -n "        - DP_Relation: "            
            DP_Relation=$(./ret_DP_by_OT_sparql.sh $relationObjID | jq -r '."results"."bindings"[].sub | select(.type=="uri") | .value')
            if [ -n "${DP_Relation}" ]; then
                echo ${DP_Relation}
				echo -n "        >> [Check in migration scope]: "  
				check_in_migration_scope $relationObjID $DP_Relation
            else
                echo "None"
            fi

        else
           echo "  - Partition: None"
        fi
    done
done < ${DPCV_LIST_FILE}
