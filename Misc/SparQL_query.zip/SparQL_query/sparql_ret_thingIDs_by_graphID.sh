#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <graph-id> [-J] [-S] [-i] [-h] [-E <DEV|QA|Sandbox>]"
}

function refetch_token
{
    # Outputs to stderr to avoid potential parse error when using jq
    echo "Re-Fetch Token ..." 1>&2
    # -H 'Content-Length: 0' (To avoid: Content-Length missing for POST or PUT requests)
    token=$(curl -s -X POST \
        -H "Key: ${uKey}" \
        -H "SecretKey: ${SecretKey}" \
        -H "x-api-key: ${APIKey}" \
        -H "Content-Length: 0" \
        ${HOST}/auth)

    if [ -z "$token" ]; then
        echo "*** Failed to obtain token! ***"
        exit 1
    fi
    #echo -e "\nNew token:\n${token}\n"
    date +%s > $TOKENFILE
    echo $token >> $TOKENFILE
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

JPARSE="true"
showEnv=""
SKIPTOKEN=""


if (( $# >= 1 )); then
    GRAPH_ID=$1
    shift
else
    display_help
    exit 1
fi

while getopts :hiJSE: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                . $WORKDIR/ENV_config/QA.cfg
            elif [ "${ENV}" = "Sandbox" ]; then
                . $WORKDIR/ENV_config/Sandbox.cfg
            else  # DEV
                . $WORKDIR/ENV_config/DEV.cfg
            fi
            ;;
        J)  JPARSE="true"
            ;;
        S)  SKIPTOKEN="true"    # Retrieve token from TOKEN_FILE without checking expiration period
            ;;
        i)  showEnv="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${ENV}" ]; then
    if [ -n "${ENV_GLOBAL}" ]; then
        . $WORKDIR/ENV_config/${ENV_GLOBAL}.cfg
    else
        # DEV Env (default)
        . $WORKDIR/ENV_config/DEV.cfg
    fi
fi

if [ "${showEnv}" = "true" ]; then
    echo "*** ENV: ${ENV} ***" 1>&2
fi

TOKENFILE="/tmp/.token_MR_${ENV}.aut"

if [ -f $TOKENFILE ]; then
    if [ -n "${SKIPTOKEN}" ]; then
        token=$(tail -n 1 $TOKENFILE)
    else
        tokenbuf="$(cat ${TOKENFILE})"
        tmstamp=$(echo "$tokenbuf" | head -n 1)
        curstamp=$(date +%s)
        if (( curstamp - tmstamp > 1800 )); then
            refetch_token
        else
            token=$(echo "$tokenbuf" | tail -n 1)
        fi
    fi
else
    refetch_token
fi

TemplateFile_ThingIDs="${WORKDIR}/sparql_thingIDs_by_graphID.tpl"
SparqlFile_ThingIDs="${WORKDIR}/sparql_thingIDs_by_graphID.sparql"

# Assemble target ecp-id into SparQL string
sed "s/%GRAPHID%/${GRAPH_ID}/" ${TemplateFile_ThingIDs} > ${SparqlFile_ThingIDs}

ret=`curl -s -X POST ${SPARQL_HOST}/metadata/sparql \
-H "Content-Type: application/sparql-query" \
-H "Accept: application/sparql-results+json" \
-H "x-api-key: ${APIKey}" \
-H "Authorization: ${token}" \
-d @${SparqlFile_ThingIDs}`

# Retrieve the length of the result array
len=$(echo "$ret" | jq -r '."results"."bindings" | length')
echo ">> Number of involved Things: $len"
sleep 1

# Display each ECPID
#echo "$ret" | jq -r '."results"."bindings"[].sub.value' | more
echo "$ret" | jq -r '."results"."bindings"[].sub.value'

