#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 <DP_ID>"
    exit 2
fi

DPId=$1

fname="query_CVs_by_DP"

echo ">> Assemble ECPID into SparQL"

sed "s/%DP_ID%/${DPId}/" ./${fname}.tpl > ./${fname}.sparql
sleep 1

./sparql_query_common ./${fname}.sparql
