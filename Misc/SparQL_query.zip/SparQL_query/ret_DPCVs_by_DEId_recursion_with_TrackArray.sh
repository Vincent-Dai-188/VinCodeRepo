#!/bin/bash

# Get the parent IDs by Dataelement ID
#   Filter the ContentItem IDs (DP & CV will be found out via a singlr SparQL)
#       output DP & CV for each ID above
#    Filter the OneToManyDtaElement and OneToOneDtaElement IDs
#       if not empty, for each ID above, invoke the "Get the parent IDs by Dataelement ID" function recursively
#       if empty, return

function print_indent
{
	(( IndentNum = nInt * 2 ))
    printf '%*s' $IndentNum
}

function get_DPCV_by_DE #DEId
{
    local DEId
    DEId=$1
	DEArray+=([$DEId]=$((nInt)))
	#print_indent && echo ">>> ${DEArray[@]} <<<"
    print_indent && echo "<>-------------------- BEGIN ($DEId) {nInt: $nInt} --------------------<>"
    DETag=$(echo "$DEId" | sed 's/ecp://')
    TMPFILE="$TMPDIR/out_parentIDs_of_$DETag.json"
    ./ret_parentIDs_by_DE.sh $DEId > "$TMPFILE"

    # Process ContentItems
    CISet=$(jq -r '.results.bindings[] | select(.rdfType.value == "https://graph.link/ecp/schema/CDF/ContentItem") | .sub.value' "$TMPFILE")
    CIsn=0
    for CIId in $CISet; do
        (( CIsn++ ))
        print_indent
        printf "(%02d) CI: %s  DP,CV: " $CIsn $CIId
        ./ret_DPCVs_by_CI.sh $CIId
    done

    # Process OneToManyDtaElements and OneToOneDtaElements
    local OTXSet
    OTXSet=$(jq -r '.results.bindings[] | select(.rdfType.value | endswith("/CDF/OneToOneDataElement") or endswith("/CDF/OneToManyDataElement")) | .sub.value' "$TMPFILE")
    (( nInt++ ))
    for OTXId in $OTXSet; do
		if [ -z "${DEArray[$OTXId]}" ]; then
			get_DPCV_by_DE $OTXId
		else
			echo "[ERROR] \"Dead Loop\" detected with DEId '$OTXId'! Recursive processing aborted!"
		fi
    done
	unset DEArray[$DEId]
    (( nInt-- ))
	#print_indent && echo ">>> ${DEArray[@]} <<<"
    print_indent && echo "<>--------------------- END ($DEId) {nInt: $nInt} ---------------------<>"
}

if (( $# < 1 )); then
    echo "Usage: $0 <DataElement_ECPID>"
    exit 1
fi

DEID=$1

TMPDIR="./tmp_workspace"

# Define an associative array with index (0,1,...) to track all the DEs in the recursion to detect "dead loop"
declare -A DEArray=()

mkdir -p $TMPDIR

nInt=0

#get_DPCV_by_DE ecp:9-a385cb59-a2a9-4614-8afe-999f9935994b
#get_DPCV_by_DE ecp:9-6029e739-03a3-4543-b9af-2accaf1f45f5
# known data with "dead loop" issue (S22):  ecp:9-54446e62-2833-40e6-9a51-a4ab5c8e6a6f  ecp:9-62709d60-53fc-4774-bcd5-dde8cc478f44
get_DPCV_by_DE "$DEID"
