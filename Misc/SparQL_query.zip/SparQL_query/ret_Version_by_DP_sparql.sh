#!/bin/bash

DPID=$1

sed "s/%DPID%/${DPID}/" query_Version_via_StoreMap.tpl > query_Version_via_StoreMap.sparql
./sparql_query_common query_Version_via_StoreMap.sparql

