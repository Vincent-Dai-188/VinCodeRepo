#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 <DP_Id>"
    exit 1
fi

DPId=$1
sed "s/%DP_ID%/${DPId}/" query_CVs_by_DP.tpl > query_CVs_by_DP.saprql

./sparql_run query_CVs_by_DP.saprql
