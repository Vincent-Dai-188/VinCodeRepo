#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 <OT_Id>"
    exit 1
fi

OTId=$1

sed "s/%OT_ID%/${OTId}/" query_CIs_by_OT.tpl > query_CIs_by_OT.sparql

./sparql_run query_CIs_by_OT.sparql
