#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 <OT_Id>"
    exit 1
fi

OTId=$1
sed "s/%OT_ID%/${OTId}/" query_DPCVs_by_OT.tpl > query_DPCVs_by_OT.sparql

./sparql_query_common query_DPCVs_by_OT.sparql | jq -rj '."results"."bindings"[] | ."dp"."value", ",", ."cv"."value", "  ", ."dplabel"."value", " ", ."cvlabel"."value", "\n"'
