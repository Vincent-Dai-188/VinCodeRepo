#!/bin/bash

DPID=$1

sed "s/%DP_ID%/${DPID}/" query_Archetype_by_DP.tpl > query_Archetype_by_DP.sparql

./sparql_query_common query_Archetype_by_DP.sparql | jq -r '.results.bindings[0].atlabel.value'

