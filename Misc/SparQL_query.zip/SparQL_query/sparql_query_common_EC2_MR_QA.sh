#!/bin/bash

export http_proxy="webproxy.far.corp.services:80"
export https_proxy="webproxy.far.corp.services:80"

#export http_proxy="webproxy.hzl.corp.services:80"
#export https_proxy="webproxy.hzl.corp.services:80"

function display_help
{
    echo "Usage: $UTILNAME <SparQL_file>"
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# >= 1 )); then
    SparqlFile=$1
    if [ ! -f $SparqlFile ]; then
        echo "Specified SparQL file '$SparqlFile' not found!" 1>&2
        exit 2
    fi
else
    display_help
    exit 1
fi

ENV="QA"
HOST="https://server.qa.ecp-registry.refinitiv.com"
SPARQL_HOST="http://a204121qanlb-2588124a14c0d9c1.elb.us-east-1.amazonaws.com"
uKey="u6064334"
SecretKey="M\$FFXR_tH8b?Y~9!"
APIKey="pVw5gWw9d48wKssfe7PV41O61b7SsHDk9AjYQqFA"
AWSPROFILE="a-corporate-preprod"
S3BUCKET="a204121-content-ecpmeta-qa-use1"
S3BUCKET_ENV="a204121-vincent-test"
ENVOPT="-M"

# Convert sparql in plain text to URL
QUERYSPL=`${WORKDIR}/URL_convert_SparQL.sh "$(cat ${SparqlFile})"`

ret=$(curl -s -X GET ${SPARQL_HOST}/metadata/sparql?query="${QUERYSPL}" -H "Accept: application/sparql-results+json")

if [ -n "$ret" ]; then
	echo "$ret" | grep -o 'ERROR: The requested URL could not be retrieved' &>/dev/null
	if [ $? -ne 0 ]; then
		echo "$ret"
	else
		echo "*** ERROR: The requested URL could not be retrieved ***" 1>&2
		exit 3
	fi
fi
