#!/bin/bash

if (( $# < 1 )); then
	echo "Usage: $0 <contentItem Id>"
	exit 1
fi

CIId=$1
sed "s/%CI_ID%/${CIId}/" query_DP_CV_StoreMap_by_CI.tpl > tmp_query_DP_CV_StoreMap_by_CI.saprql

./sparql_run tmp_query_DP_CV_StoreMap_by_CI.saprql
