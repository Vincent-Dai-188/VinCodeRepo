#!/bin/bash

function display_help
{
    echo "Usage: $0 <DP-CV_list_filename"
}

function check_in_migration_scope   #ObjTypeID #DPID
{
    OBJID=$1
    DPID=$2

    ret=$(while read FILE; do egrep -s -l "${OBJID}|${DPID}" $FILE; done < exported_json_files_v1.1.79.lst)
    if [ -n "$ret" ]; then
        echo "$ret"
    else
        echo "None"
    fi
}

if (( $# < 1 )); then
    display_help
    exit 1
fi

DPCV_LIST_FILE=$1

echo "---------------------------- ${DPCV_LIST_FILE} ----------------------------"

sn=0
while read LINE; do
    DP_CV=$(echo $LINE | sed 's/,/ /')
    (( sn+=1 ))
    printf "\n[%02d] %s\n" $sn "${DP_CV}"
    StoreMap=$(./sparql_get_StoreMaps_by_DP-CV.sh ${DP_CV} | jq -r ".results.bindings[].map.value")
    for item in $StoreMap; do
        echo "- StoreMap: $item"
        ret=$(./getThing $item)
        if [ $? -eq 0 ] ; then
            echo -n "  - Partition: "
            PT=$(echo "$ret" | jq -r '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasPartition"."@id"')
            echo "$PT"
            thing_PT=$(./getThing $PT)
			if [ $? -eq 0 ] ; then
				echo "$thing_PT" | jq -rj '."@graph"[0] | "    >> label: ", ."http://www.w3.org/2000/01/rdf-schema#label", "  description: ", ."http://purl.org/dc/elements/1.1/description", "\n"'
			fi
        else
           echo "  - Partition: None"
        fi
    done
done < ${DPCV_LIST_FILE}
