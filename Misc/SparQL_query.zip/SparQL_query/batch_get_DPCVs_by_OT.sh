#!/bin/bash

if (( $# < 1 )); then
	echo "Usage: $0 <OT_LIST_FILE>"
	exit 1
fi

OT_LIST_FILE=$1

while read OT; do
    echo -n "$OT    "
    echo "$OT" | grep '^ecp:' &>/dev/null
    if [ $? -eq 0 ]; then
        ret=$(./ret_DPCVs_by_OT.sh $OT)
		if [ -n "$ret" ]; then
			echo "$ret"
		else
			echo "Not Found"
		fi
    else
        echo "Null"
    fi
done < "${OT_LIST_FILE}"
