import json
import boto3

message = {"foo": "bar"}
sns_client = boto3.client('sns')
response = sns_client.publish(
    TargetArn='arn:aws:sns:us-east-1:015887481462:xxxxx',
    Message=json.dumps({'default': json.dumps(message)}),
    Subject='Email subject',
    MessageStructure='json'
)