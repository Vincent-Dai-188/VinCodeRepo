#!/bin/bash

TARGETZIP="/home/204618-PowerUser/vincent/test_py/pkg/lambda_function.zip"

if [ -f "${TARGETZIP}" ]; then
    rm -f ${TARGETZIP}
fi

cd -P /home/204618-PowerUser/vincent/test_py/venv_lambda_py27/lambda_t1/

# Pack all the files, directories & sub-directories into a zip file, including hidden directories & files (e.g., .libs_cffi_backend)
zip -r ${TARGETZIP} ./

echo -e "\n-------------------------------------------------"
ls -lh ${TARGETZIP}
echo -e "-------------------------------------------------\n"

read -p "Upload the new lambda zip file to S3 (zip_lambda/autopilot/)? [Y] " ret_ans
if [ -z $ret_ans ] || [ $ret_ans != "Y" ]; then
        echo "Abort!" ; exit 1
fi

BUCKET="cat-s3-store-vin1"
KEY="zip_lambda/autopilot/lambda_function.zip"
LAMBDAFUNC="arn:aws:lambda:us-east-1:015887481462:function:Lambda_autopilot_event_handler_Vincent"

aws s3 cp $TARGETZIP s3://${BUCKET}/${KEY}  #--dryrun

sleep 3

aws lambda update-function-code --function-name $LAMBDAFUNC --s3-bucket ${BUCKET} --s3-key ${KEY}   #--dry-run
