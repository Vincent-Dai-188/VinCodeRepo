import os
import sys
import boto3
import paramiko

# {
  # "version": "0",
  # "id": "5bb4aaff-22b5-0a31-b7c5-c1efd2ce9d60",
  # "detail-type": "EMR Cluster State Change",
  # "source": "aws.emr",
  # "account": "015887481462",
  # "time": "2019-03-12T02:43:51Z",
  # "region": "us-east-1",
  # "resources": [],
  # "detail": {
    # "severity": "INFO",
    # "stateChangeReason": "{\"code\":\"USER_REQUEST\" ,\"message\":\"Terminated by user request\"}",
    # "name": "Cluster_EnrichBatch_TRF_Combo_ES14_HBase",
    # "clusterId": "j-2U7OBLN0FSMZE",
    # "state": "TERMINATED",
    # "message": "Amazon EMR Cluster j-2U7OBLN0FSMZE (Cluster_EnrichBatch_TRF_C...) has terminated at 2019-03-12 02:43 UTC with a reason of USER_REQUEST."
  # }
# }

def exec_cmds_EC2_SSH(ec2_host, commands):
    pem_file = '/tmp/key_ec2_AP.pem'

    s3_client = boto3.client('s3')
    s3_client.download_file('cat-s3-store-vin1','test/key_AP_env.pem', pem_file)

    k = paramiko.RSAKey.from_private_key_file(pem_file)
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    print "Connecting to " + ec2_host
    c.connect( hostname = ec2_host, username = "ec2-user", pkey = k )
    print "Connected to " + ec2_host

    for command in commands:
        print "Executing {}".format(command)
        stdin, stdout, stderr = c.exec_command(command)
        print stdout.read()
        print stderr.read()

def lambda_handler(event, context):
    event_type = event['detail-type']
    event_time = event['time']
    details = event['detail']
    name = details['name']
    cluster_id = details['clusterId']
    state = details['state']
    message = details['message']

    if (event_type == "EMR Step Status Change") and (state == "CANCELLED"):
        print "+ 'EMR Step Status Change -- ", state, "' detected! +"
    else:
        if (event_type == "EMR Cluster State Change") and ((state == "TERMINATED") or (state == "TERMINATED_WITH_ERRORS")):
            print "* 'EMR Cluster State Change -- ", state, "' detected! *"
            print ">> Stop pipeline 'Enrich_TRF_Combo_ES14_HBase_r524x3_023' ..."

            #"pipelinectrl -n Enrich_TRF_Combo_ES14_HBase_r524x3_023 create -f /home/ec2-user/vincent/0.2.3/view_trf_Combo/pipelineConfig_Enrich_TRF_Combo_ES14_r5d24x3_hbase_DISK_ONLY.json",
            commands = [
                "pipelinectrl -n Enrich_TRF_Combo_ES14_HBase_r524x3_023 stop",
                "aws lambda remove-permission --function-name Lambda_autopilot_event_handler_Vincent --statement-id events-access-autotest-AP"
                ]
            #print commands
            exec_cmds_EC2_SSH('10.0.173.248', commands)

    print "-> [ ", event_type, " -- ", state, " (", name, ") ] (PassThrough)"
    return {
        'type': event_type,
        'name': name,
        'cluster_id': cluster_id,
        'state/status': state,
        'message': message
    }
