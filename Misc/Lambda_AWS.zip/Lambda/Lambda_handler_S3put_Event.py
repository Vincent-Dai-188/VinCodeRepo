import boto3
import os
import sys
import uuid
import json

def lambda_handler(event, context):
    # TODO implement
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key'] 
        retmsg = 'Readed object (' + key + ') content in S3 bucket ' + bucket + ' and copy it.'

    s3 = boto3.client('s3')
    response = s3.get_object(Bucket=bucket, Key=key)
    contents = response['Body'].read().decode('utf-8')
    print(f"*** {key}: {contents} ***")
    
    print('CHK-1: ' + os.popen("ls /tmp/").read())                          /* Always return empty */
    download_path = '/tmp/{}{}'.format(uuid.uuid4(), 'README_S3_SWAP')      /* Use 'README_S3_SWAP' instead of variable 'key', to avoid "FileNotFoundError". [1*] */ 
    s3.download_file(bucket, key, download_path)
    print('CHK-2: ' + os.popen("ls /tmp/").read())
    s3.upload_file(download_path, bucket, '{}2'.format(key))

    return {
        'statusCode': 200,
        'body': json.dumps(retmsg)
    }

[1*]: Do *not* use variable 'key' to generate 'download_path'. It would be something like '/tmp/7a39f4f8-2223-4800-8e54-5d80d46aa78dtest/README.txt', due to the 3rd '/' (test/README.txt), you will hit "No such file or directory: '/tmp/7a39f4f8-2223-4800-8e54-5d80d46aa78dtest/README.txt.BEBEd9Ae': FileNotFoundError" when calling s3.download_file(bucket, key, download_path).

/* type(contents = response['Body'].read()): bytes */
-----------------------------------------------------------------------------------------------
/* S3putObj Event message (test) */
{
  "Records": [
    {
      "eventVersion": "2.0",
      "eventSource": "aws:s3",
      "awsRegion": "us-east-1",
      "eventTime": "1970-01-01T00:00:00.000Z",
      "eventName": "ObjectCreated:Put",
      "userIdentity": {
        "principalId": "EXAMPLE"
      },
      "requestParameters": {
        "sourceIPAddress": "127.0.0.1"
      },
      "responseElements": {
        "x-amz-request-id": "EXAMPLE123456789",
        "x-amz-id-2": "EXAMPLE123/5678abcdefghijklambdaisawesome/mnopqrstuvwxyzABCDEFGH"
      },
      "s3": {
        "s3SchemaVersion": "1.0",
        "configurationId": "testConfigRule",
        "bucket": {
          "name": "cat-s3-store-vin1",
          "ownerIdentity": {
            "principalId": "EXAMPLE"
          },
          "arn": "arn:aws:s3:::example-bucket"
        },
        "object": {
          "key": "test/README.txt",
          "size": 1024,
          "eTag": "0123456789abcdef0123456789abcdef",
          "sequencer": "0A1B2C3D4E5F678901"
        }
      }
    }
  ]
}

------------------------------------------------------------

/* print(response) */

{
  'ResponseMetadata': {
    'RequestId': 'F42BC8A14458DA5F',
    'HostId': '7kXwl4yTKoOAFvBGQ/BHbozdkMZeSjcwl182pIjHMP0I+B8NcmtGBsEPLdyQEdUKeIf9y1JLfpA=',
    'HTTPStatusCode': 200,
    'HTTPHeaders': {
      'x-amz-id-2': '7kXwl4yTKoOAFvBGQ/BHbozdkMZeSjcwl182pIjHMP0I+B8NcmtGBsEPLdyQEdUKeIf9y1JLfpA=',
      'x-amz-request-id': 'F42BC8A14458DA5F',
      'date': 'Thu, 07 Mar 2019 08:59:43 GMT',
      'last-modified': 'Thu, 07 Mar 2019 08:01:39 GMT',
      'etag': '"b0d177fbe933cbc5066643a5fe265ce6"',
      'x-amz-version-id': 'F27ZiCMzu2HAtb_J23ks0F4OUnM10_H1',
      'accept-ranges': 'bytes',
      'content-type': 'text/plain',
      'content-length': '33',
      'server': 'AmazonS3'
    },
    'RetryAttempts': 0
  },
  'AcceptRanges': 'bytes',
  'LastModified': datetime.datetime(2019, 3, 7, 8, 1, 39, tzinfo = tzutc()),
  'ContentLength': 33,
  'ETag': '"b0d177fbe933cbc5066643a5fe265ce6"',
  'VersionId': 'F27ZiCMzu2HAtb_J23ks0F4OUnM10_H1',
  'ContentType': 'text/plain',
  'Metadata': {},
  'Body':  < botocore.response.StreamingBody object at 0x7f5be9517ef0 >
}