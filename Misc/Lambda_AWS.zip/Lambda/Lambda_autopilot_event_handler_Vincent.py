import os
import sys
import boto3
import json
import paramiko

"""
{
  "version": "0",
  "id": "5bb4aaff-22b5-0a31-b7c5-c1efd2ce9d60",
  "detail-type": "EMR Cluster State Change",
  "source": "aws.emr",
  "account": "015887481462",
  "time": "2019-03-12T02:43:51Z",
  "region": "us-east-1",
  "resources": [],
  "detail": {
    "severity": "INFO",
    "stateChangeReason": "{\"code\":\"USER_REQUEST\" ,\"message\":\"Terminated by user request\"}",
    "name": "Cluster_EnrichBatch_TRF_Combo_ES14_HBase",
    "clusterId": "j-2U7OBLN0FSMZE",
    "state": "TERMINATED",
    "message": "Amazon EMR Cluster j-2U7OBLN0FSMZE (Cluster_EnrichBatch_TRF_C...) has terminated at 2019-03-12 02:43 UTC with a reason of USER_REQUEST."
  }
}
"""

F_RESULT = '/tmp/Final_State_EMR.inf'

def exec_cmds_EC2_SSH(ec2_host, commands):
    pem_file = '/tmp/key_ec2_AP.pem'
    if not os.path.isfile(pem_file):
        s3_client = boto3.client('s3')
        s3_client.download_file('cat-s3-store-vin1','test/key_AP_env.pem', pem_file)

    k = paramiko.RSAKey.from_private_key_file(pem_file)
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    print "Connecting to " + ec2_host
    c.connect( hostname = ec2_host, username = "ec2-user", pkey = k )
    print "Connected to " + ec2_host

    for command in commands:
        print "Executing {}".format(command)
        stdin, stdout, stderr = c.exec_command(command)
        print stdout.read()
        print stderr.read()

def push_result_EMR(APHOST, ResultCode, event):
    print ">> Push EMR cluster final state notification ..."
    DetailMsg = json.dumps(event['detail'])
    InnerMsg = "{\"StateCode\":" + str(ResultCode) + ",\"detail\":" + DetailMsg + "}"

    pushinf_cmd = "echo '" + InnerMsg + "' > " + F_RESULT
    commands = [ pushinf_cmd ]
    exec_cmds_EC2_SSH(APHOST, commands)

def stop_pipeline_and_disable_lambda(APHOST, PIPELINE, LAMBDAFUNC):
    print ">> Stop pipeline '" + PIPELINE + "' and disable lambda '" + LAMBDAFUNC + "' ..."
    commands = [
        "pipelinectrl -n " + PIPELINE + " stop",
        "aws lambda remove-permission --function-name " + LAMBDAFUNC + " --statement-id events-access-autotest-AP"
        ]
    exec_cmds_EC2_SSH(APHOST, commands)

def stop_pipeline_and_disable_lambda_and_terminate_cluster(APHOST, PIPELINE, LAMBDAFUNC, ClusterId):
    print ">> Stop pipeline '" + PIPELINE + "', disable lambda '" + LAMBDAFUNC + "' and terminate EMR Cluster '" + ClusterId + "' ..."
    commands = [
        "pipelinectrl -n " + PIPELINE + " stop",
        "aws lambda remove-permission --function-name " + LAMBDAFUNC + " --statement-id events-access-autotest-AP",
        "aws emr terminate-clusters --cluster-ids " + ClusterId
        ]
    exec_cmds_EC2_SSH(APHOST, commands)

def send_message_to_sns(event):
    sns_client = boto3.client('sns')
    response = sns_client.publish(
        TargetArn='arn:aws:sns:us-east-1:015887481462:SNS_EMR_state_changes_Vincent',
        Message=json.dumps({'default': json.dumps(event)}),
        Subject=event['detail-type']+' -- '+event['detail']['state'],
        MessageStructure='json'
    )

def lambda_handler(event, context):
    event_type = event['detail-type']
    event_time = event['time']
    details = event['detail']
    name = details['name']
    cluster_id = details['clusterId']
    state = details['state']
    message = details['message']

    LAMBDAFUNC = "Lambda_autopilot_event_handler_Vincent"

    # Retrieve pipeline name from Environment Variable
    PIPELINE = os.environ['PIPELINE']
    APHOST = os.environ['APHOST']

    if state == "PENDING":
        return {
            'action': 'bypass'
        }
    elif state == "WAITING":
        if event_type == "EMR Cluster State Change":
            json_obj = json.loads(details['stateChangeReason'])
            ChangeReasonMsg = json_obj['message']
            if ChangeReasonMsg == "Cluster ready after last step failed.":
                send_message_to_sns(event)
                print "* 'Cluster ready after last step failed' detected! *"
                stop_pipeline_and_disable_lambda_and_terminate_cluster(APHOST, PIPELINE, LAMBDAFUNC, cluster_id)
                push_result_EMR(APHOST, 1, event)
            else:
                return {
                    'action': 'bypass'
                }
        else:
            return {
                'action': 'bypass'
            }
    else:
        send_message_to_sns(event)
        if (event_type == "EMR Step Status Change") and (state == "CANCELLED"):
            print "+ 'EMR Step Status Change -- ", state, "' detected! +"
        elif event_type == "EMR Cluster State Change":
            if ((state == "TERMINATED") or (state == "TERMINATED_WITH_ERRORS")):
                print "* 'EMR Cluster State Change -- ", state, "' detected! *"
                stop_pipeline_and_disable_lambda(APHOST, PIPELINE, LAMBDAFUNC)
                if state == "TERMINATED":
                    push_result_EMR(APHOST, 0, event)
                else:
                    push_result_EMR(APHOST, 2, event)
                
    print "-> [ ", event_type, " -- ", state, " (", name, ") ] (PassThrough)"
    return {
        'type': event_type,
        'name': name,
        'cluster_id': cluster_id,
        'state/status': state,
        'message': message
    }
