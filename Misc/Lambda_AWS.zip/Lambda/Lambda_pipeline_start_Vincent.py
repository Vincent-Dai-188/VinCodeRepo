import os
import sys
import boto3
import json
import paramiko

# Input:
# {
  # "AP_HOST": "10.0.173.248",
  # "UTILITY": "/home/ec2-user/vincent/Events/AP_Events_autotest.sh",
  # "ACT_WORKER": "nohup python -u /home/ec2-user/vincent/venv_py27/act_worker/act_worker_autotest.py &>/tmp/nohup_actworker.out &",
  # "PIPE_NAME": "Enrich_TRF_Combo_ES14_HBase_r44x4_023",
  # "PIPE_CONF": "/home/ec2-user/vincent/0.2.3/view_trf_Combo/pipelineConfig_Enrich_TRF_Combo_ES14_r44x4_hbase_DISK_ONLY_A2.json"
# }

def exec_cmds_EC2_SSH(ec2_host, commands):
    pem_file = '/tmp/key_ec2_AP.pem'

    s3_client = boto3.client('s3')
    s3_client.download_file('cat-s3-store-vin1','test/key_AP_env.pem', pem_file)

    k = paramiko.RSAKey.from_private_key_file(pem_file)
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    print "Connecting to " + ec2_host
    c.connect( hostname = ec2_host, username = "ec2-user", pkey = k )
    print "Connected to " + ec2_host

    aputilcmd = commands[0]
    print "Executing {}".format(aputilcmd)
    stdin, stdout, stderr = c.exec_command(aputilcmd)
    outmsg = stdout.read()
    print outmsg
    errmsg = stderr.read()
    print errmsg

    if errmsg:
        return {
            'StateCode': 1,
            'Status': 'FAIL',
            'message': errmsg
        }
    else:
        workercmd = commands[1]
        print "Executing {}".format(workercmd)
        stdin, stdout, stderr = c.exec_command(workercmd)

        return {
            'StateCode': 0,
            'Status': 'SUCCEED',
            'ClusterID': outmsg
        }

"""
def send_message_to_sns(event):
    sns_client = boto3.client('sns')
    response = sns_client.publish(
        TargetArn='arn:aws:sns:us-east-1:015887481462:SNS_EMR_state_changes_Vincent',
        Message=json.dumps({'default': json.dumps(event)}),
        Subject=event['detail-type']+' -- '+event['detail']['state'],
        MessageStructure='json'
    )
"""

def lambda_handler(event, context):
    APHOST = event['AP_HOST']
    APUTIL = event['UTILITY']
    actworker = event['ACT_WORKER']
    PIPELINENM = event['PIPE_NAME']
    PIPELINECFG = event['PIPE_CONF']

    utilcmd = APUTIL + " " + PIPELINENM + " " + PIPELINECFG
    commands = [
        utilcmd,
        actworker
        ]
    print commands

    ret = exec_cmds_EC2_SSH(APHOST, commands)
    return ret
