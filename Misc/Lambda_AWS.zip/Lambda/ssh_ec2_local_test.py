import os
import sys
import boto3
import paramiko

#def worker_handler(event, context):
def worker_handler():

    s3_client = boto3.client('s3')

    #Download private key file from secure S3 bucket
    s3_client.download_file('cat-s3-store-vin1','test/key_ec2_dy.pem', '/tmp/key_ec2.pem')

    k = paramiko.RSAKey.from_private_key_file("/tmp/key_ec2.pem")
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    host = '10.0.160.82'
    print "Connecting to " + host
    c.connect( hostname = host, username = "ec2-user", pkey = k )
    print "Connected to " + host

    commands = [
        "aws s3 cp s3://cat-s3-store-vin1/Software_store/check_es /home/ec2-user/lambda_test/check_es.sh",
        "chmod 700 /home/ec2-user/lambda_test/check_es.sh",
        "/home/ec2-user/lambda_test/check_es.sh &> /tmp/check_es.out",
        "cat /tmp/check_es.out"
        ]
    for command in commands:
        print "Executing {}".format(command)
        stdin, stdout, stderr = c.exec_command(command)
        print stdout.read()
        print stderr.read()

if __name__ == "__main__":
    worker_handler()
