import os
import sys
import boto3
import json
import paramiko

# {
  # "version": "0",
  # "id": "5bb4aaff-22b5-0a31-b7c5-c1efd2ce9d60",
  # "detail-type": "EMR Cluster State Change",
  # "source": "aws.emr",
  # "account": "015887481462",
  # "time": "2019-03-12T02:43:51Z",
  # "region": "us-east-1",
  # "resources": [],
  # "detail": {
    # "severity": "INFO",
    # "stateChangeReason": "{\"code\":\"USER_REQUEST\" ,\"message\":\"Terminated by user request\"}",
    # "name": "Cluster_EnrichBatch_TRF_Combo_ES14_HBase",
    # "clusterId": "j-2U7OBLN0FSMZE",
    # "state": "TERMINATED",
    # "message": "Amazon EMR Cluster j-2U7OBLN0FSMZE (Cluster_EnrichBatch_TRF_C...) has terminated at 2019-03-12 02:43 UTC with a reason of USER_REQUEST."
  # }
# }

PIPELINE='Enrich_TRF_Combo_ES14_HBase_r44x4_023'

def exec_cmds_EC2_SSH(ec2_host, commands):
    pem_file = '/tmp/key_ec2_AP.pem'

    s3_client = boto3.client('s3')
    s3_client.download_file('cat-s3-store-vin1','test/key_AP_env.pem', pem_file)

    k = paramiko.RSAKey.from_private_key_file(pem_file)
    c = paramiko.SSHClient()
    c.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    print "Connecting to " + ec2_host
    c.connect( hostname = ec2_host, username = "ec2-user", pkey = k )
    print "Connected to " + ec2_host

    for command in commands:
        print "Executing {}".format(command)
        stdin, stdout, stderr = c.exec_command(command)
        print stdout.read()
        print stderr.read()

def send_message_to_sns(event):
    sns_client = boto3.client('sns')
    response = sns_client.publish(
        TargetArn='arn:aws:sns:us-east-1:015887481462:SNS_EMR_state_changes_Vincent',
        Message=json.dumps({'default': json.dumps(event)}),
        Subject=event['detail-type']+' -- '+event['detail']['state'],
        MessageStructure='json'
    )

def lambda_handler(event, context):
    event_type = event['detail-type']
    event_time = event['time']
    details = event['detail']
    name = details['name']
    cluster_id = details['clusterId']
    state = details['state']
    message = details['message']

    if state == "PENDING":
        return {
            'action': 'bypass'
        }
    elif state == "WAITING":
        if event_type == "EMR Cluster State Change":
            json_obj = json.loads(details['stateChangeReason'])
            ChangeReasonMsg = json_obj['message']
            if ChangeReasonMsg == "Cluster ready after last step failed.":
                send_message_to_sns(event)
                print "* 'Cluster ready after last step failed' detected! *"
            else:
                return {
                    'action': 'bypass'
                }
        else:
            return {
                'action': 'bypass'
            }
    else:
        send_message_to_sns(event)
        if (event_type == "EMR Step Status Change") and (state == "CANCELLED"):
            print "+ 'EMR Step Status Change -- ", state, "' detected! +"
        else:
            if (event_type == "EMR Cluster State Change") and ((state == "TERMINATED") or (state == "TERMINATED_WITH_ERRORS")):
                print "* 'EMR Cluster State Change -- ", state, "' detected! *"
                # Retrieve pipeline name from Environment Variable
                PIPELINE = os.environ['PIPELINE_RUNNING']
                print ">> Stop pipeline '" + PIPELINE + "' ..."

                commands = [
                    "pipelinectrl -n " + PIPELINE + " stop",
                    "aws lambda remove-permission --function-name Lambda_autopilot_event_handler_Vincent --statement-id events-access-autotest-AP"
                    ]
                #print commands
                exec_cmds_EC2_SSH('10.0.173.248', commands)

    print "-> [ ", event_type, " -- ", state, " (", name, ") ] (PassThrough)"
    return {
        'type': event_type,
        'name': name,
        'cluster_id': cluster_id,
        'state/status': state,
        'message': message
    }
