#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3DEV_iRPM.slib

get_token_iRPM_4_mrmt

HOSTURL="https://api.dev.ms.refinitiv.com/metadata-service/metadata-store/beta1/admin/domains"

#DOMAIN_SUBDOMAIN="metadatamigrationtest/test-res-schemav2"
DOMAIN_SUBDOMAIN="configuration/data-store"
echo ">> Create official '${DOMAIN_SUBDOMAIN}' ('sharedIdentityEnabled': true)"
retROOT_Res=$(curl -sS -X POST "${HOSTURL}/${DOMAIN_SUBDOMAIN}" -H 'Content-Type: application/json' -d '{"name":"/configuration/data-store","officialName":"/configuration/data-store","description":"The domain for data store configuration data models","maintainers":[],"sharedIdentityEnabled":true}' -H "Authorization: Bearer ${token}")
echo "$retROOT_Res"

sleep 2

#DOMAIN_SUBDOMAIN="metadatamigrationtest/test-obj-schemav2"
DOMAIN_SUBDOMAIN="physical/data-store"
echo ">> Create official '${DOMAIN_SUBDOMAIN}' ('sharedIdentityEnabled': true)"
retROOT_Obj=$(curl -sS -X POST "${HOSTURL}/${DOMAIN_SUBDOMAIN}" -H 'Content-Type: application/json' -d '{"name":"/configuration/data-store","officialName":"/configuration/data-store","description":"The domain for data store configuration data models","maintainers":[],"sharedIdentityEnabled":true}' -H "Authorization: Bearer ${token}")
echo "$retROOT_Obj"

sleep 2

#DOMAIN_SUBDOMAIN="metadatamigrationtest/test-des-schemav2"
DOMAIN_SUBDOMAIN="logical/data-store"
echo ">> Create official '${DOMAIN_SUBDOMAIN}' ('sharedIdentityEnabled': true)"
retROOT_Des=$(curl -sS -X POST "${HOSTURL}/${DOMAIN_SUBDOMAIN}" -H 'Content-Type: application/json' -d '{"name":"/configuration/data-store","officialName":"/configuration/data-store","description":"The domain for data store configuration data models","maintainers":[],"sharedIdentityEnabled":true}' -H "Authorization: Bearer ${token}")
echo "$retROOT_Des"

echo
