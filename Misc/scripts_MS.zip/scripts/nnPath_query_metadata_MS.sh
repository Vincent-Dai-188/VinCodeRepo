#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_PPE.slib

if (( $# < 1 )); then
    echo "Usage: $0 <nnPath> [-J] [-X] [-h]"
    exit 1
fi

naturalNamePath=$1
shift

JQPARSE="true"
expTreeNum=0
while getopts :hJX paras
do
    case "$paras" in
        J)  JQPARSE="false"
            ;;
        X)  expTreeNum=1
            ;;
        h)  echo "Usage: $0 <nnPath> [-J] [-X] [-h]"
            exit 0
            ;;
        *)  echo "Usage: $0 <nnPath> [-J] [-X] [-h]"
            exit 2
            ;;
    esac
done

get_token_ADM

QUERYPATH="https://metadata-service-ppe.ms-preprod.aws-int.refinitiv.com/metadata-store/beta1${naturalNamePath}"

if (( expTreeNum > 0)); then
    CMDSTR="curl -sS -X GET \"${QUERYPATH}\" -H \"Authorization: Bearer ${token}\" -H \"expandTree: ${expTreeNum}\""
else
    CMDSTR="curl -sS -X GET \"${QUERYPATH}\" -H \"Authorization: Bearer ${token}\""
fi

if [ "${JQPARSE}" = "true" ]; then
    eval "$CMDSTR" | jq '.'
else
    eval "$CMDSTR"
fi

