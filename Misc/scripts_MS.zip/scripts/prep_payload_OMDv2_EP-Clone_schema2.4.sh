#!/bin/bash

if (( $# < 2 )); then
    echo "Usage: $0 <schemaVersion> <DataIndex>"
    exit 1
fi

TARGETROOT="/data/vincent/MR/MigrationTool_MR2.0/scripts/payload_MS"
output_dir="/data/vincent/MR/MigrationTool_MR2.0/scripts/payload_MS/OMDv2_payload_4_POST"

schemaVER=$1
datIndex=$2

CSNM="EP-Clone"
sn=$datIndex

echo -e "\n------------------------------ $CSNM [$sn] ------------------------------"
#cd ${TARGETROOT}/export_${CSNM}
cd ${TARGETROOT}/EP-Clone_v1.2.20_PPE

for fn in $(ls 9-*${sn}.json); do

    printf "\n[%02d] PROCESS 'envelopes' for '%s'\n" $sn $fn
    envStr=$(jq '."layer2DomainRoot"."envelopes"[]' $fn 2>/dev/null)
    if [ -n "$envStr" ]; then
        echo "$envStr" > ${output_dir}/payload_OMDv2_${CSNM}_envelope_${sn}.json
    else
        echo "   *** No 'envelopes'. ***"
    fi

    printf "\n[%02d] PROCESS 'objectTypes' for '%s'\n" $sn $fn
    desStr=$(jq '."objectDescriptionRoot"."objectTypes"[]' $fn 2>/dev/null)
    if [ -n "$desStr" ]; then
        echo "$desStr" > ${output_dir}/payload_OMDv2_${CSNM}_description_${sn}.json
    else
        echo "   *** No 'objectType'. ***"
    fi

    printf "\n[%02d] PROCESS 'resourceUnits' for '%s'\n" $sn $fn
    resStr=$(jq '."resourceDomainRoot"."resourceUnits"[]' $fn 2>/dev/null)
    if [ -n "$resStr" ]; then
        echo "$resStr" > ${output_dir}/payload_OMDv2_${CSNM}_resUnit_${sn}.json
        sed -i -e "s/\${layer2Domain}/physical\/data-store/g;s/\${objectDescriptionDomain}/logical\/data-store/g" ${output_dir}/payload_OMDv2_${CSNM}_resUnit_${sn}.json
        sed -i -e "s/\${layer2DomainVersion}/${schemaVER}/g;s/\${objectDescriptionDomainVersion}/${schemaVER}/g;s/\${adminStatus}/Released/g" ${output_dir}/payload_OMDv2_${CSNM}_resUnit_${sn}.json
    else
        echo "   *** No 'resourceUnits'. ***"
    fi
done

echo
