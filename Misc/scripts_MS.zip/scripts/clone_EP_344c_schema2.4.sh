#!/bin/bash

EP_BASE="EP_base_v1.2.20_9-e0f073a9-bcf3-4b98-8da9-92dd7929344c_9-5b135d29-0708-4271-9eb2-830345c20376.json"
EPClone_DP="9-9a370f0e-3fcb-89b4-9ad8-439297dd29d"
EPClone_CV="9-92d531b5-8070-1724-2be9-302c543038d"
EPClone_OT="9-a78ad445-5f75-63b4-2ce9-f61d361d64d"

for ((i=1;i<=2;i++)); do
    tgtEP="./${EPClone_DP}${i}_${EPClone_CV}${i}.json"
    cp "${EP_BASE}" "${tgtEP}"
    sed -i -e "s/\"businessId\" : \"ecp:9-e0f073a9-bcf3-4b98-8da9-92dd7929344c\"/\"businessId\" : \"ecp:${EPClone_DP}${i}\"/g;s/\"name\" : \"Events_EP\"/\"name\" : \"Events_EP_V${i}\"/;s/\"mrVersionEcpId\" : \"ecp:9-5b135d29-0708-4271-9eb2-830345c20376\"/\"mrVersionEcpId\" : \"ecp:${EPClone_CV}${i}\"/g;s/\"businessId\" : \"ecp:9-544da87a-57f5-4b36-9ec2-641d63d16f8d\"/\"businessId\" : \"ecp:${EPClone_OT}${i}\"/g;s/\"name\" : \"EventsPlatform\"/\"name\" : \"EventsPlatform_V${i}\"/g" "${tgtEP}"
done
