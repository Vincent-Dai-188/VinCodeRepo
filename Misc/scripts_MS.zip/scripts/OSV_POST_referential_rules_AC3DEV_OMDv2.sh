#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3DEV_iRPM.slib

get_token_iRPM_4_mrmt

HOSTURL="https://api.dev.ms.refinitiv.com/metadata-service/metadata-store/beta1/validations/reference"

RULESROOTDIR="/data/vincent/MR/MigrationTool_MR2.0/schema_v2.4/referential_rules"

schemaVER="?schemaVersion=2.4.1-1"

echo -e "\n>> POST rules for ConfigurationDomain"
DOMAIN_SUBDOMAIN="configuration/data-store"
RULESDIR="${RULESROOTDIR}/ConfigurationDomain_rules"
cd ./ConfigurationDomain_rules
for payload in $(ls *.json); do
    RULENAME=$(echo "$payload" | sed 's/\.json//')
    echo "- POST '${RULENAME}' into '${DOMAIN_SUBDOMAIN}'"
    curl -sS -X POST "${HOSTURL}/${DOMAIN_SUBDOMAIN}/rules${schemaVER}" -H 'Content-Type: application/json' -H "Authorization: Bearer ${token}" -d @${payload}
    echo && sleep 1
done
sleep 1

cd ../Layer2Domain_rules
echo -e "\n>> POST rules for Layer2Domain"
DOMAIN_SUBDOMAIN="physical/data-store"
RULESDIR="${RULESROOTDIR}/Layer2Domain_rules"
for payload in $(ls *.json); do
    RULENAME=$(echo "$payload" | sed 's/\.json//')
    echo "- POST '${RULENAME}' into '${DOMAIN_SUBDOMAIN}'"
    curl -sS -X POST "${HOSTURL}/${DOMAIN_SUBDOMAIN}/rules${schemaVER}" -H 'Content-Type: application/json' -H "Authorization: Bearer ${token}" -d @${payload}
    echo && sleep 1
done
sleep 1

cd ../ObjectDescriptionDomain_rules
echo -e "\n>> POST rules for ObjectDescriptionDomain"
DOMAIN_SUBDOMAIN="logical/data-store"
RULESDIR="${RULESROOTDIR}/ObjectDescriptionDomain_rules"
for payload in $(ls *.json); do
    RULENAME=$(echo "$payload" | sed 's/\.json//')
    echo "- POST '${RULENAME}' into '${DOMAIN_SUBDOMAIN}'"
    curl -sS -X POST "${HOSTURL}/${DOMAIN_SUBDOMAIN}/rules${schemaVER}" -H 'Content-Type: application/json' -H "Authorization: Bearer ${token}" -d @${payload}
    echo && sleep 1
done

cd ..
