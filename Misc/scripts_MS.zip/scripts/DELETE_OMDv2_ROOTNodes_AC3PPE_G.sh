#!/bin/bash

SVER="2.4.4-1"
ADMSTA="-G"

echo "Do you wish to delete current ROOT nodes of adminStatus '${ADMSTA}' in schema version '$SVER' in official domains?"
select yn in "Yes" "No"; do
    case $yn in
        Yes ) break;;
        No ) exit 1;;
    esac
done

./OSV_OMDv2_del_ROOTnode_ros_AC3PPE_auto_common.sh $SVER -r $ADMSTA
sleep 1

./OSV_OMDv2_del_ROOTnode_ros_AC3PPE_auto_common.sh $SVER -s $ADMSTA
sleep 1

./OSV_OMDv2_del_ROOTnode_ros_AC3PPE_auto_common.sh $SVER -o $ADMSTA
