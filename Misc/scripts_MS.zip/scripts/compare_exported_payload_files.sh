#!/bin/bash

exp_dir_new='metadata-registry-migration-tool-1.1.198_EXPORT/'
exp_dir_pre='metadata-registry-migration-tool-1.1.198/'

cd ./${exp_dir_new}
export_dirs_list=$(find ./ -name "export_*" -type d)

for EXPDIR in ${export_dirs_list}; do
	echo "- ${EXPDIR}"
	if [ ! -d ../${exp_dir_pre}${EXPDIR} ]; then
		echo "  Not found directory '${exp_dir_pre}${EXPDIR}'! "
		continue
	else
		cd ./${EXPDIR}
		files_list=$(ls *.json)
		for FN in ${files_list}; do
			echo "  > $FN"
			if [ ! -f ../../${exp_dir_pre}${EXPDIR}/${FN} ]; then
				echo "    Not found file '${exp_dir_pre}${FN}'! "
				cd ..
				continue
			else
				diff ./${FN} ../../${exp_dir_pre}${EXPDIR}/${FN}
			fi
		done
		cd ..
	fi
done
