#!/bin/bash

function print_string_indent    #string
{
    dataStr=$1

    IndentStr="$(printf '%*s' $nIndent)"
    echo "${IndentStr}${dataStr}"
}

function close_json_array    #counter #upperlimit
{
    cnt=$1
    uplimit=$2

    IndentStr="$(printf '%*s' $nIndent)"
    if (( cnt < uplimit )); then
        echo "${IndentStr}],"
    else
        echo "${IndentStr}]"
    fi
}

function close_json_object    #counter #upperlimit
{
    cnt=$1
    uplimit=$2

    IndentStr="$(printf '%*s' $nIndent)"
    if (( cnt < uplimit )); then
        echo "${IndentStr}},"
    else
        echo "${IndentStr}}"
    fi
}

# Output all the properties (K,V) of an Element
# CloseOption: 'true' - don't output ',' at the end, 'false' - output ',' at the end
function print_pros     #Properties (K,V)  #CloseOption
{
    PropLines=$1
    OptClose=$2

    Len=$(echo "$PropLines" | wc -l)
    if [ "$OptClose" = "true" ]; then
        if (( Len == 1 )); then
            print_string_indent "$PropLines"
        else
            LastLine=$(echo "$PropLines" | tail -n 1)
            # Drop last line
            PropLines=$(echo "$PropLines" | sed '$d')
            echo "$PropLines" | while read LINE; do print_string_indent "${LINE},"; done
            print_string_indent "$LastLine"
        fi
    else
        echo "$PropLines" | while read LINE; do print_string_indent "${LINE},"; done
    fi
}

function print_refs     #References (K,V)
{
    RefLines=$1

    Len=$(echo "$RefLines" | wc -l)
    if (( Len == 1 )); then
        print_string_indent "{"
        print_string_indent "  $RefLines"
        print_string_indent "}"
    else
        LastLine=$(echo "$RefLines" | tail -n 1)
        # Drop last line
        RefLines=$(echo "$RefLines" | sed '$d')
        echo "$RefLines" | while read LINE; do print_string_indent "{" && print_string_indent "  $LINE" && print_string_indent "},"; done
        print_string_indent "{"
        print_string_indent "  $LastLine"
        print_string_indent "}"
    fi
}

function DS_traverse_by_nnPath    #nnPath
{
    naturalNamePath=$1

    local retObj
    # In order to get the real return code, local variable must be declared separately (above), otherwise return code will always be 0
    retObj=$(./nnPath_query_metadata_MS.sh "${naturalNamePath}" -X)
    if [ $? -ne 0 ]; then
        print_string_indent "$retObj"
        exit 2
    fi

    isObjSets=$(echo "$retObj" | jq -r '. | if type=="array" then "False" else "True" end')
    if [ "${isObjSets}" = "False" ]; then
        echo -e "\n*** Unexpected array structure is detected! Please check the nnPath your entered. ***"
        exit 1
    fi

    ecpid=$(echo "$retObj" | jq -r '."_links"."self"[0].href')
    print_string_indent "\"href\": \"${ecpid}\","
    print_string_indent "\"nnPath\": \"${naturalNamePath}\","
    # Get all the properties (K,V)
    # Here we use '-c' option to get the value of list returned in a compact format
    props=$(echo "$retObj" | jq -cj 'to_entries[] | select(.key!="_links") | select(.value|type!="array") | if .value|type=="string" then "\"",.key, "\": ", (.value|tojson), "\n" else "\"",.key, "\": ", .value, "\n" end')

    # Check if there is the "_references"[] in case 'expandTree: 1'
    REFarray=$(echo "$retObj" | jq -r '."_links" | to_entries[] | select(.key=="_references") | .key')

    # Get the all the arraies except "_links" ('expandTree: 1' only)
    subNodes=$(echo "$retObj" | jq -r 'to_entries[] | select(.key!="_links") | select(.value|type=="array") | .key')
    local NumNodes=$(echo "$subNodes" | wc -l)

    if [ -n "${REFarray}" ]; then
        print_pros "$props" "false"
        # Special process for ."_link"."_references", just display "href", "_meta.direction" & "_meta.definerSide", no further traversal required
        print_string_indent "\"_references\": [" && (( nIndent += DELTA ))
        # Use '\"$BASHVAR\"' pattern to reference bash variable in jq '' (single quotes)
        refs=$(echo "$retObj" | jq -cj '."_links".'\"_references\"[]' | to_entries[] | "\"", .key, "\": \"", .value.href, ",[", .value._meta.direction, "],", .value._meta.definerSide, "\"\n"')
        print_refs "$refs"
        (( nIndent -= DELTA ))
        if [ -n "$subNodes" ]; then
            print_string_indent "],"
        else
            print_string_indent "]"
        fi
    else
        if [ -n "$subNodes" ]; then
            # Output properties (CloseOption: 'false')
            print_pros "$props" "false"
        else
            # Output properties (CloseOption: 'true')
            print_pros "$props" "true"
        fi
    fi

    local sn=0
    # Main loop for the expandable object arraies (X1)
    for node in $subNodes; do
        (( sn += 1 ))
        print_string_indent "\"${node}\": [" && (( nIndent += DELTA ))
        local expObjArr=$(echo "$retObj" | jq -r ".\"${node}\"")
        local lenArr=$(echo "$expObjArr" | jq '. | length')

        local mIndex
        # Sub-loop for each object
        for (( mIndex=0; mIndex<lenArr; mIndex++ )); do
            local expObj=$(echo "$expObjArr" | jq ".[${mIndex}]")
            exp_ecpid=$(echo "$expObj" | jq -r '."_links"."self"[0].href')
            exp_nnPath=$(echo "$expObj" | jq -r '."_links"."self"[1].href')
            print_string_indent "{" && (( nIndent += DELTA ))
            print_string_indent "\"href\": \"${exp_ecpid}\","
            print_string_indent "\"nnPath\": \"${exp_nnPath}\","
            # Get all the properties (K,V) (Note: we use '-c' option here to get the value of list returned in a compact format)
            exp_props=$(echo "$expObj" | jq -cj 'to_entries[] | select(.key!="_links") | select(.value|type!="array") | if .value|type=="string" then "\"",.key, "\": ", (.value|tojson), "\n" else "\"",.key, "\": ", .value, "\n" end')

            # Get the expandable object arraies in ."_links" except "self" ('expandTree: 1' only)
            local exp_subNodes=$(echo "$expObj" | jq -r '."_links" | to_entries[] | select(.key!="self") | select(.value|type=="array") | .key')
            if [ -z "$exp_subNodes" ]; then
                # Output properties (CloseOption: 'true')
                print_pros "$exp_props" "true"
            else
                # Output properties (CloseOption: 'false')
                print_pros "$exp_props" "false"
                local exp_NumNodes=$(echo "$exp_subNodes" | wc -l)
            fi

            local exp_sn=0
            # Sub-Loop for the expandable object arraies (X0, href)
            for exp_node in $exp_subNodes; do
                (( exp_sn += 1 ))
                print_string_indent "\"${exp_node}\": [" && (( nIndent += DELTA ))
                local exp_nnPathSet=$(echo "$expObj" | jq -r ".\"_links\".\"${exp_node}\"[]? | .[1].href")
                local exp_NumNNPaths=$(echo "$exp_nnPathSet" | wc -l)
                local subIndex=0
                # Sub-sub-loop for the expandable object arraies (X0, href)
                for exp_nnPathItem in $exp_nnPathSet; do
                    (( subIndex += 1 ))
                    print_string_indent "{" && (( nIndent += DELTA ))
                    DS_traverse_by_nnPath "$exp_nnPathItem"
                    (( nIndent -= DELTA )) && close_json_object $subIndex $exp_NumNNPaths
                done
                # Close "[]" for the expandable object arraies in Sub-sub-loop (X0, href)
                (( nIndent -= DELTA )) && close_json_array $exp_sn $exp_NumNodes
            done
            # Close "{}" for expandable arraies in Sub-Loop (X0)
            (( nIndent -= DELTA )) && close_json_object ${mIndex}+1 $lenArr
        done
        # Close "[]" for expandable arraies in Main-Loop
        (( nIndent -= DELTA )) && close_json_array $sn $NumNodes
    done    # End of loop Main-Loop
}


UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 1 )); then
    echo "Usage: $UTILNAME <nnPath>"
    exit 1
fi

NNPATH=$1

DELTA=2

(( nIndent = DELTA ))

echo "{"
DS_traverse_by_nnPath ${NNPATH}
echo "}"

