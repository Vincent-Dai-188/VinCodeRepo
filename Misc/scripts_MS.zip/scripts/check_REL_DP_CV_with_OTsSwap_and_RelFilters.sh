#!/bin/bash

function display_help
{
    echo "Usage: $0 <DP,CV>"
}

function check_relationship_OT  #OTId  #OTCategory
{
    OTID=$1
    OTCAT=$2

    if [ "$OTCAT" = "from" ]; then
        OTstring="    - RelatedObjectType(from):"
    else
        OTstring="    - RelationObjectType(to):"
    fi

    case $OTID in
        "ecp:5-63196068-b053-4407-bb98-fa37229e541c") echo "${OTstring} ecp:5-63196068-b053-4407-bb98-fa37229e541c ==> ecp:5-815e46c4-7063-4646-be99-3419a41cc577 (REL_data_correction via OTsSwap)";;
        "ecp:9-45baca54-b759-4952-b846-1e3e4ab78d5d") echo "${OTstring} ecp:9-45baca54-b759-4952-b846-1e3e4ab78d5d ==> ecp:5-d4f24f15-cf05-4673-8253-ad52be1b4dda (REL_data_correction via OTsSwap)";;
        "ecp:5-fb658dca-3599-11e9-abf5-34e6d72057a6") echo "${OTstring} ecp:5-fb658dca-3599-11e9-abf5-34e6d72057a6 ==> ecp:9-beb73190-ea0c-43a8-86fd-0c5963f46932 (REL_data_correction via OTsSwap)";;
        "ecp:5-909eaefe-a976-46c3-9f33-cc831c206e3d") echo "${OTstring} ecp:5-909eaefe-a976-46c3-9f33-cc831c206e3d ==> ecp:9-26d43526-3840-417f-9c8a-284908091f28 (REL_data_correction via OTsSwap)";;
        "ecp:5-e7af7d38-2626-456f-9af2-b31e0354af5d") echo "${OTstring} ecp:5-e7af7d38-2626-456f-9af2-b31e0354af5d ==> ecp:9-7e6e31ad-c0d2-4759-9c60-1513e2e5afb0 (REL_data_correction via OTsSwap)";;
        "ecp:5-c97d8764-9df7-4a7d-86c3-532c57d1d80b") echo "${OTstring} ecp:5-c97d8764-9df7-4a7d-86c3-532c57d1d80b ==> ecp:9-26d43526-3840-417f-9c8a-284908091f28 (REL_data_correction via OTsSwap)";;
        "ecp:5-45f98e0e-2801-4713-820c-7fec1329f0d9") echo "${OTstring} ecp:5-45f98e0e-2801-4713-820c-7fec1329f0d9 ==> ecp:9-beb73190-ea0c-43a8-86fd-0c5963f46932 (REL_data_correction via OTsSwap)";;
        "ecp:5-59eca499-ec4f-4a2e-9936-de41d3a760b7") echo "${OTstring} ecp:5-59eca499-ec4f-4a2e-9936-de41d3a760b7 ==> ecp:9-4e45b1c8-c11e-4560-81d8-5be5dbc7c1e2 (REL_data_correction via OTsSwap)";;
        *) echo "${OTstring} $OTID";;
    esac

    return 0
}

function check_linked_DPs   #Side  #DP(s)
{
    if (( $# == 2 )); then
        Side=$1
        DPid=$2
        echo ${DPid}
        echo -n "        >> [Check in migration list(${Side})]: "
        check_in_FullDPCVlist $DPid
    else    # For multiple DPs, check (and mark) and remain the only one in current full migration list
        Side=$1
        shift
        DPS=$@
        idx=0
        DPStr=""
        for DPid in $DPS; do
            (( idx += 1 ))
            ret=$(grep $DPid "${FULLDPCVLIST}")
            if [ -n "$ret" ]; then
                DP_Valid=$DPid
                DPStr="${DPStr}[$idx] $DPid "
            else
                DPStr="${DPStr}[$idx] $DPid (X) "
            fi
        done
        echo ${DPStr}
        echo -n "        >> [Check in migration list(${Side})]: "
        check_in_FullDPCVlist $DP_Valid
    fi
}

function check_DPs_for_special_OTs   #OTID #Side
{
    OTID=$1
    Side=$2

    case $OTID in
        "ecp:5-815e46c4-7063-4646-be99-3419a41cc577") DPId_replacement="ecp:8-68916d3c-01c8-4658-8ab2-38e2a5c8aa19"
                                                      echo "${DPId_replacement} (REL_data_correction via patching)"
                                                      echo -n "        >> [Check in migration list(${Side})]: "
                                                      check_in_FullDPCVlist "${DPId_replacement}"
                                                      ;;
        "ecp:5-d4f24f15-cf05-4673-8253-ad52be1b4dda") DPId_replacement="ecp:9-ffcd1cb6-846d-4ca3-a304-437cb10bcb9a"
                                                      echo "${DPId_replacement} (REL_data_correction via patching)"
                                                      echo -n "        >> [Check in migration list(${Side})]: "
                                                      check_in_FullDPCVlist "${DPId_replacement}"
                                                      ;;
        "ecp:5-fb658dca-3599-11e9-abf5-34e6d72057a6") DPId_replacement="ecp:9-2b54b1e1-0369-4f8b-a19c-5a41019b16d1"
                                                      echo "${DPId_replacement} (REL_data_correction via OTsSwap)"
                                                      echo -n "        >> [Check in migration list(${Side})]: "
                                                      check_in_FullDPCVlist "${DPId_replacement}"
                                                      ;;
        "ecp:5-909eaefe-a976-46c3-9f33-cc831c206e3d") DPId_replacement="ecp:9-e0e7684a-0bdd-4617-b50a-75de7760108e"
                                                      echo "${DPId_replacement} (REL_data_correction via OTsSwap)"
                                                      echo -n "        >> [Check in migration list(${Side})]: "
                                                      check_in_FullDPCVlist "${DPId_replacement}"
                                                      ;;
        "ecp:5-e7af7d38-2626-456f-9af2-b31e0354af5d") DPId_replacement="ecp:9-a6ebbb2e-bf21-42a4-966d-9f9b577f0524"
                                                      echo "${DPId_replacement} (REL_data_correction via OTsSwap)"
                                                      echo -n "        >> [Check in migration list(${Side})]: "
                                                      check_in_FullDPCVlist "${DPId_replacement}"
                                                      ;;
        "ecp:5-c97d8764-9df7-4a7d-86c3-532c57d1d80b") DPId_replacement="ecp:9-e0e7684a-0bdd-4617-b50a-75de7760108e"
                                                      echo "${DPId_replacement} (REL_data_correction via OTsSwap)"
                                                      echo -n "        >> [Check in migration list(${Side})]: "
                                                      check_in_FullDPCVlist "${DPId_replacement}"
                                                      ;;
        "ecp:5-45f98e0e-2801-4713-820c-7fec1329f0d9") DPId_replacement="ecp:9-2b54b1e1-0369-4f8b-a19c-5a41019b16d1"
                                                      echo "${DPId_replacement} (REL_data_correction via OTsSwap)"
                                                      echo -n "        >> [Check in migration list(${Side})]: "
                                                      check_in_FullDPCVlist "${DPId_replacement}"
                                                      ;;
        "ecp:5-59eca499-ec4f-4a2e-9936-de41d3a760b7") DPId_replacement="ecp:9-e35194a6-15b0-48eb-ba8f-3c850bcb7f39"
                                                      echo "${DPId_replacement} (REL_data_correction via OTsSwap)"
                                                      echo -n "        >> [Check in migration list(${Side})]: "
                                                      check_in_FullDPCVlist "${DPId_replacement}"
                                                      ;;
        *) return 1;;
    esac

    return 0
}

function check_in_FullDPCVlist  #DPID
{
    DPID=$1

    ret=$(grep $DPID "${FULLDPCVLIST}")
    if [ -n "$ret" ]; then
        echo "$ret"
    else
        echo "None"
    fi
}

if (( $# < 1 )); then
    display_help
    exit 1
fi


#FULLDPCVLIST="/data/vincent/MR/MigrationTool_MR2.0/DP_CV_list_CSV/FullCSV_supplement/RCF_CIQM_plus_SMIC_GOR_migration_DPCV_254_PPE_sVER.csv"
FULLDPCVLIST="./Full_Migration_DPCVs_List.csv"
FILTERCFG="/data/vincent/MR/MigrationTool_MR2.0/filter_Rel_mrmt/Relationships_Filter_mrmt.csv"

fromOT=""
toOT=""

if [ ! -f "${FULLDPCVLIST}" ]; then
    echo "*** '${FULLDPCVLIST}' not found! ***"
    exit 2
fi

# ecp:8-a9a64900-23c6-4560-8988-41941e1fbabc,ecp:9-2c8ee5b6-d8af-40fa-b512-78d8053700f7,GovCorp,relationship
DPCVLINE=$1

DP_CV=$(echo ${DPCVLINE} | awk -F',' '{print $1" "$2}')
DP=$(echo ${DPCVLINE} | awk -F',' '{print $1}')
CV=$(echo ${DPCVLINE} | awk -F',' '{print $2}')
CSNAME=$(echo ${DPCVLINE} | awk -F',' '{print $3}')
WFilter=""

relFilter=$(grep "${DP},${CV}" "${FILTERCFG}")
if [ $? -eq 0 ]; then
    fromOT=$(echo "${relFilter}" | awk -F',' '{print $2}')
    toOT=$(echo "${relFilter}" | awk -F',' '{print $4}')
    WFilter="  w/Filter_Rel"
fi

if [ -n "${CSNAME}" ]; then
    echo "---------------------- DP/CV: ${DP},${CV}  <${CSNAME}>${WFilter} ----------------------"
else
    echo "---------------------- DP/CV: ${DP},${CV}${WFilter} ----------------------"
fi
StoreMapSet=$(./sparql_get_StoreMaps_by_DP-CV.sh ${DP_CV} | jq -r ".results.bindings[].map.value")
for StoreMapId in $StoreMapSet; do
    ret=$(./getThing $StoreMapId)
    if [ $? -eq 0 ] ; then
        PT=$(echo "$ret" | jq -r '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasPartition"."@id"')
        thing_PT=$(./getThing $PT)
        relatedObjID=$(echo ${thing_PT} | jq -jr '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasRelatedObjectType"."@id"')
        relationObjID=$(echo ${thing_PT} | jq -jr '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasRelationObjectType"."@id"')
        PTLabel=$(echo ${thing_PT} | jq -jr '."@graph"[0]."http://www.w3.org/2000/01/rdf-schema#label"')
        if [ -n "${fromOT}" ] && [ -n "${toOT}" ]; then
            if [ "${relatedObjID}" != "${fromOT}" ] || [ "${relationObjID}" != "${toOT}" ]; then
                continue
            fi
        fi
        echo "- StoreMap: $StoreMapId"
        echo "  - Partition: $PT (Label: \"$PTLabel\")"

        #echo "    - RelatedObjectType(from): $relatedObjID"
        check_relationship_OT $relatedObjID "from"
        echo -n "        - Linked_DP(from): "
        check_DPs_for_special_OTs $relatedObjID "from"
        if [ $? -ne 0 ]; then
            # Query linked DP(s) by OT via SparQL
            DP_Related=$(./ret_DP_by_OT_sparql.sh $relatedObjID | jq -r '."results"."bindings"[].sub | select(.type=="uri") | .value')
            if [ -n "${DP_Related}" ]; then
                check_linked_DPs "from" ${DP_Related}
            else
                echo "None"
            fi
        fi

        #echo "    - RelationObjectType(to): $relationObjID"
        check_relationship_OT $relationObjID "to"
        echo -n "        - Linked_DP(to): "
        check_DPs_for_special_OTs $relationObjID "to"
        if [ $? -ne 0 ]; then
            DP_Relation=$(./ret_DP_by_OT_sparql.sh $relationObjID | jq -r '."results"."bindings"[].sub | select(.type=="uri") | .value')
            if [ -n "${DP_Relation}" ]; then
                check_linked_DPs "to" ${DP_Relation}
            else
                echo "None"
            fi
        fi
    else
       echo "  - Partition: None"
    fi
done

echo
