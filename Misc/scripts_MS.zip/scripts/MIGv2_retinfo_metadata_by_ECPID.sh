#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_PPE.slib

if (( $# < 2 )); then
    echo "Usage: $0 <ECPID> <-r|-o|-s> [-X]"
    exit 1
fi

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

ECPID=$1
SDOPT=$2

EXOPT=""
if (( $# == 3 )); then
    EXOPT=$3
    if [ "$EXOPT" != "-X" ]; then
        echo "Usage: $0 <ECPID> <-r|-o|-s> [-X]"
        exit 1
    fi
fi

get_token_ADM

ret=$(${WORKDIR}/MIGv2_qids_metadata_PPE_ELB.sh ${ECPID} ${SDOPT} -T "${token}")
if [ $? -eq 0 ]; then
    naturalNamePath=$(echo "$ret" | jq -r '.[]."_links".self[1].href')

    if [ -n "${naturalNamePath}" ]; then
        # Due to Cross-Domain Reference (CDR), it is possible multiple naturalNamePaths might be returned for a ECPID. In this case,
        # use the first naturalNamePath to query metadata would be sufficient.
        Len=$(echo "${naturalNamePath}" | wc -l)
        if (( Len > 1 )); then
            naturalNamePath=$(echo "${naturalNamePath}" | head -n 1)
        fi

        if [ -n "$EXOPT" ]; then
            ret=$(curl -s -X GET "https://metadata-service-ppe.ms-preprod.aws-int.refinitiv.com/metadata-store/beta1${naturalNamePath}" -H "Authorization: Bearer ${token}" -H "expandTree: 1")
        else
            ret=$(curl -s -X GET "https://metadata-service-ppe.ms-preprod.aws-int.refinitiv.com/metadata-store/beta1${naturalNamePath}" -H "Authorization: Bearer ${token}")
        fi
        if [ $? -eq 0 ]; then
            echo "$ret" | jq '.'
        fi
    else
        echo "*** Failed to retrieve naturalNamePath by ECPID ***"
        exit 2
    fi
else
    echo "$ret"
    exit 2
fi

