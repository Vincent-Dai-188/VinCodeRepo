#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3DEV_iRPM.slib

get_token_iRPM_4_mrmt

HOSTURL="https://api.dev.ms.refinitiv.com/metadata-service/metadata-store/beta1/admin/domains"

DOMAIN_SUBDOMAIN="metadatamigrationtest/test-res-schemav2"
#DOMAIN_SUBDOMAIN="configuration/data-store"
echo ">> Delete '${DOMAIN_SUBDOMAIN}'"
retROOT_Res=$(curl -sS -X DELETE "${HOSTURL}/${DOMAIN_SUBDOMAIN}" -H 'Content-Type: application/json' -H "Authorization: Bearer ${token}")
echo "$retROOT_Res"

sleep 2

DOMAIN_SUBDOMAIN="metadatamigrationtest/test-obj-schemav2"
#DOMAIN_SUBDOMAIN="physical/data-store"
echo ">> Delete '${DOMAIN_SUBDOMAIN}'"
retROOT_Obj=$(curl -sS -X DELETE "${HOSTURL}/${DOMAIN_SUBDOMAIN}" -H 'Content-Type: application/json' -H "Authorization: Bearer ${token}")
echo "$retROOT_Obj"

sleep 2

DOMAIN_SUBDOMAIN="metadatamigrationtest/test-des-schemav2"
#DOMAIN_SUBDOMAIN="logical/data-store"
echo ">> Delete '${DOMAIN_SUBDOMAIN}'"
retROOT_Des=$(curl -sS -X DELETE "${HOSTURL}/${DOMAIN_SUBDOMAIN}" -H 'Content-Type: application/json' -H "Authorization: Bearer ${token}")
echo "$retROOT_Des"

echo
