#!/bin/bash

if (( $# != 1 )); then
    echo "Usage: $0 <console_log_file> or $0 <\"console_*.log\">"
    exit 1
fi

#echo "Params: $#"
FILE=$1

#echo -e "Console logs with problem:\n"
#grep -zPo "^\[\d\d\] .*$\n^real [0-9.]*$\n^user [0-9.]*$\n^sys [0-9.]*$\n^\[INFO\][^,]*, Problem DP_CV:[1-9] .*$" $FILE

grep -zPo "^\[.*$\n  >> .*$\n  Summary: [^,]*, Problem DP_CV:[1-9]" $FILE
