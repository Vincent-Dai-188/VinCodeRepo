#!/bin/bash

function display_help
{
    echo "Usage: $0 <DP_CV_list_file>"
}

if (( $# < 1 )); then
    display_help
    exit 1
fi

DPCVLISTFILE=$1

if [ ! -f "$DPCVLISTFILE" ]; then
    echo "'$DPCVLISTFILE' not found!"
    exit 2
fi

sn=0
while read LINE; do
    (( sn += 1))
    printf "[%03d] %s\n" $sn "$LINE"
    DPCV=$(echo "$LINE" | awk -F',' '{print $1","$2}')
    ./check_REL_DP_CV_with_OTsSwap_noRelFilters.sh "$DPCV"
done < $DPCVLISTFILE
