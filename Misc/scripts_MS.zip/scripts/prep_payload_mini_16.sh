#!/bin/bash

SOURCEDIR="../metadata-registry-migration-tool-2.0.14_DEVmain_Dec_schema2.4"

echo ">> Process OA5 ..."
SUBDIR="export_OA5"
mkdir -p ./${SUBDIR}/

cp ${SOURCEDIR}/${SUBDIR}/8-5ee26eae-10bb-4b9c-8510-befc126dc22a_9-202d90e7-75d0-4850-832e-6d5781f85921.json ./${SUBDIR}/
cp ${SOURCEDIR}/${SUBDIR}/8-68916d3c-01c8-4658-8ab2-38e2a5c8aa19_9-e8c37eb7-9154-4808-bda7-fd4978134b81.json ./${SUBDIR}/

echo ">> Process CMO ..."
SUBDIR="export_CMO"
mkdir -p ./${SUBDIR}/

cp ${SOURCEDIR}/${SUBDIR}/8-22f20aca-ed44-4499-8c53-e25fabbeb8e9_9-9811b95d-4c46-45a5-a6df-b5e781448135.json ./${SUBDIR}/
cp ${SOURCEDIR}/${SUBDIR}/8-70b52163-e439-406d-b997-c4fb73e9aa89_9-3b5a24c7-4c1b-485b-83ab-c69d7640a102.json ./${SUBDIR}/
cp ${SOURCEDIR}/${SUBDIR}/8-953ecb19-c1ee-45f8-9eb0-c155a5f44722_9-299f79bd-6e44-4bb9-9960-8fda9e954d3a.json ./${SUBDIR}/
cp ${SOURCEDIR}/${SUBDIR}/8-bb29997b-1078-451f-afe0-25c8eff46ee3_9-2ad8f8c9-f1f2-4cad-a770-4a19726b319e.json ./${SUBDIR}/
cp ${SOURCEDIR}/${SUBDIR}/8-c3cc9163-0534-47f5-9b29-298c0b095116_9-4c67d1eb-f08e-4f8b-960c-1e0d947bf4c3.json ./${SUBDIR}/

echo ">> Process CMO_Rel ..."
SUBDIR="export_CMO_Rel"
mkdir -p ./${SUBDIR}/

cp ${SOURCEDIR}/${SUBDIR}/8-71afde0c-1ae3-11e9-a2b4-34e6d72057a6_9-719bb94a-1ae3-11e9-97d8-34e6d72057a6.json ./${SUBDIR}/
cp ${SOURCEDIR}/${SUBDIR}/8-71d51a42-1ae3-11e9-a45f-34e6d72057a6_9-71c38d9e-1ae3-11e9-a222-34e6d72057a6.json ./${SUBDIR}/
cp ${SOURCEDIR}/${SUBDIR}/8-d1850c8a-195b-11e9-9487-34e6d72057a6_9-d17e07a8-195b-11e9-98f0-34e6d72057a6.json ./${SUBDIR}/
cp ${SOURCEDIR}/${SUBDIR}/8-d193164a-195b-11e9-be2f-34e6d72057a6_9-d18bc34a-195b-11e9-8dc6-34e6d72057a6.json ./${SUBDIR}/

echo ">> Process Municipal_Bonds ..."
SUBDIR="export_Municipal_Bonds"
mkdir -p ./${SUBDIR}/

cp ${SOURCEDIR}/${SUBDIR}/8-325d48d3-9188-4000-9239-9bdac8733751_9-a0a2b444-af78-4d8c-aff3-631755f1d3f0.json ./${SUBDIR}/

echo ">> Process GovCorp ..."
SUBDIR="export_GovCorp"
mkdir -p ./${SUBDIR}/

cp ${SOURCEDIR}/${SUBDIR}/8-8f49238b-f7b3-4bf7-83b2-04e8cac1f4c2_9-4960e03d-2478-4d0a-9a8d-bc5db1d5acee.json ./${SUBDIR}/

echo ">> Process GovCorp_Rel ..."
SUBDIR="export_GovCorp_Rel"
mkdir -p ./${SUBDIR}/

cp ${SOURCEDIR}/${SUBDIR}/8-72f0f1c6-1ae3-11e9-ad09-34e6d72057a6_9-72dea1cc-1ae3-11e9-945d-34e6d72057a6.json ./${SUBDIR}/

echo ">> Process ESG ..."
SUBDIR="export_ESG"
mkdir -p ./${SUBDIR}/
cp ${SOURCEDIR}/${SUBDIR}/8-c5fa5477-df9a-4906-9581-5cba5a6750cc_9-47b37843-d21f-427b-a701-c7ff630e705a.json ./${SUBDIR}/

echo ">> Process EP ..."
SUBDIR="export_EP"
mkdir -p ./${SUBDIR}/
cp ${SOURCEDIR}/${SUBDIR}/9-e0f073a9-bcf3-4b98-8da9-92dd7929344c_9-5b135d29-0708-4271-9eb2-830345c20376.json ./${SUBDIR}/
