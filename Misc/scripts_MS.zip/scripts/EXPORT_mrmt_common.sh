#!/bin/bash

if (( $# < 4 )); then
	echo "Usage: $0 <config.yml> <CSName> <DPId> <CVId>"
	exit 1
fi

CONFIG=$1
CSNM=$2
DPID=$3
CVID=$4

OUTDIR="../export_${CSNM}"

if [ ! -d "${OUTDIR}" ]; then
	mkdir -p "${OUTDIR}"
fi

./mrmt export --config="${CONFIG}" -cs "${CSNM}" -dp ${DPID} -cv ${CVID} -o "${OUTDIR}"