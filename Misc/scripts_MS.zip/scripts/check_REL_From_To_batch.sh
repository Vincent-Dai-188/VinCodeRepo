#!/bin/bash

function display_help
{
    echo "Usage: $0 <DP-CV_list_filename>"
}

function check_in_FullDPCVlist  #DPID
{
    DPID=$1

    ret=$(grep $DPID /data/vincent/MR/MigrationTool_MR2.0/DP_CV_list_CSV/FullCSV_supplement/contentSetsFullCSVFile_BIS_combined_2021-04.csv)
    if [ -n "$ret" ]; then
        echo "$ret"
    else
        echo "None"
    fi
}

if (( $# < 1 )); then
    display_help
    exit 1
fi

TARGETOTS="ecp:5-59eca499-ec4f-4a2e-9936-de41d3a760b7|ecp:5-c97d8764-9df7-4a7d-86c3-532c57d1d80b"

DPCV_LIST_FILE=$1

echo "---------------------------- ${DPCV_LIST_FILE} ----------------------------"

sn=0
while read LINE; do
    CSNAME=$(echo $LINE | awk -F',' '{print $3}')
    #DP_CV=$(echo $LINE | awk '{print $1}' | sed 's/,/ /')
	DP=$(echo $LINE | awk -F',' '{print $1}')
	CV=$(echo $LINE | awk -F',' '{print $2}')
    DP_CV="${DP} ${CV}"
    (( sn+=1 ))
    printf "\n[%02d] %s\n" $sn "${DP_CV}  <${CSNAME}>"
    StoreMap=$(./sparql_get_StoreMaps_by_DP-CV.sh ${DP_CV} | jq -r ".results.bindings[].map.value")
    for item in $StoreMap; do
        echo "- StoreMap: $item"
        ret=$(./getThing $item)
        if [ $? -eq 0 ] ; then
            echo -n "  - Partition: "
            PT=$(echo "$ret" | jq -r '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasPartition"."@id"')
            echo "$PT"
            thing_PT=$(./getThing $PT)

            relatedObjID=$(echo ${thing_PT} | jq -jr '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasRelatedObjectType"."@id"')
            echo $relatedObjID | egrep ${TARGETOTS} &>/dev/null
			if [ $? -eq 0 ]; then
				echo "    - RelatedObjectType(from): $relatedObjID  [!]"
			else
				echo "    - RelatedObjectType(from): $relatedObjID"
			fi

            relationObjID=$(echo ${thing_PT} | jq -jr '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasRelationObjectType"."@id"')
            echo $relationObjID | egrep ${TARGETOTS} &>/dev/null
			if [ $? -eq 0 ]; then
				echo "    - RelatedObjectType(to): $relationObjID  [!]"
			else
				echo "    - RelatedObjectType(to): $relationObjID"
			fi

        else
           echo "  - Partition: None"
        fi
    done
done < ${DPCV_LIST_FILE}
