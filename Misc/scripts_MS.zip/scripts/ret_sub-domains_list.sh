#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_PPE.slib

allOpt=""

if (( $# ==1 )); then
    OPT=$1
    if [ "${OPT}" = "ALL" ] || [ "${OPT}" = "All" ]; then
        allOpt="?allVersions=true"
    fi
fi

get_token_ADM

if [ -z "${allOpt}" ]; then
    curl -sS -X GET "https://metadata-service-ppe.ms-preprod.aws-int.refinitiv.com/metadata-store/beta1/storage/domains" -H "Authorization: Bearer ${token}" | jq '.ocs'
else
    curl -sS -X GET "https://metadata-service-ppe.ms-preprod.aws-int.refinitiv.com/metadata-store/beta1/storage/domains${allOpt}" -H "Authorization: Bearer ${token}" | jq '.ocs'
fi

