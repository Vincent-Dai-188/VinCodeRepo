#!/bin/bash

if (( $# < 3 )); then
    echo "Usage: $0 <SOURCE_PAYLOAD_MRMT> <CS_TAG> <SCHEMA_VER"
    exit 1
fi

#SOURCEROOT=$1
#SOURCEROOT="/data/vincent/MR/MigrationTool_MR2.0/${SOURCEROOT}"

SOURCEPAYLOAD=$1
CSTAG=$2
SVER=$3

ADMSTA="Released"

if [ ! -d ${SOURCEROOT} ]; then
    echo "*** Specified directory doesn't exist! ***"
    exit 2
fi

output_dir="/data/vincent/MR/MigrationTool_MR2.0/scripts/payload_MS/OMDv2_payload_per_SD"

if [ ! -d "${output_dir}" ]; then
    mkdir -p "${output_dir}"
fi

sn=0

fn="${SOURCEPAYLOAD}"

(( sn+=1 ))
printf "[%02d] %s\n" $sn $fn
echo ">> Process 'resourceUnits' ..."
jq '."resourceDomainRoot"."resourceUnits"[]' $fn > ${output_dir}/payload_OMDv2_${CSTAG}_resUnit.json
sed -i -e "s,\${layer2Domain},physical/data-store,g;s,\${objectDescriptionDomain},logical/data-store,g" ${output_dir}/payload_OMDv2_${CSTAG}_resUnit.json
sed -i -e "s/\${layer2DomainVersion}/${SVER}/g;s/\${objectDescriptionDomainVersion}/${SVER}/g" ${output_dir}/payload_OMDv2_${CSTAG}_resUnit.json
sed -i -e "s/\${adminStatus}/${ADMSTA}/g" ${output_dir}/payload_OMDv2_${CSTAG}_resUnit.json

echo ">> Process 'envelopes' ..."
envStr=$(jq '."layer2DomainRoot"."envelopes"[]' $fn 2>/dev/null)
if [ -n "$envStr" ]; then
	echo "$envStr" > ${output_dir}/payload_OMDv2_${CSTAG}_envelope.json

	echo ">> Process 'objectTypes' ..."
	desStr=$(jq '."objectDescriptionRoot"."objectTypes"[]' $fn 2>/dev/null)
	if [ -n "$desStr" ]; then
		echo "$desStr" > ${output_dir}/payload_OMDv2_${CSTAG}_objType.json
	else
		echo "   *** No '"objectTypes"'. ***"
	fi
else
	echo "   *** No 'envelopes'. ***"
	echo ">> Process 'relationshipTypes' ..."
	desStr=$(jq '."objectDescriptionRoot"."relationshipTypes"[]' $fn 2>/dev/null)
	if [ -n "$desStr" ]; then
		echo "$desStr" > ${output_dir}/payload_OMDv2_${CSTAG}_relType.json
		sed -i -e "s,\${objectDescriptionDomain},logical/data-store,g" ${output_dir}/payload_OMDv2_${CSTAG}_relType.json
	else
		echo "   *** No '""relationshipTypes""'. ***"
	fi
fi
