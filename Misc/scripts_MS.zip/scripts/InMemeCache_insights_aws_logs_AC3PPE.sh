#!/bin/bash

# Example1: ./InMemeCache_insights_aws_logs_AC3DEV.sh -S 1635494400 -E 1635498000
# Example2: ./InMemeCache_insights_aws_logs_AC3DEV.sh -S "2022-02-10T09:26:55.459+0000" -E "2022-02-10T09:33:15.824+0000"
# Example3: ./InMemeCache_insights_aws_logs_AC3DEV.sh -t "02-15T09:26" -d "09:33"
# Example4: ./InMemeCache_insights_aws_logs_AC3DEV.sh -D "-3 day" -L 1000

function usage_help
{
    echo "Usage: $0 <-t SATRT_TIME -d END_TIME | -S SATRT_TIME -E END_TIME | -D DELTA_TIME_EXPRESSION> [-gursw] [-L LIMITS] [-h]"
}

function pull_logs_by_queryID  #queryID
{
    queryID=$1
    cnt=0
    while (( cnt <= 5 )); do
        queryRet=$(aws logs --profile ${AWS_PROFILE} get-query-results --query-id $queryID)

        queryStatus=$(echo "$queryRet" | jq -r '.status')
        if [ "$queryStatus" = "Complete" ]; then
            results=$(echo "$queryRet" | jq -r '.results')
            #results=$(echo "$results" | sed 's/\[pool-[^]]*\] INFO  com\.refinitiv\.metadata\.services\.fullcache\.[^ ]* //g')
            if [ -z "$results" ]; then
                echo "Null"
            else
                # Convert json text string to json object via 'fromjson' built, and finally reverse the order of lines ("tac", "cat"'s inverse)
                echo "$results" | jq -rj '.[] | to_entries[] | select(.key == 0) | (.value.value|fromjson) | .timestamp, " ", .jobId, " ", .message, "\n"' | tac
            fi
            break
        else
            (( cnt += 1 ))
            echo ">> \"status\": $queryStatus"
            sleep 5
        fi
    done
}

if (( $# < 2 )); then
    usage_help
    exit 1
fi

#DELTATM samples: '-30 min', '-1 hour', '-3 day'
AWS_PROFILE="edp-imm-sdlc-preprod"
LOG_GROUP="/aws/ecs/a204121-metadata-service-writer-PreProduction"

LIMITS="100"
while getopts :hgurswt:d:S:E:D:L: paras
do
    case "$paras" in
        g)  [ -z "$KEYWORD" ] && KEYWORD="Get cache:" || KEYWORD="${KEYWORD}|Get cache:"
            ;;
        u)  [ -z "$KEYWORD" ] && KEYWORD="Update cache:|Clean cache and local file:|Clean local file caused by|Cache RemovalListener for" || KEYWORD="${KEYWORD}|Update cache:|Update cache:|Clean cache and local file:|Clean local file caused by|Cache RemovalListener for"
            ;;
        r)  [ -z "$KEYWORD" ] && KEYWORD="Record " || KEYWORD="${KEYWORD}|Record "
            ;;
        s)  [ -z "$KEYWORD" ] && KEYWORD="memoryCacheStatistics" || KEYWORD="${KEYWORD}|memoryCacheStatistics"
            ;;
        w)  [ -z "$KEYWORD" ] && KEYWORD="[Ww]armup " || KEYWORD="${KEYWORD}|[Ww]armup "
            ;;
        S)  START_TM=${OPTARG}
            ;;
        E)  END_TM=${OPTARG}
            ;;
        t)  tm=${OPTARG}
            echo "$tm" | grep "^[0-9]\{2\}-[0-9]\{2\}T[0-9]\{2\}:[0-9]\{2\}$" &> /dev/null
            if [ $? -eq 0 ]; then
                START_TM=$(date +"%Y-${tm}:00.000+0800")
            else
                START_TM=$(date +"%Y-%m-%dT${tm}:00.000+0800")
            fi
            ;;
        d)  tm=${OPTARG}
            echo "$tm" | grep "^[0-9]\{2\}-[0-9]\{2\}T[0-9]\{2\}:[0-9]\{2\}$" &> /dev/null
            if [ $? -eq 0 ]; then
                END_TM=$(date +"%Y-${tm}:00.000+0800")
            else
                END_TM=$(date +"%Y-%m-%dT${tm}:00.000+0800")
            fi
            ;;
        D)  DELTATM=${OPTARG}
            START_TM=$(date --date="${DELTATM}" +%s)
            END_TM=$(date +%s)
            ;;
        L)  LIMITS=${OPTARG}
            ;;
        h)  usage_help
            exit 0
            ;;
        *)  usage_help
            exit 2
            ;;
    esac
done

echo "${START_TM}" | grep "[0-9]\{10\}" &>/dev/null
if [ $? -ne 0 ]; then
    START_TM=$(date -d"${START_TM}" +%s)
fi

echo "${END_TM}" | grep "[0-9]\{10\}" &>/dev/null
if [ $? -ne 0 ]; then
    END_TM=$(date -d"${END_TM}" +%s)
fi

if [ -z "$KEYWORD" ]; then
    KEYWORD="(Get cache:|Record |Update cache:|Clean cache and local file:|Clean local file caused by|Cache RemovalListener for|memoryCacheStatistics)"
else
    KEYWORD="(${KEYWORD})"
fi

# Schedules a query of a log group using CloudWatch Logs Insights. You specify the log group and time range to query and the query string to use.
ret=$(aws logs start-query \
 --profile ${AWS_PROFILE} \
 --log-group-name ${LOG_GROUP} \
 --start-time ${START_TM} \
 --end-time ${END_TM} \
 --query-string 'fields @message | filter @message like /'"${KEYWORD}"'/ | limit '${LIMITS}'')

queryID=$(echo $ret | jq -r '.queryId')
echo ">> queryID: $queryID"

# Delayed 3 seconds for logs readiness
sleep 3

pull_logs_by_queryID $queryID
