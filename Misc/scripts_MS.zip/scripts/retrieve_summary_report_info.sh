#!/bin/bash

if (( $# < 1 )); then
	echo "Usage: $0 <LOGFILE>"
	exit 2
fi

LOGFILE=$1

echo -n "  Summary: "
tail -n 100 ${LOGFILE} | grep "^\[INFO\]: -* All DP_CV Process Done Total"

ERRS=$(egrep "\.exception\.|\[ERROR\]: OneToOne or OneToMany without Child Data Element" ${LOGFILE})
if [ -n "$ERRS" ]; then
    echo "$ERRS" | while read LINE; do
        errMsg=$(echo "$LINE" | grep -o "{[^}]*}}$")
        if [ -n "$errMsg" ]; then
            echo "$errMsg" | jq -r -j '"  - ", .error.message, "\n"'
        else
            show_errmsg "$LINE"
        fi
    done
fi
