#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 <-O|-T>"
    exit 1
fi

OptDomain=0
while getopts :hOT paras
do
    case "$paras" in
        O)  (( OptDomain += 1 ))
            ;;
        T)  (( OptDomain += 2 ))
            ;;
        h)  echo "Usage: $0 <-O|-T>"
            exit 1
            ;;
        *)  echo "Usage: $0 <-O|-T>"
            exit 2
            ;;
    esac
done

if (( OptDomain == 1 )) || (( OptDomain == 3 )); then
    echo ">> Trigger Cache Monitoring on Official Domains"
    ./shell_overwrite_POST_CDFTestObjTo_AC3DEV.sh -O -r
    sleep 1
    ./shell_overwrite_POST_CDFTestObjTo_AC3DEV.sh -O -b
    sleep 1
    ./shell_overwrite_POST_CDFTestObjTo_AC3DEV.sh -O -o

    sleep 2
fi

if (( OptDomain == 2 )) || (( OptDomain == 3 )); then
    echo ">> Trigger Cache Monitoring on Metadatamigrationtest Domain"
    ./shell_overwrite_POST_CDFTestObjTo_AC3DEV.sh -T -r
    sleep 1
    ./shell_overwrite_POST_CDFTestObjTo_AC3DEV.sh -T -b
    sleep 1
    ./shell_overwrite_POST_CDFTestObjTo_AC3DEV.sh -T -o
fi
