#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_PPE.slib

function display_help
{
    echo "Usage: $0 <-r|-o|-s> [-V <schemaVer>] [-J] [-X] [-h] [sub-Path]"
}


#WORKDIR=$(dirname $(readlink -f "$0"))

ADMINSTA="adminStatus=Migrated"
JQPARSE="true"
while getopts :hrosJXV: paras
do
    case "$paras" in
        r)  Entity_URL="resource/resourceUnits"
            ;;
        o)  Entity_URL="object/envelopes"
            ;;
        s)  Entity_URL="description/objectCollection"
            ;;
        V)  ADMINSTA="${ADMINSTA}&schemaVersion=${OPTARG}"
            ;;
        J)  JQPARSE="false"
            ;;
        X)  EXPANDTREE="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${Entity_URL}" ]; then
    display_help
    exit 2
fi

shift $((OPTIND-1))
if (( $# >= 1 )); then
    subPath=$1
    echo ${subPath} | grep -o "adminStatus=" &> /dev/null
    if [ $? -eq 0 ]; then
        Entity_URL="${Entity_URL}/${subPath}"
    else
        Entity_URL="${Entity_URL}/${subPath}?${ADMINSTA}"
    fi
else
    Entity_URL="${Entity_URL}?${ADMINSTA}"
fi

get_token_ADM

QUERYPATH="https://metadata-service-ppe.ms-preprod.aws-int.refinitiv.com/metadata-store/beta1/metadata/metadatamigrationtest/${Entity_URL}"

if [ "${EXPANDTREE}" = "true" ]; then
    CMDSTR="curl -s -X GET \"${QUERYPATH}\" -H \"Authorization: Bearer ${token}\" -H \"expandTree: 1\""
else
    CMDSTR="curl -s -X GET \"${QUERYPATH}\" -H \"Authorization: Bearer ${token}\""
fi

if [ "${JQPARSE}" = "true" ]; then
    eval "$CMDSTR" | jq .
else
    eval "$CMDSTR"
fi

