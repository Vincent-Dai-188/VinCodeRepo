#!/bin/bash

function display_help
{
    echo "Usage: $0 <DP-CV_list_filename>"
}

function check_known_OTs  #OTID
{
    OTID=$1

	case $OTID in
        "ecp:5-63196068-b053-4407-bb98-fa37229e541c") echo "None (Replaced by \"ecp:5-815e46c4-7063-4646-be99-3419a41cc577\" via patching)" ;;
        "ecp:5-815e46c4-7063-4646-be99-3419a41cc577") echo "ecp:8-68916d3c-01c8-4658-8ab2-38e2a5c8aa19" ;;
        "ecp:9-45baca54-b759-4952-b846-1e3e4ab78d5d") echo "None (Replaced by \"ecp:5-d4f24f15-cf05-4673-8253-ad52be1b4dda\" via patching)" ;;
        "ecp:5-d4f24f15-cf05-4673-8253-ad52be1b4dda") echo "ecp:9-ffcd1cb6-846d-4ca3-a304-437cb10bcb9a" ;;
		*) return 1;; 
    esac
	return 0
}

function check_in_FullDPCVlist  #DPID
{
    DPID=$1

    ret=$(grep $DPID /data/vincent/MR/MigrationTool_MR2.0/DP_CV_list_CSV/FullCSV_supplement/contentSetsFullCSVFile.csv)
    if [ -n "$ret" ]; then
        echo "$ret"
    else
        echo "None"
    fi
}

if (( $# < 1 )); then
    display_help
    exit 1
fi

DPCV_LIST_FILE=$1

echo "---------------------------- ${DPCV_LIST_FILE} ----------------------------"

sn=0
while read LINE; do
    DP=$(echo $LINE | awk -F',' '{print $1}')
    CV=$(echo $LINE | awk -F',' '{print $2}')
    CSNAME=$(echo $LINE | awk -F',' '{print $3}')

    (( sn+=1 ))
    printf "\n[%03d] %s\n" $sn "DP: ${DP}, CV: ${CV}  <${CSNAME}>"
    StoreMap=$(./sparql_get_StoreMaps_by_DP-CV.sh "${DP}" "${CV}" | jq -r ".results.bindings[].map.value")
    for item in $StoreMap; do
        echo "- StoreMap: $item"
        ret=$(./getThing $item)
        if [ $? -eq 0 ] ; then
            echo -n "  - Partition: "
            PT=$(echo "$ret" | jq -r '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasPartition"."@id"')
            echo "$PT"
            thing_PT=$(./getThing $PT)

            relatedObjID=$(echo ${thing_PT} | jq -jr '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasRelatedObjectType"."@id"')
            echo "    - RelatedObjectType(from): $relatedObjID"
            echo -n "        - Lined_DP(from): "
			retDPID=$(check_known_OTs $relatedObjID)
			if [ $? -eq 0 ]; then
				echo "${retDPID}"
				echo -n "        >> [Check in migration scope]: "
				check_in_FullDPCVlist $retDPID
			else
				DP_Related=$(./ret_DP_by_OT_sparql.sh $relatedObjID | jq -r '."results"."bindings"[].sub | select(.type=="uri") | .value')
				if [ -n "${DP_Related}" ]; then
					echo ${DP_Related}
					echo -n "        >> [Check in migration scope]: "
					check_in_FullDPCVlist $DP_Related
				else
					echo "None"
				fi
			fi

            relationObjID=$(echo ${thing_PT} | jq -jr '."@graph"[0]."https://graph.link/ecp/schema/CDF/hasRelationObjectType"."@id"')
            echo "    - RelationObjectType(to): $relationObjID"
            echo -n "        - Linked_DP(to): "
			retDPID=$(check_known_OTs $relationObjID)
			if [ $? -eq 0 ]; then
				echo "${retDPID}"
				echo -n "        >> [Check in migration scope]: "
				check_in_FullDPCVlist $retDPID
			else
				DP_Relation=$(./ret_DP_by_OT_sparql.sh $relationObjID | jq -r '."results"."bindings"[].sub | select(.type=="uri") | .value')
				if [ -n "${DP_Relation}" ]; then
					echo ${DP_Relation}
					echo -n "        >> [Check in migration scope]: "
					#check_in_migration_scope $relationObjID $DP_Relation
					check_in_FullDPCVlist $DP_Relation
				else
					echo "None"
				fi
			fi
        else
           echo "  - Partition: None"
        fi
    done
done < ${DPCV_LIST_FILE}
