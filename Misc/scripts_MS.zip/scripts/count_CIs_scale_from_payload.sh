#!/bin/bash

#PAYLOADFILE="9-e0f073a9-bcf3-4b98-8da9-92dd7929344c_9-5b135d29-0708-4271-9eb2-830345c20376.json"

if (( $# < 1 )); then
	echo "Usage: $0 <payload_file>"
	exit 2
fi

PAYLOADFILE=$1
CIPATHSFILE="./paths_CIs.txt"

#echo ">> Extract \"contentItems\" paths ..." 2>&1
jq -c '. | paths' "${PAYLOADFILE}" | grep '"contentItems"' > "${CIPATHSFILE}"

if [ -s "${CIPATHSFILE}" ]; then
	ARRLEN=$(tail -n 1 "${CIPATHSFILE}" | awk -F',' '{print $5}')

	if (( ARRLEN > 0 )); then
		for ((n=0;n<=${ARRLEN};n++)) ; do 
			echo -n "[$n]^"
			jq -j ".\"layer2DomainRoot\".\"envelopes\"[0].\"contentItems\"[${n}] | .\"name\", \"^\"" "${PAYLOADFILE}"
			grep "\"contentItems\",${n}," "${CIPATHSFILE}" | wc -l
		done
	else
		echo "*** \"contentItems\" array is empty! ***"
		exit 2
	fi
else
	echo "*** Failed to get \"contentItems\" paths file! ***"
	exit 1
fi
