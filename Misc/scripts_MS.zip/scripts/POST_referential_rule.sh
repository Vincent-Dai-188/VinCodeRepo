#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3DEV_iRPM.slib

get_token_iRPM_4_mrmt

HOSTURL="https://api.dev.ms.refinitiv.com/metadata-service/metadata-store/beta1/validations/reference"

RULESDIR="/data/vincent/MR/MigrationTool_MR2.0/schema_v2.4/v2.4_0"

DOMAIN_SUBDOMAIN="configuration/data-store"
PAYLOADFILE="${RULESDIR}/ConfigurationDomain_referential-rules.json"
echo ">> POST referential validation rule into '${DOMAIN_SUBDOMAIN}' with payload file '${PAYLOADFILE}'"
curl -sS -X POST "${HOSTURL}/${DOMAIN_SUBDOMAIN}/rules" -H 'Content-Type: application/json' -H "Authorization: Bearer ${token}" -d @${PAYLOADFILE}

sleep 2

DOMAIN_SUBDOMAIN="physical/data-store"
PAYLOADFILE="${RULESDIR}/Layer2Domain_referential-rules.json"
echo ">> POST referential validation rule into '${DOMAIN_SUBDOMAIN}' with payload file '${PAYLOADFILE}'"
curl -sS -X POST "${HOSTURL}/${DOMAIN_SUBDOMAIN}/rules" -H 'Content-Type: application/json' -H "Authorization: Bearer ${token}" -d @${PAYLOADFILE}

sleep 2

DOMAIN_SUBDOMAIN="logical/data-store"
PAYLOADFILE="${RULESDIR}/ObjectDescriptionDomain_referential-rules.json"
echo ">> POST referential validation rule into '${DOMAIN_SUBDOMAIN}' with payload file '${PAYLOADFILE}'"
curl -sS -X POST "${HOSTURL}/${DOMAIN_SUBDOMAIN}/rules" -H 'Content-Type: application/json' -H "Authorization: Bearer ${token}" -d @${PAYLOADFILE}
