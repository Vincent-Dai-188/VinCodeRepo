#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3QA_iRPM.slib

get_token_iRPM_4_mrmt

echo "$token"
