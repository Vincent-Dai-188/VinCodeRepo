#curl -sS -L -X POST 'https://server.ecp-registry.refinitiv.com/auth' \
curl -sS -L -X POST 'http://a204121prodnlb-4022dbd1c36b7713.elb.us-east-1.amazonaws.com/auth' \
-H 'Key: mrteam' \
-H 'SecretKey: JUCn<M(.U/9PeEbH' \
-H 'x-api-key: mZ4LUT13jR1NdLCErI8es1iX6zowgxOfaMjdxTND'

