curl -sS -L -X POST 'https://server.dev.ecp-registry.refinitiv.com/auth' \
-H 'Key: EDGUser' \
-H 'SecretKey: Su_EDG_R1@2022' \
-H 'x-api-key: pVw5gWw9d48wKssfe7PV41O61b7SsHDk9AjYQqFA'
