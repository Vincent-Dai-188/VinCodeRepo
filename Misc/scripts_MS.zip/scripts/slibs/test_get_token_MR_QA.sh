curl -sS -L -X POST 'https://server.qa.ecp-registry.refinitiv.com/auth' \
-H 'Key: u6064334' \
-H 'SecretKey: M$FFXR_tH8b?Y~9!' \
-H 'x-api-key: pVw5gWw9d48wKssfe7PV41O61b7SsHDk9AjYQqFA'
