#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_DEVQA_iRPM.slib

get_token_iRPM_4_mrmt

echo "$token"
