#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_iRPM.slib

get_token_iRPM

echo "$token"
