#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AAA_AC3Prod.slib

get_token_AAA_AC3PROD

echo "$token"
