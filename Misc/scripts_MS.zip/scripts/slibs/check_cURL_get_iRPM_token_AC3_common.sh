#!/bin/bash

function display_help
{
    echo "Usage: $0 <-E <DEV|QA|PPE|Prod>> [-h]"
}

if (( $# < 2 )); then
    display_help
    exit 1
fi

HOSTURL=""
while getopts :hE: paras
do
    case "$paras" in
        E)  ENV=${OPTARG}
            if [ "${ENV}" = "QA" ]; then
                HOSTURL="https://api.qa.ms.refinitiv.com"
            elif [ "${ENV}" = "DEV" ]; then
                HOSTURL="https://api.dev.ms.refinitiv.com"
            elif [ "${ENV}" = "PPE" ]; then
                HOSTURL="https://api.ppe.ms.refinitiv.com"
            elif [ "${ENV}" = "Prod" ]; then
                HOSTURL="https://api.ms.refinitiv.com"
            fi
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -n "${HOSTURL}" ]; then
    curl -sS -X POST "${HOSTURL}/metadata-service/metadata-store/beta1/admin/token" -H 'accessId: GENTC-1070634'
else
    display_help
    exit 2
fi

