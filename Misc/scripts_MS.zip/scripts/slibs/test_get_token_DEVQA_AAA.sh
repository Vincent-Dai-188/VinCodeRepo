#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_DEVQA_AAA.slib

get_token_DEVQA_AAA

echo "$token"
