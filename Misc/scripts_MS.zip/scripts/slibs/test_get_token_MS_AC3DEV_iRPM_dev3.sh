#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3DEV_iRPM_dev3.slib

get_token_iRPM_4_mrmt

echo "$token"
