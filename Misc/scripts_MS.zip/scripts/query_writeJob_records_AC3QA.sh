#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3QA_iRPM.slib

if (( $# < 2 )); then
    echo "Usage: $0 <DOMAIN> <SUBDOMAIN> [MAXSIZE]"
    exit 2
fi

DOMAIN=$1
SUBDOMAIN=$2

MAXSIZE=9
if (( $# == 3 )); then
    MAXSIZE=$3
fi

get_token_iRPM_4_mrmt

QUERYURL="https://api.qa.ms.refinitiv.com/metadata-service/metadata-store/beta1/metadata-writes/${DOMAIN}/${SUBDOMAIN}/production/status?size=${MAXSIZE}"

curl -sS -X GET "${QUERYURL}" -H "Authorization: Bearer ${token}" | jq .
