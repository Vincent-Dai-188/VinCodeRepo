#!/bin/bash

SVER="2.4.3-1"

echo "Do you wish to delete current ROOT nodes of schema version '$SVER' in official domains and re-create it?"
select yn in "Yes" "No"; do
    case $yn in
        Yes ) break;;
        No ) exit 1;;
    esac
done

./OSV_OMDv2_del_ROOTnode_ros_AC3DEV_auto_Created.sh $SVER -r
sleep 1

./OSV_OMDv2_del_ROOTnode_ros_AC3DEV_auto_Created.sh $SVER -s
sleep 1

./OSV_OMDv2_del_ROOTnode_ros_AC3DEV_auto_Created.sh $SVER -o
sleep 1

./Create_ROOT_nodes_and_check_status_OMDv2_AC3DEV_Created.sh
