#!/bin/bash

for DIR in $(ls | grep "export_[^_]*$"); do
	cd ./${DIR}
    for FN in $(ls *.json); do
		echo -n ">> ${DIR}/${FN}    "
		grep '"isCollectionOf"' ${FN} | wc -l
	done
	cd ..
done
