#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3DEV_iRPM.slib

function display_help
{
    echo "Usage: $0 <-O|-T|-P> <-r|-o|-b> [-h]"
}

if (( $# < 2 )); then
    display_help
    exit 1
fi

payload_obj="CDFTest_envelope_To.json"
payload_des="CDFTest_objectType_To.json"

while getopts :hOTProb paras
do
    case "$paras" in
        O)  DSD_res="configuration/data-store"
            DSD_obj="physical/data-store"
            DSD_des="logical/data-store"
            payload_res="CDFTest_resUnit_CdfSdkObjTo_OMDv2.json"
            ;;
        T)  DSD_res="metadatamigrationtest/test-res-schemav2"
            DSD_obj="metadatamigrationtest/test-obj-schemav2"
            DSD_des="metadatamigrationtest/test-des-schemav2"
            payload_res="CDFTest_resUnit_CdfSdkObjTo_TSSv2.json"
            ;;
        P)  DSD_res="playground/resource"
            DSD_obj="playground/object"
            DSD_des="playground/description"
            payload_res="CDFTest_resUnit_CdfSdkObjTo_PLGv2.json"
            ;;
        r)  subRootPath="${DSD_res}/resourceUnits/CdfSdkObjTo"
            PAYLOADFILE="$payload_res"
            ;;
        o)  subRootPath="${DSD_obj}/envelopes/To"
            PAYLOADFILE="$payload_obj"
            ;;
        b)  subRootPath="${DSD_des}/objectTypes/To"
            PAYLOADFILE="$payload_des"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

get_token_iRPM_4_mrmt

HOSTURL="https://api.dev.ms.refinitiv.com/metadata-service/metadata-store/beta1/metadata"
RELEASEDSTA="?overwrite=true&adminStatus=Released"

echo ">> POST (overwrite) '${subRootPath}' with payload file '${PAYLOADFILE}'"
#echo "curl -sS -X POST '${HOSTURL}/${subRootPath}${RELEASEDSTA}'"
retMsg=$(curl -sS -X POST "${HOSTURL}/${subRootPath}${RELEASEDSTA}" -H 'Content-Type: application/json' -H 'User-Provided-Id: true' -H "Authorization: Bearer ${token}" -d @${PAYLOADFILE})

echo $retMsg
