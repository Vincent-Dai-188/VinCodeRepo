#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3PPE_iRPM.slib

function display_help
{
    echo "Usage: $0 <-r|-o|-s|-b> [-H] [-M] [-J] [-h] [target]"
}

#WORKDIR=$(dirname $(readlink -f "$0"))
ADMINSTA="adminStatus=Released"

JQPARSE="true"
NOHATEOASOPT="flase"
NOMETAOPT="false"
HEADEROPTS=""
while getopts :hrosbHMJV: paras
do
    case "$paras" in
        r)  DOMAIN_Entity_URL="configuration/data-store/resourceUnits"
            ;;
        o)  DOMAIN_Entity_URL="physical/data-store/envelopes"
            ;;
        s)  DOMAIN_Entity_URL="logical/data-store/relationshipTypes"
            ;;
        b)  DOMAIN_Entity_URL="logical/data-store/objectTypes"
            ;;
        V)  ADMINSTA="${ADMINSTA}&schemaVersion=${OPTARG}"
            ;;
        J)  JQPARSE="false"
            ;;
        H)  NOHATEOASOPT="true"
            ;;
        M)  NOMETAOPT="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${DOMAIN_Entity_URL}" ]; then
    display_help
    exit 2
fi

shift $((OPTIND-1))
if (( $# >= 1 )); then
    targetObj=$1
    DOMAIN_Entity_URL="${DOMAIN_Entity_URL}/${targetObj}?${ADMINSTA}"
else
    DOMAIN_Entity_URL="${DOMAIN_Entity_URL}?${ADMINSTA}"
fi

get_token_iRPM_4_mrmt

if [ "${NOHATEOASOPT}" = "true" ]; then
    HEADEROPTS="${HEADEROPTS}-H 'No-HATEOAS-Links: true' "
fi
if [ "${NOMETAOPT}" = "true" ]; then
    HEADEROPTS="${HEADEROPTS}-H 'No-Meta-Info: true' "
fi

QUERYPATH="https://api.ppe.ms.refinitiv.com/metadata-service/metadata-store/beta1/metadata-snapshots/${DOMAIN_Entity_URL}"

CMDSTR="curl -w \"\nStatus_Code: %{http_code}\n\" -s -X POST \"${QUERYPATH}\" -H 'Accept: application/json' -H \"Authorization: Bearer ${token}\" ${HEADEROPTS}"

ret=$(eval "$CMDSTR")

StatusStr=$(echo "$ret" | tail -n 1)
if [ "$StatusStr" != "Status_Code: 202" ]; then
    echo "DUMP snapshot failed!"
	echo "$StatusStr"
	echo "$ret"
else
	resBody=$(echo "${ret}" | sed '$d')
	echo "$resBody" | jq '.'
fi
