#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3PPE_iRPM.slib

if (( $# < 1 )); then
    echo "Usage: $0 <nnPath> [-J] [-X] [-H] [-M] [-h]"
    exit 1
fi

naturalNamePath=$1
shift

JQPARSE="true"
HEADEROPTS=""
expTreeNum=0
while getopts :hJXHM paras
do
    case "$paras" in
        J)  JQPARSE="false"
            ;;
        X)  expTreeNum=1
            ;;
        H)  NOHATEOASOPT="true"
            ;;
        M)  NOMETAOPT="true"
            ;;
        h)  echo "Usage: $0 <nnPath> [-J] [-X] [-H] [-M] [-h]"
            exit 0
            ;;
        *)  echo "Usage: $0 <nnPath> [-J] [-X] [-H] [-M] [-h]"
            exit 2
            ;;
    esac
done

echo "$naturalNamePath" | grep "^/metadata/" &> /dev/null
if [ $? -ne 0 ]; then
    naturalNamePath="/metadata${naturalNamePath}"
fi

if [ "${NOHATEOASOPT}" = "true" ]; then
    HEADEROPTS="${HEADEROPTS}-H 'No-HATEOAS-Links: true' "
fi
if [ "${NOMETAOPT}" = "true" ]; then
    HEADEROPTS="${HEADEROPTS}-H 'No-Meta-Info: true' "
fi

get_token_iRPM_4_mrmt

QUERYPATH="https://api.ppe.ms.refinitiv.com/metadata-service/metadata-store/beta1${naturalNamePath}"

if (( expTreeNum > 0)); then
    CMDSTR="curl -sS -X GET \"${QUERYPATH}\" -H \"Authorization: Bearer ${token}\" -H \"expandTree: ${expTreeNum}\" ${HEADEROPTS}"
else
    CMDSTR="curl -sS -X GET \"${QUERYPATH}\" -H \"Authorization: Bearer ${token}\" ${HEADEROPTS}"
fi

if [ "${JQPARSE}" = "true" ]; then
    eval "$CMDSTR" | jq .
else
    eval "$CMDSTR"
fi
