#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 <jobLOC_csv_File>"
    exit 2
fi

JOBLOCFILE=$1		# content: DPId,jobLocation

sn=0
while read LINE; do
    (( sn += 1 ))
    printf "\n[%02d] %s\n" $sn $LINE
    jobLOC=$(echo $LINE | awk -F',' '{print $2}')
    ./get_write_status_AC3QA.sh $jobLOC | jq '."payload" | ."naturalNames"[0], ."startTime", ."stopTime", . "status"'
done < $JOBLOCFILE
