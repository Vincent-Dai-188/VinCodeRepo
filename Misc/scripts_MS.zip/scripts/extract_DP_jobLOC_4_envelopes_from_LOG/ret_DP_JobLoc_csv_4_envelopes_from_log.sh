#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 <Log_File>"
    exit 2
fi

LOGFILE=$1

echo ">> Gen 'ABS_Import_Envelopes_Post_Status.tmp'"
egrep "Import Envelope|Post Status:AsyncResponse" $LOGFILE | grep -zPo "\[INFO\]: Import Envelope for DP\([^)]*\)\n\[INFO\]: Post Status:AsyncResponse.*" > ABS_Import_Envelopes_Post_Status.tmp

echo ">> Gen 'EP_DP_JobLoc.csv'"
egrep -o "Import Envelope for DP\([^)]*\)|location=[^,]*" ABS_Import_Envelopes_Post_Status.tmp | sed -z -e 's/Import Envelope for DP(//g;s/)\n/,/g;s/location=//g' > EP_DP_JobLoc.csv

rm -f ABS_Import_Envelopes_Post_Status.tmp
