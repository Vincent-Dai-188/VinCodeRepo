#!/bin/bash

function Check_Names_in_Array_via_Regex    #LOOPNUM
{
    LOOPNUM=$1
    for ((i=0;i<LOOPNUM;i++)); do
        # Check each name in array
        echo "${RETNAMEARR[i]}" | grep '^"[a-zA-Z0-9]\w\{0,62\}"$' &>/dev/null
        if [ $? -ne 0 ]; then
            # Convert query path for ."name" ("${ARRAY[i]}") to corresponding path for ."_meta"."businessId" & ."oldLabel"
            #idPath=$(echo "${ARRAY[i]}" | sed 's/name/id/')
            idPath=$(echo "${ARRAY[i]}" | sed 's/name/_meta/')
            labelPath=$(echo "${ARRAY[i]}" | sed 's/name/oldLabel/')
            ret_id_label=$(echo "$fileContent" | jq "${idPath}.businessId, ${labelPath}")
            ecpid=$(echo ${ret_id_label} | awk '{print $1}')
            oldLabel=$(echo ${ret_id_label} | sed "s/${ecpid} //')
            #echo "  - ecpid, name(MS), oldLabel: $ecpid, ${RETNAMEARR[i]}, $oldLabel  (!!! invalid_name !!!)"
            echo "  $ecpid, ${RETNAMEARR[i]}, $oldLabel"
        fi
    done
}

if (( $# < 1 )); then
    echo "Usage: $0 <payload_file_name> [Number_of Paths_in_Each_Batch]"
fi

NUMINBATCH=10

FILENAME=$1
if (( $# == 2 )); then
    NUMINBATCH=$2
fi

# ./9-4eceea1b-3d97-451f-9d49-8c912c2d157b_9-97a6cd27-4c8c-4821-980f-d4ed23cf42c4.json

fileContent=$(cat "${FILENAME}")

# Retrieve all paths to ."oldLabel"
rawLabelPaths=$(echo "$fileContent" | jq -c 'paths | select(.[-1] == "oldLabel")')
# Convert raw paths to jq format and drop the "oldLabel" at the end of each path
basePaths=$(echo "$rawLabelPaths" | sed -e "s/^\[/./;s/\",\"/\".\"/g;s/,\([0-9]*\),/[\1]./g;s/\"oldLabel\"\]//g")

ARRAY=()
RETNAMEARR=()

echo "businessId, name(MS), oldLabel"

sn=0
batchCounts=0
for basePath in $basePaths; do
    (( sn += 1 ))
    # Generate name paths and save them in array
    ARRAY+=("${basePath}\"name\"")
    if (( sn == NUMINBATCH )); then
        # Composite all these name paths together for jq
        JQPARAS="${ARRAY[0]}"
        for ((i=1;i<NUMINBATCH;i++)); do
            JQPARAS="${JQPARAS}, ${ARRAY[$i]}"
        done
        # Retrieve all the names via jq and save them in array
        retNames=$(echo "$fileContent" | jq "$JQPARAS")
        for nameItem in $retNames; do
            RETNAMEARR+=("$nameItem")
        done
        (( batchCounts += 1 ))
        #printf "[%03d]  " $batchCounts
        #echo "${RETNAMEARR[@]}"
        Check_Names_in_Array_via_Regex $NUMINBATCH
        sn=0
        unset ARRAY
        unset RETNAMEARR
    fi
done

# Process left name paths (if exists) that the count number is less than STPES
if (( sn > 0 )); then
    JQPARAS="${ARRAY[0]}"
    for ((i=1;i<sn;i++)); do
        JQPARAS="${JQPARAS}, ${ARRAY[$i]}"
    done
    ret=$(echo "$fileContent" | jq "$JQPARAS")
    for item in $ret; do
        RETNAMEARR+=("$item")
    done
    (( batchCounts += 1 ))
    #printf "[%03d]  " $batchCounts
    #echo "${RETNAMEARR[@]}"
    Check_Names_in_Array_via_Regex $sn
fi

echo "$FILENAME" | grep -o "export_.*_Rel/" &>/dev/null
if [ $? -eq 0 ]; then
    echo ">> Check relationshipInstanceNames"
    relInsNames=$(echo "$fileContent" | jq '."objectDescriptionRoot"."relationshipTypes"[0]."relationshipInstances"[]."name"')
    idx=0
    for insName in $relInsNames; do
        (( idx =+ 1 ))
        echo $insName | grep '^"[a-zA-Z0-9]\w\{0,62\}"$' &>/dev/null
        if [ $? -ne 0 ]; then
            echo "  - relationshipInstanceName[${idx}](MS): $insName  (!!! invalid_name !!!)"
        fi
    done
fi
