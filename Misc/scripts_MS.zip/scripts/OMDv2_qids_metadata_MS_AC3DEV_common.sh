#!/bin/bash

function display_help
{
    echo "Usage: $0 <ECPID> <-r|-o|-s> [-C|-G|-R] [-V <schemaVer>] [-J] [-h]"
}

. /data/vincent/slibs/fetch_token_MS_AC3DEV_iRPM.slib

if (( $# < 2 )); then
    display_help
    exit 2
fi

ECPID=$1
shift 1

ADMINSTA="adminStatus=Released"
JQPARSE="true"
while getopts :hrosCGRJV: paras
do
    case "$paras" in
        r)  DOMAIN_Entity_URL="configuration/data-store"
            ;;
        o)  DOMAIN_Entity_URL="physical/data-store"
            ;;
        s)  DOMAIN_Entity_URL="logical/data-store"
            ;;
        V)  schemaVer=${OPTARG}
            ;;
        C)  ADMINSTA="adminStatus=Created"
            ;;
        G)  ADMINSTA="adminStatus=Registered"
            ;;
        R)  ADMINSTA="adminStatus=Released"
            ;;
        J)  JQPARSE="false"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -n "$schemaVer" ]; then
	ADMINSTA="${ADMINSTA}&schemaVersion=${schemaVer}"
fi

if [ -n "${DOMAIN_Entity_URL}" ]; then
    DOMAIN_Entity_URL="${DOMAIN_Entity_URL}/${ECPID}"
else
    display_help
    exit 2
fi

get_token_iRPM_4_mrmt

res=$(curl -s -X GET "https://api.dev.ms.refinitiv.com/metadata-service/metadata-store/beta1/metadata-ids/${DOMAIN_Entity_URL}?${ADMINSTA}" -H "Authorization: Bearer ${token}")

err=$(echo "$res" | jq '.error? | .')
if [ -n "$err" ]; then
    echo "$err" | jq '.'
    exit 1
fi

if [ "${JQPARSE}" = "true" ]; then
    echo "$res" | jq '.'
else
    echo "$res"
fi
