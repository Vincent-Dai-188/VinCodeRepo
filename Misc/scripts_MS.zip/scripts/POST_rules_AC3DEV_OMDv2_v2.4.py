#!/usr/bin/python

import requests
import sys
import json

sys.path.append('/data/vincent/pylibs')
from fetch_token_MS_AC3DEV_iRPM import *

from urllib3.exceptions import InsecureRequestWarning

# Suppress only the single warning from urllib3 needed.
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

HOSTURL = "https://api.qa.ms.refinitiv.com/metadata-service/metadata-store/beta1/validations/reference"
#DsD_Res = "metadatamigrationtest/test-res-schemav2"
#DsD_Obj = "metadatamigrationtest/test-obj-schemav2"
#DsD_Des = "metadatamigrationtest/test-des-schemav2"
DsD_Res = "configuration/data-store"
DsD_Obj = "physical/data-store"
DsD_Des = "logical/data-store"

DIR_SCHEMA = "/data/vincent/MR/MigrationTool_MR2.0/schema_v2.4/v2.4_0"
SFILE_Res = "ConfigurationDomain_referential-rules.json"
SFILE_Obj = "Layer2Domain_referential-rules.json"
SFILE_Des = "ObjectDescriptionDomain_referential-rules.json"

TOKEN = get_token_iRPM_4_mrmt()

''' POST schema '''
#headers = {'Content-Type': 'application/json', 'reutersuuid': USERID, 'Authorization': 'Bearer ' + TOKEN}
headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + TOKEN}

print(">> POST rule in '%s'\n" % (DsD_Res))
url = HOSTURL + '/' + DsD_Res + '/rules'

with open(DIR_SCHEMA + '/' + SFILE_Res) as json_file:
    json_dict = json.load(json_file)
    payload = json.dumps(json_dict)

response = requests.request("POST", url, headers=headers, data = payload, verify=False)
print(response.text.encode('utf8') + "\n")


print(">> POST rule in '%s'\n" % (DsD_Obj))
url = HOSTURL + '/' + DsD_Obj + '/rules'

with open(DIR_SCHEMA + '/' + SFILE_Obj) as json_file:
    json_dict = json.load(json_file)
    payload = json.dumps(json_dict)

response = requests.request("POST", url, headers=headers, data = payload, verify=False)
print(response.text.encode('utf8') + "\n")


print(">> POST rule in '%s'\n" % (DsD_Des))
url = HOSTURL + '/' + DsD_Des + '/rules'

with open(DIR_SCHEMA + '/' + SFILE_Des) as json_file:
    json_dict = json.load(json_file)
    payload = json.dumps(json_dict)

response = requests.request("POST", url, headers=headers, data = payload, verify=False)
print(response.text.encode('utf8') + "\n")
