#!/bin/bash

if (( $# < 4 )); then
    echo "Usage: $0 <config.yml> <CSName> <DPId> <CVId>"
    exit 1
fi

CONFIG=$1
CSNM=$2
DPID=$3
CVID=$4

PAYLOADDIR="../export_${CSNM}"

if [ ! -d "${PAYLOADDIR}" ]; then
    echo "Directory '${PAYLOADDIR}' not found!"
	exit 2
fi

./mrmt import --config="${CONFIG}" -cs "${CSNM}" -dp ${DPID} -cv ${CVID} -i "${PAYLOADDIR}"
