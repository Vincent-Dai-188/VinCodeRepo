#!/bin/bash

while read LINE; do
	#SHOWSTR=$(echo $LINE | awk -F',' '{print $1","$2","$3","}')
	echo -n "${LINE},"
	DP=$(echo $LINE | awk -F',' '{print $1}')
	getThing $DP -D | jq -rj '"\"",."@graph"[0]."http://www.w3.org/2000/01/rdf-schema#label","\",","\"",."currentTo","\"\n"'
done < AUG_migration_DPCV_672_PPE_no_header.csv
