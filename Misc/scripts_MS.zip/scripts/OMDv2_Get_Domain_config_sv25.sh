#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3DEV_iRPM.slib

get_token_iRPM_4_mrmt

HOSTURL="https://api.dev.ms.refinitiv.com/metadata-service/metadata-store/beta1/admin/domains"

DOMAIN_SUBDOMAIN="configuration/data-store"
echo ">> Get '${DOMAIN_SUBDOMAIN}' configuration"
ret_Res=$(curl -sS -X GET "${HOSTURL}/${DOMAIN_SUBDOMAIN}" -H 'Content-Type: application/json' -H "Authorization: Bearer ${token}")
echo "$ret_Res"

sleep 2

DOMAIN_SUBDOMAIN="physical/data-store"
echo -e "\n>> Get '${DOMAIN_SUBDOMAIN}' configuration"
ret_Obj=$(curl -sS -X GET "${HOSTURL}/${DOMAIN_SUBDOMAIN}" -H 'Content-Type: application/json' -H "Authorization: Bearer ${token}")
echo "$ret_Obj"

sleep 2

DOMAIN_SUBDOMAIN="logical/data-store"
echo -e "\n>> Get '${DOMAIN_SUBDOMAIN}' configuration"
ret_Des=$(curl -sS -X GET "${HOSTURL}/${DOMAIN_SUBDOMAIN}" -H 'Content-Type: application/json' -H "Authorization: Bearer ${token}")
echo "$ret_Des"

echo
