#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_PPE.slib

function display_help
{
    echo "Usage: $0 <-r|-o|-s> <-V schemaVer> [-J] [-h]"
}

#WORKDIR=$(dirname $(readlink -f "$0"))

JQPARSE="true"
while getopts :hrosVJ: paras
do
    case "$paras" in
        r)  Entity_URL="test-res-schemav2"
            ;;
        o)  Entity_URL="test-obj-schemav2"
            ;;
        s)  Entity_URL="test-des-schemav2"
            ;;
        V)  schemaVER="${OPTARG}"
            ;;
        J)  JQPARSE="false"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${Entity_URL}" ]; then
    display_help
    exit 2
fi

shift $((OPTIND-1))
Entity_URL="${Entity_URL}?schemaVersion=${schemaVER}"

get_token_ADM

QUERYPATH="https://metadata-service-ppe.ms-preprod.aws-int.refinitiv.com/metadata-store/beta1/schemas/metadatamigrationtest/${Entity_URL}"

CMDSTR="curl -s -X GET \"${QUERYPATH}\" -H \"Authorization: Bearer ${token}\""

if [ "${JQPARSE}" = "true" ]; then
    eval "$CMDSTR" | jq .
else
    eval "$CMDSTR"
fi
