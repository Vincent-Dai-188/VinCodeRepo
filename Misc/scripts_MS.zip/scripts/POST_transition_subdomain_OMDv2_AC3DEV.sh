#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3DEV_iRPM.slib

function display_help
{
    echo "Usage: $0 <-r|-o|-s> <-C|-G> [-h]"
}

if (( $# < 2 )); then
    display_help
    exit 1
fi

DSD_OPT=""
while getopts :hrosCG paras
do
    case "$paras" in
        r)  DSD_OPT="configuration/data-store"
            ;;
        o)  DSD_OPT="physical/data-store"
            ;;
        s)  DSD_OPT="logical/data-store"
            ;;
        C)  StartAdmSta="Created"
            ;;
        G)  StartAdmSta="Registered"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "$DSD_OPT" ]; then
    display_help
    exit 2
fi

get_token_iRPM_4_mrmt

HOSTURL="https://api.dev.ms.refinitiv.com/metadata-service/metadata-store/beta1/lifecycle-transitions"
#TRANS_STA="?startStatus=Created&endStatus=Registered"
TRANS_STA="?startStatus=${StartAdmSta}"

echo ">> POST (lifecycle-transitions) on '${DSD_OPT}' (${TRANS_STA})"
retMsg=$(curl -sS -X POST "${HOSTURL}/${DSD_OPT}${TRANS_STA}" -H 'Content-Type: application/json' -H "Authorization: Bearer ${token}")

echo $retMsg
