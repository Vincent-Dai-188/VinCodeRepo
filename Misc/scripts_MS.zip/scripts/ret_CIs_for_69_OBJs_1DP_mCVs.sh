#!/bin/bash

sn=0
while read LINE; do
    echo "$LINE" | grep "^ecp:" &> /dev/null
    if [ $? -eq 0 ]; then
        (( sn += 1 ))
        DPstr=$(echo "$LINE" | awk '{print $1}')
        DPid=$(echo "$DPstr" | awk -F',' '{print $1}')
        DPlabel=$(echo "$DPstr" | awk -F',' '{print $2}')
        printf "[%02d] DP: %s (DL: %s)\n" $sn $DPid $DPlabel
        migItem=$(grep $DPid ./Feb_migration_DPCV_769_PPE_2022.csv)
        if [ -n "$migItem" ]; then
            echo "   > $migItem <"
            migCVid=$(echo "$migItem" | awk -F',' '{print $2}')
        else
            echo "   > NULL <"
            migCVid=""
        fi
        CVstr=$(echo "$LINE" | awk '{print $2}')
        CVset=$(echo "$CVstr" | grep -o "ecp:[^,]*,[^;]*")
        ix=0
        for CVitem in $CVset; do
            (( ix += 1 ))
            CVid=$(echo "$CVitem" | awk -F',' '{print $1}')
            CVlabel=$(echo "$CVitem" | awk -F',' '{print $2}')
            if [ "$migCVid" = "${CVid}" ]; then
                CVlabel="${CVlabel} *"
            fi
            printf "(%d) DP/CV: %s %s (VL: %s)\n" $ix $DPid $CVid "$CVlabel"
            ./get_ContentItems_via_sparql_CIMaps_by_DP-CV.sh $DPid $CVid | sed '/^$/d' | egrep -v "No matching data found|null" | sort | uniq
        done
        echo
    fi
done < 69_OBJs_1DP_mCVs.lst
