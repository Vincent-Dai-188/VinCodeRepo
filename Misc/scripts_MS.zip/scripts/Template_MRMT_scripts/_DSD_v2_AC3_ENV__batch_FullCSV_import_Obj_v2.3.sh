#!/bin/bash

. ./DS_OBJ.lst

sn=0

for CSNM in ${DS_Obj};
do
	(( sn += 1 ))
	printf "\n[%02d] IMPORT '%s'\n" ${sn} ${CSNM}
    time -p ./_DSD_v2_AC3_ENV__FullCSV_import_CS_Obj_v2.3.sh ${CSNM}
    sleep 5
done
