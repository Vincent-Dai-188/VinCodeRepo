#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 <CSName> [-R]"
    exit 2
fi

CSNM=$1
ArcheType="object"
OUTDIR="../export_${CSNM}"
if (( $# >= 2 )); then
    RelOpt=$2
    if [ "${RelOpt}" = "-R" ]; then
        ArcheType="relationship"
        OUTDIR="${OUTDIR}_Rel"
    fi
fi

mkdir -p "${OUTDIR}"
./mrmt export --config="./_DSD_v2_config_v2.3_manual_AC3_ENV_.yml" -cs "${CSNM}" -at ${ArcheType} -o "${OUTDIR}"

