#!/bin/bash

. ./DS_OBJ.lst

MTVER="_MRMTVER_"

sn=0

for CSNM in ${DS_Obj};
do
    (( sn += 1 ))
    printf "\n[%02d] EXPORT OBJ '%s'\n" ${sn} ${CSNM}
    OUTLOG="./out_export_FullList_${CSNM}_${MTVER}.log"
    time -p ./_DSD_v2_AC3_ENV__FullCSV_export_CS_common_v2.3.sh ${CSNM} &> ${OUTLOG}
    sleep 3
    tail -n 200 ${OUTLOG} | grep " All DP_CV Process Done Total:"
done
