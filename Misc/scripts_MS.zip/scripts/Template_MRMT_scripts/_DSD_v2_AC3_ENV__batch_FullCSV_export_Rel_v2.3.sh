#!/bin/bash

. ./DS_REL.lst

MTVER="_MRMTVER_"

sn=0

for CSNM in ${DS_Rel};
do
    (( sn += 1 ))
    printf "\n[%02d] EXPORT REL '%s'\n" ${sn} ${CSNM}
    OUTLOG="./out_export_FullList_${CSNM}_Rel_${MTVER}.log"
    time -p ./_DSD_v2_AC3_ENV__FullCSV_export_CS_common_v2.3.sh ${CSNM} -R &> ${OUTLOG}
    sleep 3
    tail -n 230 ${OUTLOG} | grep " All DP_CV Process Done Total:"
done
