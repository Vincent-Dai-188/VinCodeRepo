#!/bin/bash

function show_errmsg  # errorMsg
{
    echo "$1" | sed -e 's/link\.graph\..*\.exception\.Metadata.*Exception: /  - /;s/ for the query with dates:BitemporalDatesImpl([^)]*)//'
}

if (( $# < 1 )); then
    echo "Usage: $0 <CSName>"
    exit 2
fi

CSNM=$1

DTIDS=$(date +"%m-%d_%H%M")

if [ ! -d "../export_${CSNM}" ]; then
    echo "*** Directory '../export_${CSNM}' not found!***"
    exit 1
fi

DOMAIN="metadatamigrationtest"

LOGFILE="./out_import_FullList_${CSNM}_${DTIDS}_MS_AC3_ENV_.log"
echo "  >> IMPORT '${CSNM}' (Obj) into '${DOMAIN}' domain on MS AC3_ENV_ ..."
./mrmt import --config="./_DSD_v2_config_v2.3_manual_AC3_ENV_.yml" -cs "${CSNM}" -at object -i "../export_${CSNM}" &> ${LOGFILE}
sleep 1

echo -n "  Summary: "
tail -n 200 ${LOGFILE} | grep "^\[INFO\]: -* All DP_CV Process Done Total"

ERRS=$(egrep "\.exception\.|\[ERROR\]: OneToOne or OneToMany without Child Data Element" ${LOGFILE})
if [ -n "$ERRS" ]; then
    echo "$ERRS" | while read LINE; do
        errMsg=$(echo "$LINE" | grep -o "{[^}]*}}$")
        if [ -n "$errMsg" ]; then
            echo "$errMsg" | jq -r -j '"  - ", .error.message, "\n"'
        else
            show_errmsg "$LINE"
        fi
    done
fi

