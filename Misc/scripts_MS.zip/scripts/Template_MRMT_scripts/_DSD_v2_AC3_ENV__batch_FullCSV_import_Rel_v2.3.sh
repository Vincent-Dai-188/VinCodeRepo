#!/bin/bash

. ./DS_REL.lst

sn=0

for CSNM in ${DS_Rel};
do
	(( sn += 1 ))
	printf "\n[%02d] IMPORT REL '%s'\n" ${sn} ${CSNM}
    time -p ./_DSD_v2_AC3_ENV__FullCSV_import_CS_Rel_v2.3.sh ${CSNM}
    sleep 5
done
