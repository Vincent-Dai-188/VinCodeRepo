#!/bin/bash

while read LINE; do
	DPID=$(echo $LINE | awk -F',' '{print $1}')
	CVID=$(echo $LINE | awk -F',' '{print $2}')
	DPLabel=$(getThing $DPID | jq -r '."@graph"[0]."http://www.w3.org/2000/01/rdf-schema#label"')
	CVLabel=$(getThing $CVID | jq -r '."@graph"[0]."http://www.w3.org/2000/01/rdf-schema#label"')
	echo "$DPID,$DPLabel,$CVID,$CVLabel"
done < 543_Rel_DPCVs_not_migrated_with_OT_in_migration_list_Dec.txt
