#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3QA_iRPM.slib

if (( $# < 1 )); then
	echo "Usage: $0 <DOMAIN/SUB-DOMAIN>"
	exit 1
fi

DSD=$1

get_token_iRPM_4_mrmt

QUERYPATH="https://api.qa.ms.refinitiv.com/metadata-service/metadata-store/beta1/schemas/${DSD}"

ret=$(curl -s -X GET "${QUERYPATH}?$adminStatus=Released" -H "Authorization: Bearer ${token}")

echo "$ret" | jq '.'
