#!/bin/bash

for fn in $(ls *.json); do
    #MIGv2_Muni_resUnit_8-325d48d3-9188-4000-9239-9bdac8733751_9-a0a2b444-af78-4d8c-aff3-631755f1d3f0.json
    #MIGv2_OA5_rel-resUnit_9-6f5f5ba2-5d6f-4997-8694-8f5ad7225c43_9-028974a7-b8d1-4d42-9bfa-070d96cec6bb.json
    echo "- oldFn: $fn"

    prefixFn=$(echo "$fn" | grep -o "MIGv2_[a-zA-Z0-9]*_[a-zA-Z-]*")

    idlist=$(echo "$fn" |  grep -o "[0-9]-[0-9a-z]\{8\}-[0-9a-z]\{4\}-[0-9a-z]\{4\}-[0-9a-z]\{4\}-[0-9a-z]\{12\}")
    DPId=$(echo $idlist | awk '{print $1}')
    CVId=$(echo $idlist | awk '{print $2}')

    #newFn="${prefixFn}_${DPId:34:4}_${CVId:34:4}.json"
    newFn="${prefixFn}_${DPId:2:4}_${CVId:2:4}.json"

    echo "  >> rename to '$newFn'"
    mv $fn $newFn
done

