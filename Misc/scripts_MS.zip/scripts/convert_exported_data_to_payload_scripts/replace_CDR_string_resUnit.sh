#!/bin/bash

# According to schema v2.2, reference CDRstring exist in resUnit only.

DOMAIN="metadatamigrationtest"
SD_OBJ="test-obj-schemav2"
SD_DES="test-des-schemav2"

sed -i -e "s/\${layer2Domain}/${DOMAIN}>${SD_OBJ}/g;s/\${objectDescriptionDomain}/${DOMAIN}>${SD_DES}/g" *_resUnit_*.json
