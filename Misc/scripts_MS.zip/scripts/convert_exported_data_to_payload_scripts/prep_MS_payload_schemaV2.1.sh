#!/bin/bash

output_dir="payload_MS_v1.1.136"

if [ ! -d "./${output_dir}" ]; then
    mkdir -p "./${output_dir}"
fi

# OBJECT
for CS in ESG EP2; do
    echo ">> OBJ_$CS"
    if [ -d ./export_${CS} ]; then
        cd ./export_${CS}
    else
        echo "   *** Exported data folder for 'OBJ_${CS}' not found! ***"
        continue
    fi
    for fn in $(ls *.json); do
        echo "  -> $fn"
        jq '."resourceDomainRoot"."resourceUnits"[]' $fn > ../${output_dir}/TSSv2_${CS}_resUnit_${fn}
        envStr=$(jq '."layer2DomainRoot"."envelopes"[]' $fn 2>/dev/null)
        if [ -n "$envStr" ]; then
            echo "$envStr" > ../${output_dir}/TSSv2_${CS}_envelope_${fn}
        else
            echo "   *** No 'envelopes'. ***"
        fi
        desStr=$(jq '."objectDescriptionRoot"."objectCollection"[]' $fn 2>/dev/null)
        if [ -n "$desStr" ]; then
            echo "$desStr" > ../${output_dir}/TSSv2_${CS}_description_${fn}
        else
            echo "   *** No 'objectCollection'. ***"
        fi
    done
    cd ..
done
