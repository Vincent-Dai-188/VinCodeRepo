#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3DEV_iRPM.slib

function display_help
{
    echo "Usage: $0 <-O|-T> <-r|-o|-b|-s targetName> <-P payloadfile> [-h]"
}

if (( $# < 4 )); then
    display_help
    exit 1
fi

AutoStatus=""

while getopts :hOTr:o:b:s:P: paras
do
    case "$paras" in
        O)  DSD_res="configuration/data-store"
            DSD_obj="physical/data-store"
            DSD_des="logical/data-store"
            ;;
        T)  DSD_res="metadatamigrationtest/test-res-schemav2"
            DSD_obj="metadatamigrationtest/test-obj-schemav2"
            DSD_des="metadatamigrationtest/test-des-schemav2"
            ;;
        r)  targetName="${OPTARG}"
            subRootPath="${DSD_res}/resourceUnits/${targetName}"
            ;;
        o)  targetName="${OPTARG}"
            subRootPath="${DSD_obj}/envelopes/${targetName}"
            ;;
        b)  targetName="${OPTARG}"
            subRootPath="${DSD_des}/objectTypes/${targetName}"
            ;;
        s)  targetName="${OPTARG}"
            subRootPath="${DSD_des}/relationshipTypes/${targetName}"
            ;;
        P)  PAYLOADFILE="${OPTARG}"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

get_token_iRPM_4_mrmt

HOSTURL="https://api.dev.ms.refinitiv.com/metadata-service/metadata-store/beta1/metadata"
RELEASEDSTA="?overwrite=true&adminStatus=Released"

echo ">> POST (Overwrite) '${subRootPath}' with payload file '${PAYLOADFILE}'"
retMsg=$(curl -sS -X POST "${HOSTURL}/${subRootPath}${RELEASEDSTA}" -H 'Content-Type: application/json' -H 'User-Provided-Id: true' -H "Authorization: Bearer ${token}" -d @${PAYLOADFILE})

echo $retMsg
