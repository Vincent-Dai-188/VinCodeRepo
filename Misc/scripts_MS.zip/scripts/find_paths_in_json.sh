#!/bin/bash

function display_help
{
	echo "Usgae: $0 <json_file> <keyword> [-P] [-h]"
}

if (( $# < 2 )); then
    display_help
    exit 2
fi

JSONFILE=$1
keyWord=$2

shift 2

convertToPath=""
while getopts :hP paras
do
    case "$paras" in
        P)  convertToPath="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

ret=$(jq -c --arg argV "$keyWord" 'paths | select(.[-1] == $argV)' $JSONFILE)
if [ -n "${convertToPath}" ]; then
	echo "$ret" | sed -e "s/,\([0-9]\{1,3\}\),/[\1]./g;s/\",\"/\".\"/g;s/^\[/./g;s/\]$//g"
else
	echo "$ret"
fi
