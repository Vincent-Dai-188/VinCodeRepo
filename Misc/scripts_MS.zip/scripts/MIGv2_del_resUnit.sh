#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_PPE.slib

if (( $# < 1 )); then
    echo "Usage: $0 <resourceUnit>"
    exit 2
fi

resUnitName=$1

get_token_ADM

echo ">> DELETE resourceUnit '${resUnitName}' in \"migrationv2/resource\""
curl -sS -X DELETE "https://metadata-service-ppe.ms-preprod.aws-int.refinitiv.com/metadata-store/beta1/metadata/migrationv2/resource/resourceUnits/${resUnitName}?cascade=true&adminStatus=Migrated" -H "Authorization: Bearer ${token}"

