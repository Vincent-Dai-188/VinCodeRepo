#!/bin/bash
sn=0
while read FN; do
	(( sn += 1 ))
	printf "\n[%03d] %s\n" $sn $FN
    cat $FN | jq -c 'paths | select(.[-1] == "oldLabel")' > ./oldLabel_paths.tmp
    while read LINE; do
        labelPath=$(echo $LINE | sed -e "s/^\[/./;s/\",\"/\".\"/g;s/,\([0-9]*\),/[\1]./g;s/\"oldLabel\"\]/\"oldLabel\"/")
        namePath=$(echo $labelPath | sed 's/oldLabel/name/')
        oldLabel=$(jq $labelPath $FN)
		name=$(jq $namePath $FN)
		nmLen=$(echo $name | wc -c)
		if (( nmLen <= 66 )); then	# Returned length include '""' & 'EOL"
			echo "  - name(MS), oldLabel: $name, $oldLabel"
		else
			echo "  - name(MS), oldLabel: $name, $oldLabel  (!!! Name_Length_Exceed_63 !!!)"
		fi
    done < ./oldLabel_paths.tmp
done < files_list_SEP.txt

rm -f ./oldLabel_paths.tmp
