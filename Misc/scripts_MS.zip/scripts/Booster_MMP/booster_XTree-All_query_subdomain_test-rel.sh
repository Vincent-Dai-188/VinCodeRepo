#time -p ./booster_query_metadata_PPE_ELB.sh /metadata/metadatamigrationtest/test-rel -XAll
time -p curl -s -o /dev/null -w "- Status_code: %{http_code}\n" -X GET 'https://metadata-booster-lab.ms-preprod.aws-int.refinitiv.com/metadata/metadatamigrationtest/test-rel?adminStatus=Migrated' -H 'expandTree: All'
