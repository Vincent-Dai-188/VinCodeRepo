#!/bin/bash

function display_help
{
    echo "Usage: $0 <payload_file> [-b <num>] [-e <num>] [-J] [-h]"
}

#WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 1 )); then
    display_help
    exit 1
fi

PAYLOADFILE=$1
shift

NUM_BEGIN=1
NUM_END=10
while getopts :hJb:e: paras
do
    case "$paras" in
        b)  NUM_BEGIN=${OPTARG}
            ;;
        e)  NUM_END=${OPTARG}
            ;;
        J)  JQPARSE="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 1
            ;;
    esac
done

QUERYPATH="https://metadata-booster-lab.ms-preprod.aws-int.refinitiv.com/mmp/users/yun_dai2/saved-search"

payloadRaw=$(cat "${PAYLOADFILE}")

echo "$payloadRaw" | grep -o '%NUM%' "${PAYLOADFILE}" &> /dev/null
if [ $? -ne 0 ]; then
    echo "*** Wrong template file is specified! ***"
    exit 2
fi

for((n=${NUM_BEGIN};n<=${NUM_END};n++)); do
    SN=$(printf "%03d" ${n})
    echo ">> $SN"

    Payload=$(echo $payloadRaw | sed "s/%NUM%/${SN}/")

    CMDSTR="curl -s -X POST '${QUERYPATH}' -H 'Content-Type: application/json' -d '"${Payload}"'"

    if [ "${JQPARSE}" = "true" ]; then
        eval "$CMDSTR" | jq .
    else
        eval "$CMDSTR"
    fi

    echo
    sleep 1
done

