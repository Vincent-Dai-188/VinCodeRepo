#!/bin/bash

function display_help
{
    echo "Usage: $0 <ECPID> <-r|-o|-s> [-V <schemaVer>] [-J] [-h]"
}

if (( $# < 2 )); then
    display_help
    exit 2
fi

ECPID=$1
shift 1

ADMINSTA="?adminStatus=Migrated"
token=""
JQPARSE="true"
while getopts :hrosJV: paras
do
    case "$paras" in
        r)  Entity_URL="test-res"
            ;;
        o)  Entity_URL="test-obj"
            ;;
        s)  Entity_URL="test-rel"
            ;;
        V)  schemaVer=${OPTARG}
            ADMINSTA="?schemaVersion=${schemaVer}&adminStatus=Migrated"
            ;;
        J)  JQPARSE="false"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -n "${Entity_URL}" ]; then
    Entity_URL="${Entity_URL}/${ECPID}"
else
    display_help
    exit 2
fi

res=$(curl -s -X GET "https://metadata-booster-lab.ms-preprod.aws-int.refinitiv.com/metadata-store/beta1/metadata-ids/metadatamigrationtest/${Entity_URL}${ADMINSTA}")

err=$(echo "$res" | jq '.error? | .')
if [ -n "$err" ]; then
    echo "$err" | jq .
    exit 1
fi

if [ "${JQPARSE}" = "true" ]; then
    echo "$res" | jq .
else
    echo "$res"
fi

