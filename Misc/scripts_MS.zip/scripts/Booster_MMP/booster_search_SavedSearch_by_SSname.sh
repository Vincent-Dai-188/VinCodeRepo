#!/bin/bash

function display_help
{
    echo "Usage: $UTILNAME <KEYWORD_SSNAME> [-p <page>] [-s <size>] [-S <sortBy>] [-O <desc|asc>] [-L] [-h]"
}

KEYWORD_SSNAME=$1
shift

USERNAME_SS="yun_dai2"

PAGENUM="1"
SIZENUM="10"
SORTBY="lastUpdateTime"
ORDERBY="desc"
ShowLength=""
while getopts :hLp:s:S:O: paras
do
    case "$paras" in
        p)  PAGENUM=${OPTARG}
            ;;
        s)  SIZENUM=${OPTARG}
            ;;
        S)  SORTBY=${OPTARG}
            ;;
        O)  ORDERBY=${OPTARG}
            ;;
        L)  ShowLength="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

HOSTQUERY="https://metadata-booster-lab.ms-preprod.aws-int.refinitiv.com/mmp/users"

#curl -s -o /dev/null -w "- Status_code: %{http_code}\n" -X GET "${HOSTQUERY}/${USERNAME_SS}/saved-search?keyword=${KEYWORD_SSNAME}&page=${PAGENUM}&size=${SIZENUM}&sortBy=${SORTBY}&orderBy=${ORDERBY}"

if [ -n "${ShowLength}" ]; then
    ret=$(curl -s -X GET "${HOSTQUERY}/${USERNAME_SS}/saved-search?keyword=${KEYWORD_SSNAME}&page=${PAGENUM}&size=${SIZENUM}&sortBy=${SORTBY}&orderBy=${ORDERBY}" | jq '. | length')
    echo "Length of response list: $ret"
else
    #curl -s -X GET "${HOSTQUERY}/${USERNAME_SS}/saved-search?keyword=${KEYWORD_SSNAME}&page=${PAGENUM}&size=${SIZENUM}&sortBy=${SORTBY}&orderBy=${ORDERBY}" | jq
    curl -s -X GET "${HOSTQUERY}/${USERNAME_SS}/saved-search?keyword=${KEYWORD_SSNAME}&page=${PAGENUM}&size=${SIZENUM}&sortBy=${SORTBY}&orderBy=${ORDERBY}"
fi

echo

