./booster_get_redis_keys_by_filter.sh metadatamigrationtest/test-obj* | jq '. | length'
