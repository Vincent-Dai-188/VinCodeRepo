#!/bin/bash

function display_help
{
    echo "Usage: $0 <Key_Tag>"
    echo "  e.g., $0 \"migrationv2/object\""
}

WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 1 )); then
    display_help
    exit 1;
fi

keyTag=$1

Key="metadata:/metadata/${keyTag}?adminStatus=Migrated&schemaVersion=*&expandTree=0"

URLKey=$(${WORKDIR}/URL_converter "${Key}")

DELKEYCMD="https://metadata-booster-lab.ms-preprod.aws-int.refinitiv.com/admin/redis/explorer?key=${URLKey}"

curl -s -X DELETE "${DELKEYCMD}"

