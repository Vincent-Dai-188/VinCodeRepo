#!/bin/bash

function display_help
{
    echo "Usage: $0 <naturalNamePath> [-J] [-X <num>] [-h]"
}

#WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 1 )); then
    display_help
    exit 1;
fi

naturalNP=$1
shift

ADMINSTA="adminStatus=Migrated"
JQPARSE="true"
expTNum=""
while getopts :hJX: paras
do
    case "$paras" in
        J)  JQPARSE="false"
            ;;
        X)  expTNum=${OPTARG}
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 1
            ;;
    esac
done

#echo ${naturalNP} | grep -o "^/metadata/" &> /dev/null
#if [ $? -ne 0 ]; then
#    naturalNP="/metadata/${naturalNP}"
#fi

echo ${naturalNP} | grep -o "${ADMINSTA}" &> /dev/null
if [ $? -ne 0 ]; then
    naturalNP="${naturalNP}?${ADMINSTA}"
fi

QUERYPATH="https://metadata-booster-lab.ms-preprod.aws-int.refinitiv.com${naturalNP}"

if [ -n "${expTNum}" ]; then
    CMDSTR="curl -s -X GET \"${QUERYPATH}\" -H \"expandTree: ${expTNum}\""
else
    CMDSTR="curl -s -X GET \"${QUERYPATH}\""
fi

if [ "${JQPARSE}" = "true" ]; then
    eval "$CMDSTR" | jq .
else
    eval "$CMDSTR"
fi

echo

