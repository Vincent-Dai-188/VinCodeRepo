./booster_get_redis_keys_by_filter.sh metadatamigrationtest/test-res* | jq '. | length'
