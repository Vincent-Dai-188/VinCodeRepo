curl -s -X DELETE 'https://metadata-booster-lab.ms-preprod.aws-int.refinitiv.com/cache/metadata/metadatamigrationtest/test-res?adminStatus=Migrated'
echo
