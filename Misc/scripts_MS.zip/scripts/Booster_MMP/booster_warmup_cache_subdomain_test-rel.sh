time -p (curl -X GET 'https://metadata-booster-lab.ms-preprod.aws-int.refinitiv.com/cache/warmup/metadata/metadatamigrationtest/test-rel?adminStatus=Migrated' && echo)
sleep 1
./booster_keys_cache_subdomain_test-rel.sh
