echo -n "obj: " && ./booster_redis_keys_filter.sh metadatamigrationtest/test-obj* | jq '. | length'
echo -n " EP: " && ./booster_redis_keys_filter.sh metadatamigrationtest/test-obj/objectTypes/Events-EP* | jq '. | length'
echo -n "MnA: " && ./booster_redis_keys_filter.sh metadatamigrationtest/test-obj/objectTypes/Events-EP/contentItems/DealsMnAProxy* | jq '. | length'
