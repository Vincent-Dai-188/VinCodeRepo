curl -s -X GET 'https://metadata-booster-lab.ms-preprod.aws-int.refinitiv.com/mmp/users/yun_dai2/saved-search' | jq
