#!/bin/bash

function display_help
{
    echo "Usage: $0 <keys filter>"
    echo "  e.g., $0 \"migrationv2/object/*\""
}

WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 1 )); then
    display_help
    exit 1;
fi

keysTag=$1

KeysPattern="metadata:/metadata/${keysTag}"

KeysFilter=$(${WORKDIR}/URL_converter "${KeysPattern}")

DELKEYCMD="https://metadata-booster-lab.ms-preprod.aws-int.refinitiv.com/admin/redis/explorer/keys?filter=${KeysFilter}"

curl -s -X DELETE "${DELKEYCMD}"

