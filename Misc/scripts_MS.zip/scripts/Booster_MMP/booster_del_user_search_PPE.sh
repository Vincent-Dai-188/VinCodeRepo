#!/bin/bash

function display_help
{
    echo "Usage: $0 <SearchName> [-J] [-h]"
}

#WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 1 )); then
    display_help
    exit 1
fi

SearchName=$1
shift

while getopts :hJ paras
do
    case "$paras" in
        J)  JQPARSE="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 1
            ;;
    esac
done

QUERYPATH="https://metadata-booster-lab.ms-preprod.aws-int.refinitiv.com/mmp/users/yun_dai2/saved-search/${SearchName}"

CMDSTR="curl -s -X DELETE '${QUERYPATH}'"

if [ "${JQPARSE}" = "true" ]; then
    eval "$CMDSTR" | jq .
else
    eval "$CMDSTR"
fi

