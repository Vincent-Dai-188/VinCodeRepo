#!/bin/bash

function display_help
{
    echo "Usage: $0 <batch_query_file> [-J] [-h]"
}

#WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 1 )); then
    display_help
    exit 1
fi

QUERYFIEL=$1
shift

while getopts :hJ paras
do
    case "$paras" in
        J)  JQPARSE="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 1
            ;;
    esac
done


#batchPayload='["/metadata/metadatamigrationtest/test-res/resourceUnits/AbsCmoCdfOffering-ResourceUnit?adminStatus=Migrated&schemaVersion=*&expandTree=0","/metadata/metadatamigrationtest/test-obj/objectTypes/ESG/contentItems/ManagementIndicators/dataStructure/ESG-DataStructure/dataItems/BoardAttendance?adminStatus=Migrated&schemaVersion=*&expandTree=1","/metadata/metadatamigrationtest/test-obj/objectTypes/ESG/contentItems/WorkforceDataPoints/dataStructure?adminStatus=Migrated&schemaVersion=*&expandTree=0","/metadata/metadatamigrationtest/test-obj/objectTypes/OA5?adminStatus=Migrated&schemaVersion=*&expandTree=0"]'

batchPayload=$(cat "${QUERYFIEL}")

QUERYPATH="https://metadata-booster-lab.ms-preprod.aws-int.refinitiv.com/batch/metadata"

CMDSTR="curl -s -X POST '${QUERYPATH}' -H 'Content-Type: application/json' -d '"${batchPayload}"'"

if [ "${JQPARSE}" = "true" ]; then
    eval "$CMDSTR" | jq .
else
    eval "$CMDSTR"
fi

