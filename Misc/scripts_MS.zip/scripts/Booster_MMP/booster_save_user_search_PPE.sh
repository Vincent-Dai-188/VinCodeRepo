#!/bin/bash

function display_help
{
    echo "Usage: $0 <payload_file> [-J] [-h]"
}

#WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 1 )); then
    display_help
    exit 1
fi

PAYLOADFILE=$1
shift

while getopts :hJ paras
do
    case "$paras" in
        J)  JQPARSE="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 1
            ;;
    esac
done

Payload=$(cat "${PAYLOADFILE}")

QUERYPATH="https://metadata-booster-lab.ms-preprod.aws-int.refinitiv.com/mmp/users/yun_dai2/saved-search"

CMDSTR="curl -s -X POST '${QUERYPATH}' -H 'Content-Type: application/json' -d '"${Payload}"'"

if [ "${JQPARSE}" = "true" ]; then
    eval "$CMDSTR" | jq .
else
    eval "$CMDSTR"
fi

