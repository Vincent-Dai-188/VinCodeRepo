time -p curl -s -o /dev/null -w "- Status_code: %{http_code}\n" -X DELETE "https://metadata-booster-lab.ms-preprod.aws-int.refinitiv.com/admin/redis/explorer/keys?filter=metadata%3A%2Fmetadata%2Fmetadatamigrationtest%2Ftest-obj%2FobjectTypes%2FEvents-EP%2A"

echo
sleep 1
./booster_EP_keys_cache_subdomain_test-obj.sh
