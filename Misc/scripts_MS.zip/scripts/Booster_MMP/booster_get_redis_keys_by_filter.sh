#!/bin/bash

function display_help
{
    echo "Usage: $0 <keys filter> [-J] [-h]"
    echo "  e.g., $0 \"migrationv2/object/*\""
}

WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 1 )); then
    display_help
    exit 1;
fi

keysTag=$1
shift

JQPARSE="true"
while getopts :hJ paras
do
    case "$paras" in
        J)  JQPARSE="false"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 1
            ;;
    esac
done

KeysPattern="metadata:/metadata/${keysTag}"

KeysFilter=$(${WORKDIR}/URL_converter "${KeysPattern}")

QUERYPATH="https://metadata-booster-lab.ms-preprod.aws-int.refinitiv.com/admin/redis/explorer/keys?filter=${KeysFilter}"

CMDSTR="curl -s -X GET \"${QUERYPATH}\""

ret=$(eval "$CMDSTR")
if [ "${ret}" != "[]" ]; then
    echo ">> Drop prefix 'metadata:' ..."
    ret=$(echo ${ret} | sed 's/"metadata:/"/g')
fi

if [ "${JQPARSE}" = "true" ]; then
    echo $ret | jq .
else
    echo $ret
fi

