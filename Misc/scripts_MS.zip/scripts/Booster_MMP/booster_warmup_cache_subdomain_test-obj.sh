time -p (curl -sS -w "\n- Status_code: %{http_code}\n" -X GET 'https://metadata-booster-lab.ms-preprod.aws-int.refinitiv.com/cache/warmup/metadata/metadatamigrationtest/test-obj?adminStatus=Migrated' && echo)
sleep 1
./booster_EP_keys_cache_subdomain_test-obj.sh
