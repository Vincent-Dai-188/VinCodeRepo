#!/bin/bash

function display_help
{
    echo "Usage: $0 <ECPID> <-r|-o|-s> [-V <schemaVer>] [-T <token>] [-J] [-h]"
}

. /data/vincent/slibs/fetch_token_MS_PPE.slib

if (( $# < 2 )); then
    display_help
    exit 2
fi

ECPID=$1
shift 1

ADMINSTA="?adminStatus=Migrated"
token=""
JQPARSE="true"
while getopts :hrosJV:T: paras
do
    case "$paras" in
        r)  Entity_URL="test-res-schemav2"
            ;;
        o)  Entity_URL="test-obj-schemav2"
            ;;
        s)  Entity_URL="test-des-schemav2"
            ;;
        V)  schemaVer=${OPTARG}
            ADMINSTA="?schemaVersion=${schemaVer}&adminStatus=Migrated"
            ;;
        T)  token="${OPTARG}"
            ;;
        J)  JQPARSE="false"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -n "${Entity_URL}" ]; then
    Entity_URL="${Entity_URL}/${ECPID}"
else
    display_help
    exit 2
fi

get_token_ADM

res=$(curl -s -X GET "https://metadata-service-ppe.ms-preprod.aws-int.refinitiv.com/metadata-store/beta1/metadata-ids/metadatamigrationtest/${Entity_URL}${ADMINSTA}" -H "Authorization: Bearer ${token}")

err=$(echo "$res" | jq '.error? | .')
if [ -n "$err" ]; then
    echo "$err" | jq '.'
    exit 1
fi

if [ "${JQPARSE}" = "true" ]; then
    echo "$res" | jq '.'
else
    echo "$res"
fi
