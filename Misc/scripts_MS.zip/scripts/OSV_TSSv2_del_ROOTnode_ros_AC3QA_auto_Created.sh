#!/bin/bash

function get_job_status     # retMsg
{
    retMsg=$1
    #echo "- ${retMsg}"
    staCode=$(echo "${retMsg}" | jq -r '.status')
    if [ "${staCode}" = "202" ]; then
        retLocation=$(echo "${retMsg}" | jq -r '.payload.location')
        echo " - $retLocation"
        count=0
        while (( count < 50 ))
        do
            (( count+=1 ))
            retQuery=$(curl -sS -X GET "https://api.qa.ms.refinitiv.com/metadata-service/metadata-store${retLocation}" -H "Authorization: Bearer ${token}")
            staCodeQ=$(echo "${retQuery}" | jq -r '.status')
            if [ "${staCodeQ}" = "200" ]; then
                status_Res=$(echo "${retQuery}" | jq -r '.payload.status')
                echo ">> ${status_Res}"
                if [ "${status_Res}" = "FAILED" ] || [ "${status_Res}" = "COMPLETED" ]; then
                    break
                else
                    sleep 20
                fi
            else
                echo "Failed to get write job status!"
                echo "${retQuery}"
                return 1
            fi
        done
    else
        echo "Failed to create write job!"
        echo "${retMsg}"
        return 2
    fi
    return 0
}

. /data/vincent/slibs/fetch_token_MS_AC3QA_iRPM.slib

function display_help
{
    echo "Usage: $0 <Override_Schema_Version> <-r|-o|-s>"
}

if (( $# < 2 )); then
    display_help
    exit 2
fi

schemaVER=$1
shift

while getopts :rosh paras
do
    case "$paras" in
        r)  Entity_URL="/metadatamigrationtest/test-res-schemav2"
            ;;
        o)  Entity_URL="/metadatamigrationtest/test-obj-schemav2"
            ;;
        s)  Entity_URL="/metadatamigrationtest/test-des-schemav2"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

get_token_iRPM_4_mrmt

echo ">> DELETE '${Entity_URL}'"
retMsg=$(curl -sS -X DELETE "https://api.qa.ms.refinitiv.com/metadata-service/metadata-store/beta1/metadata${Entity_URL}?cascade=true&adminStatus=Created" -H "Override-Schema-Version: ${schemaVER}" -H "Authorization: Bearer ${token}")

get_job_status "${retMsg}"
