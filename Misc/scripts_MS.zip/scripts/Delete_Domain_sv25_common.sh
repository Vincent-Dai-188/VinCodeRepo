#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3DEV_iRPM.slib

if (( $# < 1 )); then
	echo "Usage: $0 <DOMAIN/SUBDOMAIN>"
	exit 1
fi

DOMAIN_SUBDOMAIN=$1

get_token_iRPM_4_mrmt

HOSTURL="https://api.dev.ms.refinitiv.com/metadata-service/metadata-store/beta1/admin/domains"

echo ">> Delete '${DOMAIN_SUBDOMAIN}'"
retROOT_Res=$(curl -sS -X DELETE "${HOSTURL}/${DOMAIN_SUBDOMAIN}" -H 'Content-Type: application/json' -H "Authorization: Bearer ${token}")
echo "$retROOT_Res"
