#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_PPE.slib

if (( $# < 1 )); then
    echo "Usage: $0 <envelope>"
    exit 2
fi

envelopeName=$1

get_token_ADM

echo ">> DELETE envelope '${envelopeName}' in \"metadatamigrationtest/object\""
curl -sS -X DELETE "https://metadata-service-ppe.ms-preprod.aws-int.refinitiv.com/metadata-store/beta1/metadata/metadatamigrationtest/object/envelopes/${envelopeName}?cascade=true&adminStatus=Migrated" -H "Authorization: Bearer ${token}"

