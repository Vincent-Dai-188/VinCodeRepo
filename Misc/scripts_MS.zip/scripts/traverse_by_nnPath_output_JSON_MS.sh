#!/bin/bash

function print_string_indent    #string
{
    dataStr=$1

    IndentStr="$(printf '%*s' $nIndent)"
    echo "${IndentStr}${dataStr}"
}

function close_json_array    #counter #upperlimit
{
    cnt=$1
    uplimit=$2

    IndentStr="$(printf '%*s' $nIndent)"
    if (( cnt < uplimit )); then
        echo "${IndentStr}],"
    else
        echo "${IndentStr}]"
    fi
}

function close_json_object    #counter #upperlimit
{
    cnt=$1
    uplimit=$2

    IndentStr="$(printf '%*s' $nIndent)"
    if (( cnt < uplimit )); then
        echo "${IndentStr}},"
    else
        echo "${IndentStr}}"
    fi
}

# Output all the properties (K,V) of an Element
# CloseOption: 'true' - don't output ',' at the end, 'false' - output ',' at the end
function print_pros     #Properties (K,V)  #CloseOption
{
    PropLines=$1
    OptClose=$2

    Len=$(echo "$PropLines" | wc -l)
    if [ "$OptClose" = "true" ]; then
        if (( Len == 1 )); then
            print_string_indent "$PropLines"
        else
            LastLine=$(echo "$PropLines" | tail -n 1)
            #Drop last line
            PropLines=$(echo "$PropLines" | sed '$d')
            echo "$PropLines" | while read LINE; do print_string_indent "${LINE},"; done
            print_string_indent "$LastLine"
        fi
    else
        echo "$PropLines" | while read LINE; do print_string_indent "${LINE},"; done
    fi
}

function print_refs     #References (K,V)
{
    RefLines=$1

    Len=$(echo "$RefLines" | wc -l)
    if (( Len == 1 )); then
        print_string_indent "{"
        print_string_indent "  $RefLines"
        print_string_indent "}"
    else
        LastLine=$(echo "$RefLines" | tail -n 1)
        #Drop last line
        RefLines=$(echo "$RefLines" | sed '$d')
        echo "$RefLines" | while read LINE; do print_string_indent "{" && print_string_indent "  $LINE" && print_string_indent "},"; done
        print_string_indent "{"
        print_string_indent "  $LastLine"
        print_string_indent "}"
    fi
}

function DS_traverse_by_nnPath    #nnPath
{
    naturalNamePath=$1

    local retObj
    # In order to get the real return code, local variable must be declared separately (above), otherwise return code will always be 0
    retObj=$(./nnPath_query_metadata_MS.sh "${naturalNamePath}")
    if [ $? -ne 0 ]; then
        print_string_indent "$retObj"
        exit 2
    fi

    isObjSets=$(echo "$retObj" | jq -r '. | if type=="array" then "False" else "True" end')
    if [ "${isObjSets}" = "False" ]; then
        echo -e "\n*** Unexpected array structure is detected! Please check the nnPath your entered. ***"
        exit 1
    fi

    ecpid=$(echo "$retObj" | jq -r '."_links"."self"[0].href')
    print_string_indent "\"href\": \"${ecpid}\","
    print_string_indent "\"nnPath\": \"${naturalNamePath}\","
    # Get all the properties (K,V)
    # Here we use '-c' option to get the value of list returned in a compact format
    props=$(echo "$retObj" | jq -cj 'to_entries[] | select(.key!="_links") | if .value|type=="string" then "\"",.key, "\": ", (.value|tojson), "\n" else "\"",.key, "\": ", .value, "\n" end')

    # Get the expandable Elements except "self" in "_links"{}
    subNodes=$(echo "$retObj" | jq -r '."_links" | to_entries[] | select(.key!="self") | .key')
    if [ -z "$subNodes" ]; then
        # Output properties (CloseOption: 'true')
        print_pros "$props" "true"
    else
        # Output properties (CloseOption: 'false')
        print_pros "$props" "false"
        local NumNodes=$(echo "$subNodes" | wc -l)
    fi

    local sn=0
    for node in $subNodes; do
        (( sn += 1 ))
        # Special process for ."_link"."_references", just display "href", "_meta.direction" & "_meta.definerSide", no further traversal required
        print_string_indent "\"${node}\": [" && (( nIndent += DELTA ))
        if [ "$node" = "_references" ]; then
            # Use '\"$BASHVAR\"' pattern to reference bash variable in jq '' (single quotes)
            refs=$(echo "$retObj" | jq -cj '."_links".'\"$node\"' | if type=="array" then .[] else [.][] end | to_entries[] | "\"", .key, "\": \"", .value.href, ",[", .value._meta.direction, "],", .value._meta.definerSide, "\"\n"')
            print_refs "$refs"
        else
            nnPathSet=$(echo "$retObj" | jq -r ".\"_links\".\"${node}\"[]? | .[1].href")
            local NumNNPaths=$(echo "$nnPathSet" | wc -l)
            local si=0
            for nnPathItem in $nnPathSet; do
                (( si += 1 ))
                print_string_indent "{" && (( nIndent += DELTA ))
                DS_traverse_by_nnPath "$nnPathItem"
                (( nIndent -= DELTA )) && close_json_object $si $NumNNPaths
            done
        fi
        (( nIndent -= DELTA )) && close_json_array $sn $NumNodes
    done
}

UTILNAME="$(basename $0)"
WORKDIR=$(dirname $(readlink -f "$0"))

if (( $# < 1 )); then
    echo "Usage: $UTILNAME <nnPath>"
    exit 1
fi

NNPATH=$1

DELTA=2

(( nIndent = DELTA ))

echo "{"
DS_traverse_by_nnPath ${NNPATH}
echo "}"

