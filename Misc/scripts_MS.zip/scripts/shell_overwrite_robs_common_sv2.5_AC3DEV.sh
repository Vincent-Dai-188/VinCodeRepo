#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3DEV_iRPM.slib

function display_help
{
    echo "Usage: $0 <-r|-o|-b|-s targetName> <-P payloadfile> [-h]"
}

if (( $# < 3 )); then
    display_help
    exit 1
fi

DSD_res="configuration/data-store"
DSD_obj="physical/data-store"
DSD_des="logical/data-store"

AutoStatus=""

while getopts :hr:o:b:s:P: paras
do
    case "$paras" in
        r)  targetName="${OPTARG}"
            subRootPath="${DSD_res}/resourceUnits/${targetName}"
            ;;
        o)  targetName="${OPTARG}"
            subRootPath="${DSD_obj}/objects/${targetName}"
            ;;
        b)  targetName="${OPTARG}"
            subRootPath="${DSD_des}/objectTypes/${targetName}"
            ;;
        s)  targetName="${OPTARG}"
            subRootPath="${DSD_des}/relationshipTypes/${targetName}"
            ;;
        P)  PAYLOADFILE="${OPTARG}"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

get_token_iRPM_4_mrmt

HOSTURL="https://api.dev.ms.refinitiv.com/metadata-service/metadata-store/beta1/metadata"
RELEASEDSTA="?overwrite=true&adminStatus=Released"

echo ">> POST (Overwrite) '${subRootPath}' with payload file '${PAYLOADFILE}'"
retMsg=$(curl -sS -X POST "${HOSTURL}/${subRootPath}${RELEASEDSTA}" -H 'Content-Type: application/json' -H 'User-Provided-Id: true' -H "Authorization: Bearer ${token}" -d @${PAYLOADFILE})

echo $retMsg
