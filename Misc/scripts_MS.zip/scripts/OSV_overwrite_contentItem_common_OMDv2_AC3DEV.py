#!/usr/bin/python

import requests
import sys

sys.path.append('/data/vincent/pylibs')
from fetch_token_MS_AC3DEV_iRPM import *

if ((len(sys.argv) < 5)):
    print("    Usage: %s <payload_file> <schemaVersion> <objectName> <contentItemName>\n" % sys.argv[0])
    sys.exit(2)

PAYLOAD_FILE = sys.argv[1]
schemaVER = sys.argv[2]
objectName = sys.argv[3]
CIName = sys.argv[4]

DsD_OBJ = 'physical/data-store/objects/' + objectName + '/contentItems/' + CIName
PAYLOAD_DIR = "/data/vincent/MR/MigrationTool_MR2.0/Perf_Test_4_migration"

TOKEN = get_token_iRPM_4_mrmt()

''' POST metadata '''
POCHOST = "https://api.dev.ms.refinitiv.com/metadata-service/metadata-store/beta1/metadata"

print(">> POST metadata payload '%s' to '%s' (schemaVersion=%s) ...\n" % (PAYLOAD_FILE, DsD_OBJ, schemaVER))
url = POCHOST + '/' + DsD_OBJ + '?overwrite=true&adminStatus=Released'

payload = open(PAYLOAD_DIR + '/' + PAYLOAD_FILE)
headers = {'Content-Type': 'application/json', 'Override-Schema-Version': '' + schemaVER + '', 'Authorization': 'Bearer ' + TOKEN}

response = requests.post(url, data=payload, headers=headers)
print(response.text.encode('utf8') + "\n")
