#!/bin/bash

function return_COMPLETED_Jobs_status_in_json
{
    LOGFILE=$1
    DSNAME=$2

    RETJSONFILE="abs_Job_Status_${DSNAME}.json"

    # Abstract all "COMPLETED" Job Status Info
    TMPCONTENT=$(grep -zPo '\[INFO\]: Response: JobId\([^\)]*\) for DP\([^\)]*\) :\{\n.*\n  "status" : "COMPLETED",\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*\n.*' $LOGFILE)

    # Convert '[INFO]: Response: JobId(xxxxxx) for DP(xxxxxxxxx) :{' for json format
    TMPCONTENT=$(echo "$TMPCONTENT" | sed -z 's/\[INFO\]: Response: JobId([^)]*) for DP(\([^)]*\)) :{\n/{\n  "DP" : "\1",\n/g')

    # Insert '[' at the first line of file
    TMPCONTENT=$(echo "$TMPCONTENT" | sed '1 i [')

    # Replace all '}' to '},'
    TMPCONTENT=$(echo "$TMPCONTENT" | sed 's/}/},/g')

    # Insert ']' at the last line of file
    TMPCONTENT=$(echo "$TMPCONTENT" | sed -z 's/$/]\n/')

    # Replace '},\n]' to '}\n]'
    TMPCONTENT=$(echo "$TMPCONTENT" | sed -z 's/},\n]/}\n]/')

    # Remove redundant [INFO] lines (if exists) due to occasional bad Job Status response caused by DynamodDB query issue
    TMPCONTENT=$(echo "$TMPCONTENT" | sed -z -e 's/\[INFO\]: getJobIdStatus, url:.*[0-9a-f]\n//g;s/\[INFO\]: Response: JobId.*\w\n//g')

	echo "$TMPCONTENT" > "$RETJSONFILE"
}

function return_FAILED_Jobs_status_info
{
    LOGFILE=$1

    # Abstract all "FAILED" Job Status Info
    FAILEDJOB=$(grep -zPo '\[INFO\]: Response: JobId\([^\)]*\) for DP\([^\)]*\) :\{\n.*\n  "status" : "FAILED"' $LOGFILE)
    if [ $? -eq 0 ]; then
        DPIdSet=$(echo $FAILEDJOB | grep -o 'ecp:[^)]*')
        sn=0
        for DPId in $DPIdSet ; do
            (( sn += 1 ))
            printf "[%02d] DP: %s    <FAILED>\n" $sn $DPId
        done
        printf "\n"
    fi
}

function cacl_time_duration
{
    JobStat=$1

    TM_S=$(echo "$JobStat" | jq -r '.startTime')
    TM_S_SEC=$(date -d $TM_S +%s)
    TM_E=$(echo "$JobStat" | jq -r '.stopTime')
    TM_E_SEC=$(date -d $TM_E +%s)

    (( TM_Duration = TM_E_SEC - TM_S_SEC ))

    echo "$JobStat" | jq -rj '"  - ", .operationType, " ", .naturalNamePath, " (", .naturalNames[0], "), ", .status, ": "'
    echo "${TM_Duration}s"
}

DSNAME="FROGC"

TM_Duration=0
RETJSONFILE=""

#LOGFILE=$(ls console_Full_IMPORT_TBM_*.log 2> /dev/null)
LOGFILE=$1
echo -e "\n---------------------------------------------- LOGFILE: $LOGFILE ----------------------------------------------"

return_FAILED_Jobs_status_info $LOGFILE

return_COMPLETED_Jobs_status_in_json $LOGFILE $DSNAME

# Retrieve DPs list
#DPs_set=$( jq -r '.[].DP' $RETJSONFILE  | sort -u)
DPs_set=$( jq -r '.[].DP' $RETJSONFILE  | awk '!x[$0]++')

JSONCONTENT=$(cat $RETJSONFILE)
# Traverse all DPs to get envelope, objectType|relationshipType & resUnit JOBs status separately nad caculte time duration
sn=0
for DPId in ${DPs_set}; do
    tm_count=0
    (( sn += 1 ))
    printf "[%02d] DP: %s\n" $sn $DPId
    envJson=$(echo "$JSONCONTENT" | jq ".[] | select(.DP == \"${DPId}\" and .\"naturalNamePath\" == \"/SubdomainRoot/ROOT/envelopes\") | .")
    if [ -n "$envJson" ]; then
        cacl_time_duration "$envJson"
        (( tm_count += TM_Duration ))
    fi

    objJson=$(echo "$JSONCONTENT" | jq ".[] | select(.DP == \"${DPId}\" and .\"naturalNamePath\" == \"/SubdomainRoot/ROOT/objectTypes\") | .")
    if [ -n "$objJson" ]; then
        cacl_time_duration "$objJson"
        (( tm_count += TM_Duration ))
    fi

    relJson=$(echo "$JSONCONTENT" | jq ".[] | select(.DP == \"${DPId}\" and .\"naturalNamePath\" == \"/SubdomainRoot/ROOT/relationshipTypes\") | .")
    if [ -n "$relJson" ]; then
        cacl_time_duration "$relJson"
        (( tm_count += TM_Duration ))
    fi

    resJson=$(echo "$JSONCONTENT" | jq ".[] | select(.DP == \"${DPId}\" and .\"naturalNamePath\" == \"/SubdomainRoot/ROOT/resourceUnits\") | .")
    if [ -n "$resJson" ]; then
        cacl_time_duration "$resJson"
        (( tm_count += TM_Duration ))
        echo "  > Total Time-Duration: ${tm_count}s"
    fi
done
