#!/bin/bash

function refetch_AdmToken
{
    AdmTokenRet=$(curl -s -L -X POST 'https://metadata-service-ppe.ms-preprod.aws-int.refinitiv.com/metadata-store/beta1/admin/token' \
    -H 'Accept: application/json' \
    -H 'Content-Type: application/x-www-form-urlencoded' \
    -H 'clientId: 6nrhjadjkfb98kemurflejt0t8' \
    -H 'username: mr2.tester' \
    -H 'password: Ie7k3^y&X' \
    --data-urlencode 'grant_type=password' \
    --data-urlencode 'username=mr2.tester' \
    --data-urlencode 'password=Ie7k3^y&X' \
    --data-urlencode 'clientId=7u28ei3p8qvjm7k6kiuogb04ek' \
    --data-urlencode 'takeExclusiveSignOnControl=true' \
    --data-urlencode 'scope=trapi.metadata')

    if [ -n "$AdmTokenRet" ]; then
        AdmToken=$(echo $AdmTokenRet | jq -r '.token')
        ExpTM=$(echo $AdmTokenRet | jq -r '.expirationTimestamp')
        echo -e "AdmToken:\n$AdmToken"
        echo "ExpireTm: $ExpTM"
    else
        echo "Failed to get the token!"
        exit 2
    fi
}

if (( $# < 1 )); then
    echo "Usage: $0 <SD_VER>"
    exit 2
fi

SD_VER=$1

refetch_AdmToken

DOMAIN="metadatamigrationtest"
errCode=0
for subDomain in "resource" "object" ; do
    echo -e "\n>> DELETE ${DOMAIN}/${subDomain}/${SD_VER}"
    ret=$(curl -s -L -X DELETE "https://metadata-service-ppe.ms-preprod.aws-int.refinitiv.com/metadata-store/beta1/storage-admin/all-resources/${DOMAIN}/${subDomain}/${SD_VER}" \
    -H "Authorization: Bearer ${AdmToken}")

    echo "$ret" | grep "error" &>/dev/null
    if [ $? -eq 0 ]; then
        (( errCode+=1 ))
        echo "$ret"
    fi
done

exit $errCode

