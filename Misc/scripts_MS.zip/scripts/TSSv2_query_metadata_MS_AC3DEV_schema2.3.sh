#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3DEV_iRPM.slib

function display_help
{
    echo "Usage: $0 <-r|-o|-s|-b> [-V <schemaVer>] [-J] [-X] [-H] [-M] [-h] [sub-Path]"
}

#WORKDIR=$(dirname $(readlink -f "$0"))
ADMINSTA="adminStatus=Released"

JQPARSE="true"
NOHATEOASOPT="flase"
NOMETAOPT="false"
HEADEROPTS=""
while getopts :hrosbHMJXV: paras
do
    case "$paras" in
        r)  DOMAIN_Entity_URL="metadatamigrationtest/test-res-schemav2/resourceUnits"
            ;;
        o)  DOMAIN_Entity_URL="metadatamigrationtest/test-obj-schemav2/envelopes"
            ;;
        s)  DOMAIN_Entity_URL="metadatamigrationtest/test-des-schemav2/relationshipTypes"
            ;;
        b)  DOMAIN_Entity_URL="metadatamigrationtest/test-des-schemav2/objectTypes"
            ;;
        V)  ADMINSTA="${ADMINSTA}&schemaVersion=${OPTARG}"
            ;;
        J)  JQPARSE="false"
            ;;
        X)  EXPANDTREE="true"
            ;;
        H)  NOHATEOASOPT="true"
            ;;
        M)  NOMETAOPT="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${DOMAIN_Entity_URL}" ]; then
    display_help
    exit 2
fi

shift $((OPTIND-1))
if (( $# >= 1 )); then
    subPath=$1
    echo ${subPath} | grep -o "adminStatus=" &> /dev/null
    if [ $? -eq 0 ]; then
        DOMAIN_Entity_URL="${DOMAIN_Entity_URL}/${subPath}"
    else
        DOMAIN_Entity_URL="${DOMAIN_Entity_URL}/${subPath}?${ADMINSTA}"
    fi
else
    DOMAIN_Entity_URL="${DOMAIN_Entity_URL}?${ADMINSTA}"
fi

get_token_iRPM_4_mrmt

QUERYPATH="https://api.dev.ms.refinitiv.com/metadata-service/metadata-store/beta1/metadata/${DOMAIN_Entity_URL}"

if [ "${EXPANDTREE}" = "true" ]; then
	HEADEROPTS="${HEADEROPTS}-H 'expandTree: 1' "
fi
if [ "${NOHATEOASOPT}" = "true" ]; then
	HEADEROPTS="${HEADEROPTS}-H 'No-HATEOAS-Links: true' "
fi
if [ "${NOMETAOPT}" = "true" ]; then
	HEADEROPTS="${HEADEROPTS}-H 'No-Meta-Info: true' "
fi

CMDSTR="curl -s -X GET \"${QUERYPATH}\" -H \"Authorization: Bearer ${token}\" ${HEADEROPTS}"

if [ "${JQPARSE}" = "true" ]; then
    eval "$CMDSTR" | jq '.'
else
    eval "$CMDSTR"
fi
