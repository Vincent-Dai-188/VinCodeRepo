#!/bin/bash

#
# Extract contentItem data (json) from specified exported full data by traversal or 'expandTree: All'
#

if (( $# < 2 )); then
	echo "Usage: $0 <DATA_FILE> <CS_TAG>"
	exit 2
fi

#DATAFILE="EP_DEV_Vincent_xT-100.json"
DATAFILE=$1
CSTAG=$2

OUTDIR="./CI_data_${CSTAG}"

mkdir -p ${OUTDIR}

ARRLEN=$(jq '.contentItems | length' "${DATAFILE}")

for ((n=0;n<${ARRLEN};n++)); do
	CINAME=$(jq -r ".contentItems[${n}].name" "${DATAFILE}")
	echo -n "[$n]^${CINAME}^"
	jq ".contentItems[${n}]" "${DATAFILE}" > ${OUTDIR}/CI_${CINAME}_EP.json
	sleep 1
	ls -lh "${OUTDIR}/CI_${CINAME}_EP.json" | awk '{print $5}'
done
