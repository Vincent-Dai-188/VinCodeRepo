#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3DEV_iRPM.slib

get_token_iRPM_4_mrmt

HOSTURL="https://api.dev.ms.refinitiv.com/metadata-service/metadata-store/beta1/admin/domains"

DOMAIN_SUBDOMAIN="configuration/data-store"
echo ">> Update '${DOMAIN_SUBDOMAIN}' configuration"
ret_Res=$(curl -sS -X PUT "${HOSTURL}/${DOMAIN_SUBDOMAIN}" -H 'Content-Type: application/json' -d '{"name":"/configuration/data-store","officialName":"/configuration/data-store","description":"The domain for data store configuration data models","maintainers":[],"sharedIdentityEnabled":true}' -H "Authorization: Bearer ${token}")
echo "$ret_Res"

sleep 2

DOMAIN_SUBDOMAIN="physical/data-store"
echo -e "\n>> Update '${DOMAIN_SUBDOMAIN}' configuration"
ret_Obj=$(curl -sS -X PUT "${HOSTURL}/${DOMAIN_SUBDOMAIN}" -H 'Content-Type: application/json' -d '{"name":"/physical/data-store","officialName":"/physical/data-store","description":"The domain for data store physical data models","maintainers":[],"sharedIdentityEnabled":true}' -H "Authorization: Bearer ${token}")
echo "$ret_Obj"

sleep 2

DOMAIN_SUBDOMAIN="logical/data-store"
echo -e "\n>> Update '${DOMAIN_SUBDOMAIN}' configuration"
ret_Des=$(curl -sS -X PUT "${HOSTURL}/${DOMAIN_SUBDOMAIN}" -H 'Content-Type: application/json' -d '{"name":"/logical/data-store","officialName":"/logical/data-store","description":"The domain for data store logical data models","maintainers":[],"sharedIdentityEnabled":true}' -H "Authorization: Bearer ${token}")
echo "$ret_Des"

echo
