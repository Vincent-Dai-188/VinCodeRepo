#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_PPE.slib

function display_help
{
	echo "Usage: $0 <-r|-o|-s> <subdomain>"
}

if (( $# < 2 )); then
    display_help
    exit 2
fi

while getopts :hr:o:s: paras
do
    case "$paras" in
        r)  Entity_URL="/configuration/data-store/resourceUnits/${OPTARG}"
            ;;
        o)  Entity_URL="/physical/data-store/envelopes"
            ;;
        s)  Entity_URL="/logical/cdf-object/objectCollection"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

get_token_ADM

echo ">> DELETE '${Entity_URL}'"
curl -sS -X DELETE "https://metadata-service-ppe.ms-preprod.aws-int.refinitiv.com/metadata-store/beta1/metadata${Entity_URL}?cascade=true&adminStatus=Migrated" -H "Authorization: Bearer ${token}"
