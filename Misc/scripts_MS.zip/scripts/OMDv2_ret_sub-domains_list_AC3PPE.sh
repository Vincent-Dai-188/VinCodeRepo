#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3PPE_iRPM.slib

allOpt=""

if (( $# == 1 )); then
    OPT=$1
    if [ "${OPT}" = "-A" ]; then
        allOpt="?allVersions=true"
    fi
fi

get_token_iRPM_4_mrmt

HOSTURL="https://api.ppe.ms.refinitiv.com/metadata-service/metadata-store/beta1/storage/domains"

if [ -z "${allOpt}" ]; then
    retDomains=$(curl -sS -X GET "${HOSTURL}" -H "Authorization: Bearer ${token}")
    echo "$retDomains" | grep '^\s*{.*}\s*$' &>/dev/null
    if [ $? -ne 0 ]; then
        echo "Failed to get response of valid json string!"
        echo "$retDomains"
        exit 2
    fi
    for domain in "configuration" "physical" "logical" ; do
        echo "${retDomains}" | jq -r ".${domain} | to_entries[] | select(.key==\"data-store\") | .key, .value"
    done
else
    retDomains=$(curl -sS -X GET "${HOSTURL}${allOpt}" -H "Authorization: Bearer ${token}")
    for domain in "configuration" "physical" "logical" ; do
        echo "${retDomains}" | jq -r ".${domain} | to_entries[] | select(.key==\"data-store\") | .key, .value"
    done
fi
