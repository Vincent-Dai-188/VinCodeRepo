#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3QA_iRPM.slib

function display_help
{
    echo "Usage: $0 <-r|-o|-s> [-J] [-h] [target]"
}

#WORKDIR=$(dirname $(readlink -f "$0"))
ADMINSTA="adminStatus=Migrated"

JQPARSE="true"
while getopts :hrosJ paras
do
    case "$paras" in
        r)  DOMAIN_Entity_URL="configuration/data-store/resourceUnits"
            ;;
        o)  DOMAIN_Entity_URL="physical/data-store/envelopes"
            ;;
        s)  DOMAIN_Entity_URL="logical/cdf-object/objectCollection"
            ;;
        J)  JQPARSE="false"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

if [ -z "${DOMAIN_Entity_URL}" ]; then
    display_help
    exit 2
fi

shift $((OPTIND-1))
if (( $# >= 1 )); then
    targetObj=$1
    DOMAIN_Entity_URL="${DOMAIN_Entity_URL}/${targetObj}?${ADMINSTA}"
else
    DOMAIN_Entity_URL="${DOMAIN_Entity_URL}?${ADMINSTA}"
fi

get_token_iRPM_4_mrmt

ret=$(curl -w "\nStatus_Code: %{http_code}\n" -s -X POST \
"https://api.qa.ms.refinitiv.com/metadata-service/metadata-store/beta1/metadata-snapshots/${DOMAIN_Entity_URL}" \
  --header 'Accept: application/json' \
  --header "Authorization: Bearer ${token}")

StatusStr=$(echo "$ret" | tail -n 1)
if [ "$StatusStr" != "Status_Code: 202" ]; then
    echo "DUMP snapshot failed!"
fi

resBody=$(echo "${ret}" | sed '$d')
echo "$resBody" | jq '.'
