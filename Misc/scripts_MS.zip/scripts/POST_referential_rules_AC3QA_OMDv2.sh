#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3QA_iRPM.slib

get_token_iRPM_4_mrmt

HOSTURL="https://api.qa.ms.refinitiv.com/metadata-service/metadata-store/beta1/validations/reference"

#RULESDIR="/data/vincent/MR/MigrationTool_MR2.0/schema_v2.4/v2.4_0"

DOMAIN_SUBDOMAIN="configuration/data-store"
PAYLOADFILE="ConfigurationDomain_referential-rules.json"
echo -e "\n>> POST referential validation rule into '${DOMAIN_SUBDOMAIN}' with payload file '${PAYLOADFILE}'"
curl -sS -X POST "${HOSTURL}/${DOMAIN_SUBDOMAIN}/rules" -H 'Content-Type: application/json' -H "Authorization: Bearer ${token}" -d @${PAYLOADFILE}

sleep 2

DOMAIN_SUBDOMAIN="physical/data-store"
PAYLOADFILE="Layer2Domain_referential-rules.json"
echo -e "\n>> POST referential validation rule into '${DOMAIN_SUBDOMAIN}' with payload file '${PAYLOADFILE}'"
curl -sS -X POST "${HOSTURL}/${DOMAIN_SUBDOMAIN}/rules" -H 'Content-Type: application/json' -H "Authorization: Bearer ${token}" -d @${PAYLOADFILE}

sleep 2

DOMAIN_SUBDOMAIN="logical/data-store"
PAYLOADFILE="ObjectDescriptionDomain_referential-rules.json"
echo -e "\n>> POST referential validation rule into '${DOMAIN_SUBDOMAIN}' with payload file '${PAYLOADFILE}'"
curl -sS -X POST "${HOSTURL}/${DOMAIN_SUBDOMAIN}/rules" -H 'Content-Type: application/json' -H "Authorization: Bearer ${token}" -d @${PAYLOADFILE}


curl -sS -X POST 'https://api.dev.ms.refinitiv.com/metadata-service/metadata-store/beta1/validations/reference/configuration/data-store/rules' -H 'Content-Type: application/json' -H 'Authorization: Bearer {token}' -d @{PAYLOADFILE}