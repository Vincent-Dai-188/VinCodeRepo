#!/bin/bash
SVER="2.4.3-1"

./OSV_OMDv2_del_ROOTnode_ros_AC3DEV_auto_Created.sh ${SVER} -r
sleep 2

./OSV_OMDv2_del_ROOTnode_ros_AC3DEV_auto_Created.sh ${SVER} -s
sleep 2

./OSV_OMDv2_del_ROOTnode_ros_AC3DEV_auto_Created.sh ${SVER} -o
sleep 2

./OSV_Create_ROOT_nodes_and_check_status_OMDv2_AC3DEV_Created.sh ${SVER}
