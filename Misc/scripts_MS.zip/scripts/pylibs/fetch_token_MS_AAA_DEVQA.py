import sys
import requests
import os.path
import time

AAATOKENFILE = "/tmp/.token_MS_AAA_DEVQA.aut"

def fetch_aaa_token():
    url = "https://us-east-1-api.dev.refinitiv.com/auth/oauth2/beta1/token"
    ''' Original password 'hV%YvY$A8p88-t@Q' is encoded to 'hV%25YvY%24A8p88-t%40Q' '''
    #payload='grant_type=password&username=GE-A-01103867-3-8343&password=hV%25YvY%24A8p88-t%40Q&client_id=ff12cd3431f746d0b60d6df351db1ad230d1ee75&scope=trapi.metadata&takeExclusiveSignOnControl=true'
    payload='grant_type=password&username=yun.dai.rdp@refinitiv.com&password=PortalAlpha@912&client_id=ff12cd3431f746d0b60d6df351db1ad230d1ee75&scope=trapi.metadata&takeExclusiveSignOnControl=true'
    headers = {'Accept': 'application/json', 'Content-Type': 'application/x-www-form-urlencoded'}

    response = requests.post(url, headers=headers, data=payload)
    sta_code = response.status_code
    if (sta_code != 200):
        print('Failed to fetch RDP Token! Status Code: %d' % sta_code)
        sys.exit(2)

    jsonResponse = response.json()
    tokenStr = jsonResponse["access_token"]
    expSecsStr = jsonResponse["expires_in"]

    ''' Covert "expired in seconds" to expirationTimestamp string '''
    expTmStr = str(int(time.time()) + int(expSecsStr))

    ''' Save token & expirationTimestamp in file '''
    with open(AAATOKENFILE, 'w') as datfile:
        datfile.write(expTmStr + '\n')
        datfile.write(tokenStr + '\n')

    return tokenStr

def get_token_aaa():
    if os.path.isfile(AAATOKENFILE):
        file1 = open(AAATOKENFILE, 'r')
        Lines = file1.readlines()
        file1.close()

        exp_datetime = int(Lines[0].strip('\n'))
        cur_datetime = int(time.time())
        deltaTm = exp_datetime - cur_datetime
        if deltaTm < 30:
            TOKEN = fetch_aaa_token()
        else:
            TOKEN = Lines[1].strip('\n')
    else:
        TOKEN = fetch_aaa_token()

    return TOKEN

