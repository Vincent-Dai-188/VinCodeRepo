import requests
import os.path
import time

RDPTOKENFILE = "/tmp/.token_MS_AAA_AC3Prod.aut"

def fetch_aaa_token():
    url = "https://api.refinitiv.com/auth/oauth2/beta1/token"
    payload='grant_type=password&username=yun.dai2@refinitiv.com&password=Prod3A@912&client_id=ff12cd3431f746d0b60d6df351db1ad230d1ee75&scope=trapi.metadata&takeExclusiveSignOnControl=true'
    headers = {'Accept': 'application/json', 'Content-Type': 'application/x-www-form-urlencoded'}

    response = requests.post(url, headers=headers, data=payload)
    sta_code = response.status_code
    if (sta_code != 200):
        print('Failed to fetch RDP Token! Status Code: %d' % sta_code)
        sys.exit(2)

    jsonResponse = response.json()
    tokenStr = jsonResponse["access_token"]
    expSecsStr = jsonResponse["expires_in"]

    ''' Covert "expired in seconds" to expirationTimestamp string '''
    expTmStr = str(int(time.time()) + int(expSecsStr))

    ''' Save token & expirationTimestamp in file '''
    with open(RDPTOKENFILE, 'w') as datfile:
        datfile.write(expTmStr + '\n')
        datfile.write(tokenStr + '\n')

    return tokenStr

def get_token_aaa():
    if os.path.isfile(RDPTOKENFILE):
        file1 = open(RDPTOKENFILE, 'r')
        Lines = file1.readlines()
        file1.close()

        exp_datetime = int(Lines[0].strip('\n'))
        cur_datetime = int(time.time())
        deltaTm = exp_datetime - cur_datetime
        if deltaTm < 30:
            TOKEN = fetch_aaa_token()
        else:
            TOKEN = Lines[1].strip('\n')
    else:
        TOKEN = fetch_aaa_token()

    return TOKEN
