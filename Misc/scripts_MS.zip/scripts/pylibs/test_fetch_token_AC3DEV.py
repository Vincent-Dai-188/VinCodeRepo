#!/usr/bin/python

import sys

sys.path.append('/data/vincent/pylibs')
from fetch_token_MS_AC3DEV_iRPM import *

iRPMToken = get_token_iRPM_4_mrmt()
print(iRPMToken)
