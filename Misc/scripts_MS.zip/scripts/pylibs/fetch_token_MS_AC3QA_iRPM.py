import sys
import requests
import os.path
import time
import datetime

from urllib3.exceptions import InsecureRequestWarning

# Suppress only the single warning from urllib3 needed.
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

iRPMTOKENFILE = "/tmp/.token_MS_AC3QA_iRPM.aut"

def fetch_token_iRPM_4_mrmt():
    url = "https://api.qa.ms.refinitiv.com/metadata-service/metadata-store/beta1/admin/token"
    payload=''
    headers = {'Accept': 'application/json', 'accessId': 'GENTC-1070634'}

    response = requests.post(url, headers=headers, data=payload, verify=False)
    sta_code = response.status_code
    if (sta_code != 200):
        print('Failed to fetch iRPM Token! Status Code: %d' % sta_code)
        sys.exit(2)

    jsonResponse = response.json()
    tokenStr = jsonResponse["token"]

    ''' Covert "expirationTimestamp" to timestamp string '''
    #timetuple = datetime.strptime(jsonResponse["expirationTimestamp"], "%Y-%m-%d %H:%M:%S").timetuple()
    #timestamp = time.mktime(timetuple)
    #expTmStr = str(int(timestamp))
    NOWDT = datetime.datetime.now().timetuple()
    timestamp = time.mktime(NOWDT)
    longDelta88 = 7603200
    expTmStr = str(int(timestamp) + longDelta88)

    ''' Save token & expirationTimestamp in file '''
    with open(iRPMTOKENFILE, 'w') as datfile:
        datfile.write(expTmStr + '\n')
        datfile.write(tokenStr + '\n')

    return tokenStr

def get_token_iRPM_4_mrmt():
    if os.path.isfile(iRPMTOKENFILE):
        file1 = open(iRPMTOKENFILE, 'r')
        Lines = file1.readlines()
        file1.close()

        exp_datetime = int(Lines[0].strip('\n'))
        cur_datetime = int(time.time())
        deltaTm = exp_datetime - cur_datetime
        if deltaTm < 3600:
            TOKEN = fetch_token_iRPM_4_mrmt()
        else:
            TOKEN = Lines[1].strip('\n')
    else:
        TOKEN = fetch_token_iRPM_4_mrmt()

    return TOKEN

