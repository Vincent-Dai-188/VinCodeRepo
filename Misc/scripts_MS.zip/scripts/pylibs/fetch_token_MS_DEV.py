import requests
import os.path
import time
from datetime import datetime

TOKENFILE = "/tmp/.token_MS_DEV.aut"

def fetch_cognito_token_DEV():
    url = "https://metadata-service-dev.ms-preprod.aws-int.refinitiv.com/metadata-store/beta1/admin/token"
    payload=''
    headers = {'Accept': 'application/json', 'clientId': '2nd5qpa0hlsdqdqqvau2ciuvm5', 'password': 'yQxL85Su@', 'username': 'mr2.developer'}

    response = requests.post(url, headers=headers, data=payload)
    sta_code = response.status_code
    if (sta_code != 200):
        print('Failed to fetch cognito Token! Status Code: %d' % sta_code)
        sys.exit(2)

    jsonResponse = response.json()
    tokenStr = jsonResponse["token"]

    ''' Covert "expirationTimestamp" to timestamp string '''
    timetuple = datetime.strptime(jsonResponse["expirationTimestamp"], "%Y-%m-%d %H:%M:%S").timetuple()
    timestamp = time.mktime(timetuple)
    expTmStr = str(int(timestamp))

    ''' Save token & expirationTimestamp in file '''
    with open(TOKENFILE, 'w') as datfile:
        datfile.write(expTmStr + '\n')
        datfile.write(tokenStr + '\n')

    return tokenStr

def get_token_cognito_DEV():
    if os.path.isfile(TOKENFILE):
        file1 = open(TOKENFILE, 'r')
        Lines = file1.readlines()
        file1.close()

        exp_datetime = int(Lines[0].strip('\n'))
        cur_datetime = int(time.time())
        deltaTm = exp_datetime - cur_datetime
        if deltaTm < 60:
            TOKEN = fetch_cognito_token_DEV()
        else:
            TOKEN = Lines[1].strip('\n')
    else:
        TOKEN = fetch_cognito_token_DEV()

    return TOKEN

