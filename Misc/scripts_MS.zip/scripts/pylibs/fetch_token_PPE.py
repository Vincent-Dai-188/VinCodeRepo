import requests
import os.path
import time
from datetime import datetime

COGTOKENFILE = "/tmp/.token_MS_ADM.aut"
RDPTOKENFILE = "/tmp/.token_MS_RDP.aut"

def fetch_token_ADM():
    url = "https://metadata-service-ppe.ms-preprod.aws-int.refinitiv.com/metadata-store/beta1/admin/token"
    payload=''
    headers = {'Accept': 'application/json', 'clientId': '6nrhjadjkfb98kemurflejt0t8', 'password': 'Ie7k3^y&X', 'username': 'mr2.tester'}

    response = requests.post(url, headers=headers, data=payload)
    sta_code = response.status_code
    if (sta_code != 200):
        print('Failed to fetch cognito Token! Status Code: %d' % sta_code)
        sys.exit(2)

    jsonResponse = response.json()
    tokenStr = jsonResponse["token"]

    ''' Covert "expirationTimestamp" to timestamp string '''
    timetuple = datetime.strptime(jsonResponse["expirationTimestamp"], "%Y-%m-%d %H:%M:%S").timetuple()
    timestamp = time.mktime(timetuple)
    expTmStr = str(int(timestamp))

    ''' Save token & expirationTimestamp in file '''
    with open(COGTOKENFILE, 'w') as datfile:
        datfile.write(expTmStr + '\n')
        datfile.write(tokenStr + '\n')

    return tokenStr

def get_token_ADM():
    if os.path.isfile(COGTOKENFILE):
        file1 = open(COGTOKENFILE, 'r')
        Lines = file1.readlines()
        file1.close()

        exp_datetime = int(Lines[0].strip('\n'))
        cur_datetime = int(time.time())
        deltaTm = exp_datetime - cur_datetime
        if deltaTm < 60:
            TOKEN = fetch_token_ADM()
        else:
            TOKEN = Lines[1].strip('\n')
    else:
        TOKEN = fetch_token_ADM()

    return TOKEN

def fetch_token_RDP():
    url = "https://us-east-1-api.ppe.refinitiv.com/auth/oauth2/beta1/token"
    payload='grant_type=password&username=yun.daiT3@refinitiv.com&password=RdpPortal@T3@912&client_id=ff12cd3431f746d0b60d6df351db1ad230d1ee75&scope=trapi.metadata&takeExclusiveSignOnControl=true'
    headers = {'Accept': 'application/json', 'Content-Type': 'application/x-www-form-urlencoded'}

    response = requests.post(url, headers=headers, data=payload)
    sta_code = response.status_code
    if (sta_code != 200):
        print('Failed to fetch RDP Token! Status Code: %d' % sta_code)
        sys.exit(2)

    jsonResponse = response.json()
    tokenStr = jsonResponse["access_token"]
    expSecsStr = jsonResponse["expires_in"]

    ''' Covert "expired in seconds" to expirationTimestamp string '''
    expTmStr = str(int(time.time()) + int(expSecsStr))

    ''' Save token & expirationTimestamp in file '''
    with open(RDPTOKENFILE, 'w') as datfile:
        datfile.write(expTmStr + '\n')
        datfile.write(tokenStr + '\n')

    return tokenStr

def get_token_RDP():
    if os.path.isfile(RDPTOKENFILE):
        file1 = open(RDPTOKENFILE, 'r')
        Lines = file1.readlines()
        file1.close()

        exp_datetime = int(Lines[0].strip('\n'))
        cur_datetime = int(time.time())
        deltaTm = exp_datetime - cur_datetime
        if deltaTm < 30:
            TOKEN = fetch_token_RDP()
        else:
            TOKEN = Lines[1].strip('\n')
    else:
        TOKEN = fetch_token_RDP()

    return TOKEN

