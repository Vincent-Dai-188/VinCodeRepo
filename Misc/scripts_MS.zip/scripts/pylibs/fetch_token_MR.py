import requests
import os.path
import time

TOKENFILE = "/tmp/.token_MR_QA.aut"
URL = "https://ecp-registry-qa-int.thomsonreuters.com/auth"
TOKENFILE_DEV = "/tmp/.token_MR_DEV.aut"
URL_DEV = "https://registry-ecp-devs.a-corporate-preprod.aws-int.thomsonreuters.com/auth"

def fetch_token_MR():
    global TOKENFILE, URL
    url = URL
    payload=''
    headers = {'Key': 'u6025979', 'SecretKey': 'Rjr>NJgR9\BD.V-T', 'x-api-key': 'gDtAPG68Im8ObNx6G0ZyG4PbYSyzfpjt3qT8VN20'}

    response = requests.post(url, headers=headers, data=payload)
    sta_code = response.status_code
    if (sta_code != 200):
        print('Failed to fetch auth Token! Status Code: %d' % sta_code)
        sys.exit(2)

    #print(response)
    tokenStr = response.text

    ''' Save curTimestamp & token in file '''
    curTmStr = str(int(time.time()))
    with open(TOKENFILE, 'w') as datfile:
        datfile.write(curTmStr + '\n')
        datfile.write(tokenStr + '\n')

    return tokenStr

def get_token_MR(Env="QA"):
    global TOKENFILE, URL
    if Env == "DEV":
        TOKENFILE = TOKENFILE_DEV
        URL = URL_DEV

    if os.path.isfile(TOKENFILE):
        file1 = open(TOKENFILE, 'r')
        Lines = file1.readlines()
        file1.close()

        old_datetime = int(Lines[0].strip('\n'))
        cur_datetime = int(time.time())
        deltaTm = cur_datetime - old_datetime
        if deltaTm > 900:
            TOKEN = fetch_token_MR()
        else:
            TOKEN = Lines[1].strip('\n')
    else:
        TOKEN = fetch_token_MR()

    return TOKEN

