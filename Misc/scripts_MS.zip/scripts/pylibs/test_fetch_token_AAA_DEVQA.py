#!/usr/bin/python

import sys

sys.path.append('/data/vincent/pylibs')
from fetch_token_MS_AAA_DEVQA import *

AAAToken = get_token_aaa()
print(AAAToken)
