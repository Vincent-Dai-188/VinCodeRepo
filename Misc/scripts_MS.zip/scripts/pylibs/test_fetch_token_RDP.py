#!/usr/bin/python

import sys

sys.path.append('/data/vincent/pylibs')
from fetch_token_RDP import *

RDPToken = get_token_aaa()
print(RDPToken)
