#!/usr/bin/python

import sys

sys.path.append('/data/vincent/pylibs')
from fetch_token_MR import *

print('--- QA ---')
MRToken = get_token_MR()
print(MRToken)

print('--- DEV ---')
MRToken = get_token_MR('DEV')
print(MRToken)

