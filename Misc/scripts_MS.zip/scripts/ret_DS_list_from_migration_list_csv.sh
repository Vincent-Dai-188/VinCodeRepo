#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 <MIG_CSV_FILE>"
    exit 1
fi

MIG_LIST_FILE=$1

if [ ! -f "${MIG_LIST_FILE}" ]; then
    echo "'${MIG_LIST_FILE}' not found!"
    exit 2
fi

DS_list_Obj=$(grep -o "[^,]*,object" $MIG_LIST_FILE | sed 's/,object//g' | sort -u)
DS_list_Obj=$(echo $DS_list_Obj | sed -z 's/\n/ /g')
DS_list_Obj=$(echo $DS_list_Obj | sed 's/ $//')
arr_Obj=( $DS_list_Obj )
num_Obj="${#arr_Obj[@]}"

DS_list_Rel=$(grep -o "[^,]*,relationship" $MIG_LIST_FILE | sed 's/,relationship//g' | sort -u)
DS_list_Rel=$(echo $DS_list_Rel | sed -z 's/\n/ /g')
DS_list_Rel=$(echo $DS_list_Rel | sed 's/ $//')
arr_Rel=( $DS_list_Rel )
num_Rel="${#arr_Rel[@]}"

TMstr="$(date +"%Y%m%d%H%M")"

echo -e "# SOURCE: ${MIG_LIST_FILE}\n# DS-Obj: [$num_Obj] \nDS_Obj=\"${DS_list_Obj}\"" > DS_OBJ_${TMstr}.lst

echo -e "# SOURCE: ${MIG_LIST_FILE}\n# DS-Rel: [$num_Rel] \nDS_Rel=\"${DS_list_Rel}\"" > DS_REL_${TMstr}.lst
