#!/bin/bash

. /data/vincent/slibs/fetch_token_MS_AC3DEV_iRPM.slib

function get_job_status     # retMsg
{
    retMsg=$1
    #echo "- ${retMsg}"
    staCode=$(echo "${retMsg}" | jq -r '.status')
    if [ "${staCode}" = "202" ]; then
        retLocation=$(echo "${retMsg}" | jq -r '.payload.location')
        echo " - $retLocation"
        count=0
        while (( count < 50 ))
        do
            (( count+=1 ))
            retQuery=$(curl -sS -X GET "https://api.dev.ms.refinitiv.com/metadata-service/metadata-store${retLocation}" -H "Authorization: Bearer ${token}")
            staCodeQ=$(echo "${retQuery}" | jq -r '.status')
            if [ "${staCodeQ}" = "200" ]; then
                status_Res=$(echo "${retQuery}" | jq -r '.payload.status')
                echo ">> ${status_Res}"
                if [ "${status_Res}" = "FAILED" ] || [ "${status_Res}" = "COMPLETED" ]; then
                    break
                else
                    sleep 20
                fi
            else
                echo "Failed to get write job status!"
                echo "${retQuery}"
                return 1
            fi
        done
    else
        echo "Failed to create write job!"
        echo "${retMsg}"
        return 2
    fi
    return 0
}

if (( $# < 2 )); then
    echo "Usage: $0 <[-r|-o|-s|-b subRoot] | [-n nnPath]> [-h]"
    exit 1
fi

while getopts :hr:o:s:b:n: paras
do
    case "$paras" in
        r)  DOMAIN_Entity_URL="/configuration/data-store/resourceUnits/${OPTARG}"
            ;;
        o)  DOMAIN_Entity_URL="/physical/data-store/objects/${OPTARG}"
            ;;
        s)  DOMAIN_Entity_URL="/logical/data-store/relationshipTypes/${OPTARG}"
            ;;
        b)  DOMAIN_Entity_URL="/logical/data-store/objectTypes/${OPTARG}"
            ;;
        n)  DOMAIN_Entity_URL="${OPTARG}"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

get_token_iRPM_4_mrmt

HOSTURL="https://api.dev.ms.refinitiv.com/metadata-service/metadata-store/beta1/metadata"

echo ">> DELETE '${DOMAIN_Entity_URL}'"
retMsg=$(curl -sS -X DELETE "${HOSTURL}${DOMAIN_Entity_URL}?cascade=true&adminStatus=Released" -H "Authorization: Bearer ${token}")

get_job_status "${retMsg}"
