#!/bin/bash

sn=0
while read LINE; do
    (( sn += 1 ))
    DPCV=$(echo "$LINE" | awk -F',' '{print $1" "$2}')
	DPtag="${DPCV:38:4}"
    printf "====== %d. %s ======\n" $sn $LINE
    ./retrieve_CIs_DEs_by_DP_CV.sh $DPCV | tee out_RCS_CIs_DEs_${DPtag}.txt
done < OBJ_DPCVs_RCS.lst
