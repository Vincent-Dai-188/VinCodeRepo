#!/bin/bash

function display_help
{
    echo "Usage: $0 <-D OMD|TSS> <-E DEV|QA|PPE> <-V MRMT_VER> [-h]"
}

if (( $# < 3 )); then
    display_help
    exit 1
fi

CURDIR=$(pwd)
BASEDIR="/data/vincent/MR/MigrationTool_MR2.0/Template_MRMT_scripts"

while getopts :hD:E:V: paras
do
    case "$paras" in
        D)  DSD=${OPTARG}
            ;;
        E)  ENV=${OPTARG}
            ;;
        V)  MRMTVER=${OPTARG}
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

SWAPDIR="${BASEDIR}/swap"
mkdir -p "${SWAPDIR}"

cp ${BASEDIR}/*.* $SWAPDIR && cd $SWAPDIR

echo ">> Setup config.yml with ENV"
if [ "${DSD}" = "OMD" ]; then
    sed -i -e 's/_resD_/configuration/;s/_resSD_/data-store/;s/_objD_/physical/;s/_objSD_/data-store/;s/_desD_/logical/;s/_desSD_/cdf-object/' _DSD_v2_config_v2.2_manual_AC3_ENV_.yml
elif [ "${DSD}" = "TSS" ]; then
    sed -i -e 's/_resD_/metadatamigrationtest/;s/_resSD_/test-res-schemav2/;s/_objD_/metadatamigrationtest/;s/_objSD_/test-obj-schemav2/;s/_desD_/metadatamigrationtest/;s/_desSD_/test-des-schemav2/' _DSD_v2_config_v2.2_manual_AC3_ENV_.yml
else
    display_help
    exit 2
fi

if [ "${ENV}" = "PPE" ]; then
    sed -i 's/_ALBENV_/ppe/g' _DSD_v2_config_v2.2_manual_AC3_ENV_.yml
elif [ "${ENV}" = "QA" ]; then
    sed -i 's/_ALBENV_/qa/g' _DSD_v2_config_v2.2_manual_AC3_ENV_.yml
elif [ "${ENV}" = "DEV" ]; then
    sed -i 's/_ALBENV_/dev/g' _DSD_v2_config_v2.2_manual_AC3_ENV_.yml
else
    display_help
    exit 2
fi

echo ">> Update config name in export/import single script files"
sed -i -e "s/_DSD_/${DSD}/;s/_ENV_/${ENV}/" _DSD_v2_AC3_ENV__FullCSV_*.sh

echo ">> Update export/import single script name in batch files"
sed -i "s/_DSD_v2_AC3_ENV__FullCSV_/${DSD}v2_AC3${ENV}_FullCSV_/" *_batch_*.sh

echo ">> Update '_MRMTVER_' in  \"_DSD_v2_AC3_ENV__batch_FullCSV_export_*.sh\""
sed -i "s/_MRMTVER_/${MRMTVER}/" _DSD_v2_AC3_ENV__batch_FullCSV_export_*.sh

echo ">> Rename scripts by replacing '_DSD_' & '_ENV_'"
for fn in $(ls *.*); do newFn=$(echo $fn | sed -e "s/_DSD_/${DSD}/;s/_ENV_/${ENV}/") && mv $fn $newFn; done

TARGETDIR="${CURDIR}/${DSD}_ACT${ENV}_${MRMTVER}"
mkdir -p $TARGETDIR
mv ${SWAPDIR}/*.* $TARGETDIR

echo -e "\n  * Done. *"
