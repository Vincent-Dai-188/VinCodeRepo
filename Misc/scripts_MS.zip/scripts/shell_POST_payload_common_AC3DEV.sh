#!/bin/bash

function get_job_status     # retMsg
{
    retMsg=$1
    #echo "- ${retMsg}"
    staCode=$(echo "${retMsg}" | jq -r '.status')
    if [ "${staCode}" = "202" ]; then
        retLocation=$(echo "${retMsg}" | jq -r '.payload.location')
        echo " - $retLocation"
        count=0
        while (( count < 80 ))
        do
            (( count+=1 ))
            retQuery=$(curl -sS -X GET "https://api.dev.ms.refinitiv.com/metadata-service/metadata-store${retLocation}" -H "Authorization: Bearer ${token}")
            staCodeQ=$(echo "${retQuery}" | jq -r '.status')
            if [ "${staCodeQ}" = "200" ]; then
                status_Res=$(echo "${retQuery}" | jq -r '.payload.status')
                echo ">> ${status_Res}"
                if [ "${status_Res}" = "FAILED" ] || [ "${status_Res}" = "COMPLETED" ]; then
                    break
                else
                    sleep 30
                fi
            else
                echo "Failed to get write job status!"
                echo "${retQuery}"
                return 1
            fi
        done
    else
        echo "Failed to create write job!"
        echo "${retMsg}"
        return 2
    fi
    return 0
}

. /data/vincent/slibs/fetch_token_MS_AC3DEV_iRPM.slib

function display_help
{
    echo "Usage: $0 <-O|-T> <-r|-o|-b|-s> <-P payloadfile> [-A] [-h]"
}

if (( $# < 3 )); then
    display_help
    exit 1
fi

AutoStatus=""

while getopts :hOTArobsP: paras
do
    case "$paras" in
        O)  DSD_res="configuration/data-store"
            DSD_obj="physical/data-store"
            DSD_des="logical/data-store"
            ;;
        T)  DSD_res="metadatamigrationtest/test-res-schemav2"
            DSD_obj="metadatamigrationtest/test-obj-schemav2"
            DSD_des="metadatamigrationtest/test-des-schemav2"
            ;;
        r)  subRootPath="${DSD_res}/resourceUnits"
            ;;
        o)  subRootPath="${DSD_obj}/envelopes"
            ;;
        b)  subRootPath="${DSD_des}/objectTypes"
            ;;
        s)  subRootPath="${DSD_des}/relationshipTypes"
            ;;
        P)  PAYLOADFILE="${OPTARG}"
            ;;
        A)  AutoStatus="true"
            ;;
        h)  display_help
            exit 0
            ;;
        *)  display_help
            exit 2
            ;;
    esac
done

get_token_iRPM_4_mrmt

HOSTURL="https://api.dev.ms.refinitiv.com/metadata-service/metadata-store/beta1/metadata"
RELEASEDSTA="?adminStatus=Released"

echo ">> POST '${subRootPath}' with payload file '${PAYLOADFILE}'"
retMsg=$(curl -sS -X POST "${HOSTURL}/${subRootPath}${RELEASEDSTA}" -H 'Content-Type: application/json' -H 'User-Provided-Id: true' -H "Authorization: Bearer ${token}" -d @${PAYLOADFILE})

if [ "$AutoStatus" = "true" ]; then
    get_job_status "${retMsg}"
else
    echo $retMsg
fi
