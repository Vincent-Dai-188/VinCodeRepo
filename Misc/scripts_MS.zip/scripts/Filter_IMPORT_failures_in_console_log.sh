#!/bin/bash

if (( $# < 1 )); then
    echo "Usage: $0 <CONSOLE_LOG_FILE>"
    exit 1
fi

LOGFILE=$1

grep -zPo "\[[^]]*] IMPORT '[^']*'\n\s*>>.* ...\n\s*Summary: [^,]*, Problem DP_CV:[1-9]{1,3} -------" $LOGFILE
