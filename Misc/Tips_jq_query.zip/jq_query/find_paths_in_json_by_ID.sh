#!/bin/bash

function display_help
{
	echo "Usgae: $0 <json_file> <ECPID>"
}

if (( $# < 2 )); then
    display_help
    exit 2
fi

JSONFILE=$1
ECPID=$2

ret=$(jq --arg vID "$ECPID" -c 'paths as $path | select(getpath($path) == $vID) | $path' $JSONFILE)
echo "$ret" | sed -e "s/,\([0-9]\{1,3\}\),/[\1]./g;s/\",\"/\".\"/g;s/^\[/./g;s/\]$//g"
