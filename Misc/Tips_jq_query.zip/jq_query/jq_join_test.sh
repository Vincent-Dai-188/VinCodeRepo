# '-r': jq will print string contents directly to the terminal instead of as JSON escaped strings
# output: 
#   with '-r':  one, two, three
#   without '-r': "one, two, three"
jq -r '.host_components | map(.HostRoles.host_name) | join(", ")' <<DATA
{"host_components":[
  {"HostRoles":{"host_name":"one"}},
  {"HostRoles":{"host_name":"two"}},
  {"HostRoles":{"host_name":"three"}}
]}
DATA