#include <stdio.h>
#include <unistd.h>
 
int main(void)
{
	char cmdbuf[128];
    char *out = "MyPasswd2023"
    sprintf(cmdbuf, "echo -e \"%s\\n%s\" | sudo -S passwd root", out, out);
	system(cmdbuf);

	sprintf(cmdbuf, "sudo ls -la /root/.bashrc");
	system(cmdbuf);

	return 0;
}